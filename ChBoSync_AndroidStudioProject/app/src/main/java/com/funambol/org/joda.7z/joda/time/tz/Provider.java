package com.funambol.org.joda.time.tz;

import java.util.Set;
import com.funambol.org.joda.time.DateTimeZone;

public abstract interface Provider
{
  public abstract DateTimeZone getZone(String paramString);
  
  public abstract Set getAvailableIDs();
}
