package com.funambol.org.joda.time.tz;

import java.util.Collections;
import java.util.Set;
import com.funambol.org.joda.time.DateTimeZone;































public final class UTCProvider
  implements Provider
{
  public UTCProvider() {}
  
  public DateTimeZone getZone(String paramString)
  {
    if ("UTC".equalsIgnoreCase(paramString)) {
      return DateTimeZone.UTC;
    }
    return null;
  }
  


  public Set getAvailableIDs()
  {
    return Collections.singleton("UTC");
  }
}
