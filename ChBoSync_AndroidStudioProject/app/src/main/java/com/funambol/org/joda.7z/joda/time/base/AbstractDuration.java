package com.funambol.org.joda.time.base;

import com.funambol.org.joda.time.Duration;
import com.funambol.org.joda.time.Period;
import com.funambol.org.joda.time.ReadableDuration;
import com.funambol.org.joda.time.format.FormatUtils;






































public abstract class AbstractDuration
  implements ReadableDuration
{
  protected AbstractDuration() {}
  
  public Duration toDuration()
  {
    return new Duration(getMillis());
  }
  





















  public Period toPeriod()
  {
    return new Period(getMillis());
  }
  









  public int compareTo(Object paramObject)
  {
    AbstractDuration localAbstractDuration = this;
    ReadableDuration localReadableDuration = (ReadableDuration)paramObject;
    
    long l1 = localAbstractDuration.getMillis();
    long l2 = localReadableDuration.getMillis();
    

    if (l1 < l2) {
      return -1;
    }
    if (l1 > l2) {
      return 1;
    }
    return 0;
  }
  





  public boolean isEqual(ReadableDuration paramReadableDuration)
  {
    if (paramReadableDuration == null) {
      paramReadableDuration = Duration.ZERO;
    }
    return compareTo(paramReadableDuration) == 0;
  }
  





  public boolean isLongerThan(ReadableDuration paramReadableDuration)
  {
    if (paramReadableDuration == null) {
      paramReadableDuration = Duration.ZERO;
    }
    return compareTo(paramReadableDuration) > 0;
  }
  





  public boolean isShorterThan(ReadableDuration paramReadableDuration)
  {
    if (paramReadableDuration == null) {
      paramReadableDuration = Duration.ZERO;
    }
    return compareTo(paramReadableDuration) < 0;
  }
  







  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {
      return true;
    }
    if (!(paramObject instanceof ReadableDuration)) {
      return false;
    }
    ReadableDuration localReadableDuration = (ReadableDuration)paramObject;
    return getMillis() == localReadableDuration.getMillis();
  }
  





  public int hashCode()
  {
    long l = getMillis();
    return (int)(l ^ l >>> 32);
  }
  











  public String toString()
  {
    long l1 = getMillis();
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("PT");
    FormatUtils.appendUnpaddedInteger(localStringBuffer, l1 / 1000L);
    long l2 = Math.abs(l1 % 1000L);
    if (l2 > 0L) {
      localStringBuffer.append('.');
      FormatUtils.appendPaddedInteger(localStringBuffer, l2, 3);
    }
    localStringBuffer.append('S');
    return localStringBuffer.toString();
  }
}
