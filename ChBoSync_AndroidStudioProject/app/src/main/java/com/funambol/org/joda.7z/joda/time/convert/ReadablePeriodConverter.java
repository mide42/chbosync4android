package com.funambol.org.joda.time.convert;

import com.funambol.org.joda.time.Chronology;
import com.funambol.org.joda.time.PeriodType;
import com.funambol.org.joda.time.ReadWritablePeriod;
import com.funambol.org.joda.time.ReadablePeriod;

























class ReadablePeriodConverter
  extends AbstractConverter
  implements PeriodConverter
{
  static final ReadablePeriodConverter INSTANCE = new ReadablePeriodConverter();
  








  protected ReadablePeriodConverter() {}
  








  public void setInto(ReadWritablePeriod paramReadWritablePeriod, Object paramObject, Chronology paramChronology)
  {
    paramReadWritablePeriod.setPeriod((ReadablePeriod)paramObject);
  }
  







  public PeriodType getPeriodType(Object paramObject)
  {
    ReadablePeriod localReadablePeriod = (ReadablePeriod)paramObject;
    return localReadablePeriod.getPeriodType();
  }
  





  public Class getSupportedType()
  {
    return ReadablePeriod.class;
  }
}
