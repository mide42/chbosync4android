package com.funambol.org.joda.time.convert;

import com.funambol.org.joda.time.Chronology;


























class LongConverter
  extends AbstractConverter
  implements InstantConverter, PartialConverter, DurationConverter
{
  static final LongConverter INSTANCE = new LongConverter();
  







  protected LongConverter() {}
  







  public long getInstantMillis(Object paramObject, Chronology paramChronology)
  {
    return ((Long)paramObject).longValue();
  }
  








  public long getDurationMillis(Object paramObject)
  {
    return ((Long)paramObject).longValue();
  }
  





  public Class getSupportedType()
  {
    return Long.class;
  }
}
