package com.funambol.org.joda.time.chrono;

import java.util.HashMap;
import java.util.Map;
import com.funambol.org.joda.time.Chronology;
import com.funambol.org.joda.time.DateTime;
import com.funambol.org.joda.time.DateTimeField;
import com.funambol.org.joda.time.DateTimeZone;
import com.funambol.org.joda.time.field.SkipDateTimeField;
















































public final class EthiopicChronology
  extends BasicFixedMonthChronology
{
  private static final long serialVersionUID = -5972804258688333942L;
  public static final int EE = 1;
  private static final DateTimeField ERA_FIELD = new BasicSingleEraDateTimeField("EE");
  

  private static final int MIN_YEAR = -292269337;
  

  private static final int MAX_YEAR = 292272984;
  

  private static final Map cCache = new HashMap();
  




  private static final EthiopicChronology INSTANCE_UTC = getInstance(DateTimeZone.UTC);
  







  public static EthiopicChronology getInstanceUTC()
  {
    return INSTANCE_UTC;
  }
  




  public static EthiopicChronology getInstance()
  {
    return getInstance(DateTimeZone.getDefault(), 4);
  }
  





  public static EthiopicChronology getInstance(DateTimeZone paramDateTimeZone)
  {
    return getInstance(paramDateTimeZone, 4);
  }
  






  public static EthiopicChronology getInstance(DateTimeZone paramDateTimeZone, int paramInt)
  {
    if (paramDateTimeZone == null) {
      paramDateTimeZone = DateTimeZone.getDefault();
    }
    EthiopicChronology localEthiopicChronology;
    synchronized (cCache) {
      EthiopicChronology[] arrayOfEthiopicChronology = (EthiopicChronology[])cCache.get(paramDateTimeZone);
      if (arrayOfEthiopicChronology == null) {
        arrayOfEthiopicChronology = new EthiopicChronology[7];
        cCache.put(paramDateTimeZone, arrayOfEthiopicChronology);
      }
      try {
        localEthiopicChronology = arrayOfEthiopicChronology[(paramInt - 1)];
      } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException) {
        throw new IllegalArgumentException("Invalid min days in first week: " + paramInt);
      }
      
      if (localEthiopicChronology == null) {
        if (paramDateTimeZone == DateTimeZone.UTC)
        {
          localEthiopicChronology = new EthiopicChronology(null, null, paramInt);
          
          DateTime localDateTime = new DateTime(1, 1, 1, 0, 0, 0, 0, localEthiopicChronology);
          localEthiopicChronology = new EthiopicChronology(LimitChronology.getInstance(localEthiopicChronology, localDateTime, null), null, paramInt);
        }
        else
        {
          localEthiopicChronology = getInstance(DateTimeZone.UTC, paramInt);
          localEthiopicChronology = new EthiopicChronology(ZonedChronology.getInstance(localEthiopicChronology, paramDateTimeZone), null, paramInt);
        }
        
        arrayOfEthiopicChronology[(paramInt - 1)] = localEthiopicChronology;
      }
    }
    return localEthiopicChronology;
  }
  




  EthiopicChronology(Chronology paramChronology, Object paramObject, int paramInt)
  {
    super(paramChronology, paramObject, paramInt);
  }
  


  private Object readResolve()
  {
    Chronology localChronology = getBase();
    return localChronology == null ? getInstance(DateTimeZone.UTC, getMinimumDaysInFirstWeek()) : getInstance(localChronology.getZone(), getMinimumDaysInFirstWeek());
  }
  








  public Chronology withUTC()
  {
    return INSTANCE_UTC;
  }
  





  public Chronology withZone(DateTimeZone paramDateTimeZone)
  {
    if (paramDateTimeZone == null) {
      paramDateTimeZone = DateTimeZone.getDefault();
    }
    if (paramDateTimeZone == getZone()) {
      return this;
    }
    return getInstance(paramDateTimeZone);
  }
  




  long calculateFirstDayOfYearMillis(int paramInt)
  {
    int i = paramInt - 1963;
    int j;
    if (i <= 0)
    {

      j = i + 3 >> 2;
    } else {
      j = i >> 2;
      
      if (!isLeapYear(paramInt)) {
        j++;
      }
    }
    
    long l = (i * 365L + j) * 86400000L;
    



    return l + 21859200000L;
  }
  
  int getMinYear()
  {
    return -292269337;
  }
  
  int getMaxYear()
  {
    return 292272984;
  }
  
  long getApproxMillisAtEpochDividedByTwo()
  {
    return 30962844000000L;
  }
  
  protected void assemble(AssembledChronology.Fields paramFields)
  {
    if (getBase() == null) {
      super.assemble(paramFields);
      

      year = new SkipDateTimeField(this, year);
      weekyear = new SkipDateTimeField(this, weekyear);
      
      era = ERA_FIELD;
      monthOfYear = new BasicMonthOfYearDateTimeField(this, 13);
      months = monthOfYear.getDurationField();
    }
  }
}
