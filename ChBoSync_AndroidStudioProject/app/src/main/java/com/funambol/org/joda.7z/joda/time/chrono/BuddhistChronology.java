package com.funambol.org.joda.time.chrono;

import java.util.HashMap;
import java.util.Map;
import com.funambol.org.joda.time.Chronology;
import com.funambol.org.joda.time.DateTime;
import com.funambol.org.joda.time.DateTimeField;
import com.funambol.org.joda.time.DateTimeFieldType;
import com.funambol.org.joda.time.DateTimeZone;
import com.funambol.org.joda.time.field.DelegatedDateTimeField;
import com.funambol.org.joda.time.field.DividedDateTimeField;
import com.funambol.org.joda.time.field.OffsetDateTimeField;
import com.funambol.org.joda.time.field.RemainderDateTimeField;
import com.funambol.org.joda.time.field.SkipUndoDateTimeField;













































public final class BuddhistChronology
  extends AssembledChronology
{
  private static final long serialVersionUID = -3474595157769370126L;
  public static final int BE = 1;
  private static final DateTimeField ERA_FIELD = new BasicSingleEraDateTimeField("BE");
  

  private static final int BUDDHIST_OFFSET = 543;
  

  private static final Map cCache = new HashMap();
  

  private static final BuddhistChronology INSTANCE_UTC = getInstance(DateTimeZone.UTC);
  






  public static BuddhistChronology getInstanceUTC()
  {
    return INSTANCE_UTC;
  }
  




  public static BuddhistChronology getInstance()
  {
    return getInstance(DateTimeZone.getDefault());
  }
  






  public static synchronized BuddhistChronology getInstance(DateTimeZone paramDateTimeZone)
  {
    if (paramDateTimeZone == null) {
      paramDateTimeZone = DateTimeZone.getDefault();
    }
    BuddhistChronology localBuddhistChronology = (BuddhistChronology)cCache.get(paramDateTimeZone);
    if (localBuddhistChronology == null)
    {
      localBuddhistChronology = new BuddhistChronology(GJChronology.getInstance(paramDateTimeZone, null), null);
      
      DateTime localDateTime = new DateTime(1, 1, 1, 0, 0, 0, 0, localBuddhistChronology);
      localBuddhistChronology = new BuddhistChronology(LimitChronology.getInstance(localBuddhistChronology, localDateTime, null), "");
      cCache.put(paramDateTimeZone, localBuddhistChronology);
    }
    return localBuddhistChronology;
  }
  







  private BuddhistChronology(Chronology paramChronology, Object paramObject)
  {
    super(paramChronology, paramObject);
  }
  


  private Object readResolve()
  {
    Chronology localChronology = getBase();
    return localChronology == null ? getInstanceUTC() : getInstance(localChronology.getZone());
  }
  






  public Chronology withUTC()
  {
    return INSTANCE_UTC;
  }
  





  public Chronology withZone(DateTimeZone paramDateTimeZone)
  {
    if (paramDateTimeZone == null) {
      paramDateTimeZone = DateTimeZone.getDefault();
    }
    if (paramDateTimeZone == getZone()) {
      return this;
    }
    return getInstance(paramDateTimeZone);
  }
  






  public boolean equals(Object paramObject)
  {
    return super.equals(paramObject);
  }
  





  public int hashCode()
  {
    return "Buddhist".hashCode() * 11 + getZone().hashCode();
  }
  






  public String toString()
  {
    String str = "BuddhistChronology";
    DateTimeZone localDateTimeZone = getZone();
    if (localDateTimeZone != null) {
      str = str + '[' + localDateTimeZone.getID() + ']';
    }
    return str;
  }
  
  protected void assemble(AssembledChronology.Fields paramFields) {
    if (getParam() == null)
    {
      Object localObject = year;
      year = new OffsetDateTimeField(new SkipUndoDateTimeField(this, (DateTimeField)localObject), 543);
      


      localObject = yearOfEra;
      yearOfEra = new DelegatedDateTimeField(year, DateTimeFieldType.yearOfEra());
      


      localObject = weekyear;
      weekyear = new OffsetDateTimeField(new SkipUndoDateTimeField(this, (DateTimeField)localObject), 543);
      

      localObject = new OffsetDateTimeField(yearOfEra, 99);
      centuryOfEra = new DividedDateTimeField((DateTimeField)localObject, DateTimeFieldType.centuryOfEra(), 100);
      

      localObject = new RemainderDateTimeField((DividedDateTimeField)centuryOfEra);
      
      yearOfCentury = new OffsetDateTimeField((DateTimeField)localObject, DateTimeFieldType.yearOfCentury(), 1);
      

      localObject = new RemainderDateTimeField(weekyear, DateTimeFieldType.weekyearOfCentury(), 100);
      
      weekyearOfCentury = new OffsetDateTimeField((DateTimeField)localObject, DateTimeFieldType.weekyearOfCentury(), 1);
      

      era = ERA_FIELD;
    }
  }
}
