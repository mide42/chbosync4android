package com.funambol.org.joda.time.format;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import com.funambol.org.joda.time.Chronology;
import com.funambol.org.joda.time.DateTimeField;
import com.funambol.org.joda.time.DateTimeFieldType;
import com.funambol.org.joda.time.DateTimeZone;
import com.funambol.org.joda.time.DurationField;
import com.funambol.org.joda.time.MutableDateTime;
import com.funambol.org.joda.time.MutableDateTime.Property;
import com.funambol.org.joda.time.ReadablePartial;
import com.funambol.org.joda.time.field.MillisDurationField;
import com.funambol.org.joda.time.field.PreciseDateTimeField;























































public class DateTimeFormatterBuilder
{
  private ArrayList iElementPairs;
  private Object iFormatter;
  
  public DateTimeFormatterBuilder()
  {
    iElementPairs = new ArrayList();
  }
  















  public DateTimeFormatter toFormatter()
  {
    Object localObject = getFormatter();
    DateTimePrinter localDateTimePrinter = null;
    if (isPrinter(localObject)) {
      localDateTimePrinter = (DateTimePrinter)localObject;
    }
    DateTimeParser localDateTimeParser = null;
    if (isParser(localObject)) {
      localDateTimeParser = (DateTimeParser)localObject;
    }
    if ((localDateTimePrinter != null) || (localDateTimeParser != null)) {
      return new DateTimeFormatter(localDateTimePrinter, localDateTimeParser);
    }
    throw new UnsupportedOperationException("Both printing and parsing not supported");
  }
  











  public DateTimePrinter toPrinter()
  {
    Object localObject = getFormatter();
    if (isPrinter(localObject)) {
      return (DateTimePrinter)localObject;
    }
    throw new UnsupportedOperationException("Printing is not supported");
  }
  











  public DateTimeParser toParser()
  {
    Object localObject = getFormatter();
    if (isParser(localObject)) {
      return (DateTimeParser)localObject;
    }
    throw new UnsupportedOperationException("Parsing is not supported");
  }
  






  public boolean canBuildFormatter()
  {
    return isFormatter(getFormatter());
  }
  





  public boolean canBuildPrinter()
  {
    return isPrinter(getFormatter());
  }
  





  public boolean canBuildParser()
  {
    return isParser(getFormatter());
  }
  




  public void clear()
  {
    iFormatter = null;
    iElementPairs.clear();
  }
  







  public DateTimeFormatterBuilder append(DateTimeFormatter paramDateTimeFormatter)
  {
    if (paramDateTimeFormatter == null) {
      throw new IllegalArgumentException("No formatter supplied");
    }
    return append0(paramDateTimeFormatter.getPrinter(), paramDateTimeFormatter.getParser());
  }
  







  public DateTimeFormatterBuilder append(DateTimePrinter paramDateTimePrinter)
  {
    checkPrinter(paramDateTimePrinter);
    return append0(paramDateTimePrinter, null);
  }
  







  public DateTimeFormatterBuilder append(DateTimeParser paramDateTimeParser)
  {
    checkParser(paramDateTimeParser);
    return append0(null, paramDateTimeParser);
  }
  







  public DateTimeFormatterBuilder append(DateTimePrinter paramDateTimePrinter, DateTimeParser paramDateTimeParser)
  {
    checkPrinter(paramDateTimePrinter);
    checkParser(paramDateTimeParser);
    return append0(paramDateTimePrinter, paramDateTimeParser);
  }
  
















  public DateTimeFormatterBuilder append(DateTimePrinter paramDateTimePrinter, DateTimeParser[] paramArrayOfDateTimeParser)
  {
    if (paramDateTimePrinter != null) {
      checkPrinter(paramDateTimePrinter);
    }
    if (paramArrayOfDateTimeParser == null) {
      throw new IllegalArgumentException("No parsers supplied");
    }
    int i = paramArrayOfDateTimeParser.length;
    if (i == 1) {
      if (paramArrayOfDateTimeParser[0] == null) {
        throw new IllegalArgumentException("No parser supplied");
      }
      return append0(paramDateTimePrinter, paramArrayOfDateTimeParser[0]);
    }
    
    DateTimeParser[] arrayOfDateTimeParser = new DateTimeParser[i];
    
    for (int j = 0; j < i - 1; j++) {
      if ((arrayOfDateTimeParser[j] =  paramArrayOfDateTimeParser[j]) == null)
      {
        throw new IllegalArgumentException("Incomplete parser array");
      }
    }
    arrayOfDateTimeParser[j] = paramArrayOfDateTimeParser[j];
    
    return append0(paramDateTimePrinter, new MatchingParser(arrayOfDateTimeParser));
  }
  






  public DateTimeFormatterBuilder appendOptional(DateTimeParser paramDateTimeParser)
  {
    checkParser(paramDateTimeParser);
    DateTimeParser[] arrayOfDateTimeParser = { paramDateTimeParser, null };
    return append0(null, new MatchingParser(arrayOfDateTimeParser));
  }
  





  private void checkParser(DateTimeParser paramDateTimeParser)
  {
    if (paramDateTimeParser == null) {
      throw new IllegalArgumentException("No parser supplied");
    }
  }
  




  private void checkPrinter(DateTimePrinter paramDateTimePrinter)
  {
    if (paramDateTimePrinter == null) {
      throw new IllegalArgumentException("No printer supplied");
    }
  }
  
  private DateTimeFormatterBuilder append0(Object paramObject) {
    iFormatter = null;
    
    iElementPairs.add(paramObject);
    iElementPairs.add(paramObject);
    return this;
  }
  
  private DateTimeFormatterBuilder append0(DateTimePrinter paramDateTimePrinter, DateTimeParser paramDateTimeParser)
  {
    iFormatter = null;
    iElementPairs.add(paramDateTimePrinter);
    iElementPairs.add(paramDateTimeParser);
    return this;
  }
  






  public DateTimeFormatterBuilder appendLiteral(char paramChar)
  {
    return append0(new CharacterLiteral(paramChar));
  }
  






  public DateTimeFormatterBuilder appendLiteral(String paramString)
  {
    if (paramString == null) {
      throw new IllegalArgumentException("Literal must not be null");
    }
    switch (paramString.length()) {
    case 0: 
      return this;
    case 1: 
      return append0(new CharacterLiteral(paramString.charAt(0)));
    }
    return append0(new StringLiteral(paramString));
  }
  












  public DateTimeFormatterBuilder appendDecimal(DateTimeFieldType paramDateTimeFieldType, int paramInt1, int paramInt2)
  {
    if (paramDateTimeFieldType == null) {
      throw new IllegalArgumentException("Field type must not be null");
    }
    if (paramInt2 < paramInt1) {
      paramInt2 = paramInt1;
    }
    if ((paramInt1 < 0) || (paramInt2 <= 0)) {
      throw new IllegalArgumentException();
    }
    if (paramInt1 <= 1) {
      return append0(new UnpaddedNumber(paramDateTimeFieldType, paramInt2, false));
    }
    return append0(new PaddedNumber(paramDateTimeFieldType, paramInt2, false, paramInt1));
  }
  













  public DateTimeFormatterBuilder appendFixedDecimal(DateTimeFieldType paramDateTimeFieldType, int paramInt)
  {
    if (paramDateTimeFieldType == null) {
      throw new IllegalArgumentException("Field type must not be null");
    }
    if (paramInt <= 0) {
      throw new IllegalArgumentException("Illegal number of digits: " + paramInt);
    }
    return append0(new FixedNumber(paramDateTimeFieldType, paramInt, false));
  }
  











  public DateTimeFormatterBuilder appendSignedDecimal(DateTimeFieldType paramDateTimeFieldType, int paramInt1, int paramInt2)
  {
    if (paramDateTimeFieldType == null) {
      throw new IllegalArgumentException("Field type must not be null");
    }
    if (paramInt2 < paramInt1) {
      paramInt2 = paramInt1;
    }
    if ((paramInt1 < 0) || (paramInt2 <= 0)) {
      throw new IllegalArgumentException();
    }
    if (paramInt1 <= 1) {
      return append0(new UnpaddedNumber(paramDateTimeFieldType, paramInt2, true));
    }
    return append0(new PaddedNumber(paramDateTimeFieldType, paramInt2, true, paramInt1));
  }
  













  public DateTimeFormatterBuilder appendFixedSignedDecimal(DateTimeFieldType paramDateTimeFieldType, int paramInt)
  {
    if (paramDateTimeFieldType == null) {
      throw new IllegalArgumentException("Field type must not be null");
    }
    if (paramInt <= 0) {
      throw new IllegalArgumentException("Illegal number of digits: " + paramInt);
    }
    return append0(new FixedNumber(paramDateTimeFieldType, paramInt, true));
  }
  







  public DateTimeFormatterBuilder appendText(DateTimeFieldType paramDateTimeFieldType)
  {
    if (paramDateTimeFieldType == null) {
      throw new IllegalArgumentException("Field type must not be null");
    }
    return append0(new TextField(paramDateTimeFieldType, false));
  }
  







  public DateTimeFormatterBuilder appendShortText(DateTimeFieldType paramDateTimeFieldType)
  {
    if (paramDateTimeFieldType == null) {
      throw new IllegalArgumentException("Field type must not be null");
    }
    return append0(new TextField(paramDateTimeFieldType, true));
  }
  













  public DateTimeFormatterBuilder appendFraction(DateTimeFieldType paramDateTimeFieldType, int paramInt1, int paramInt2)
  {
    if (paramDateTimeFieldType == null) {
      throw new IllegalArgumentException("Field type must not be null");
    }
    if (paramInt2 < paramInt1) {
      paramInt2 = paramInt1;
    }
    if ((paramInt1 < 0) || (paramInt2 <= 0)) {
      throw new IllegalArgumentException();
    }
    return append0(new Fraction(paramDateTimeFieldType, paramInt1, paramInt2));
  }
  




  public DateTimeFormatterBuilder appendFractionOfSecond(int paramInt1, int paramInt2)
  {
    return appendFraction(DateTimeFieldType.secondOfDay(), paramInt1, paramInt2);
  }
  




  public DateTimeFormatterBuilder appendFractionOfMinute(int paramInt1, int paramInt2)
  {
    return appendFraction(DateTimeFieldType.minuteOfDay(), paramInt1, paramInt2);
  }
  




  public DateTimeFormatterBuilder appendFractionOfHour(int paramInt1, int paramInt2)
  {
    return appendFraction(DateTimeFieldType.hourOfDay(), paramInt1, paramInt2);
  }
  




  public DateTimeFormatterBuilder appendFractionOfDay(int paramInt1, int paramInt2)
  {
    return appendFraction(DateTimeFieldType.dayOfYear(), paramInt1, paramInt2);
  }
  












  public DateTimeFormatterBuilder appendMillisOfSecond(int paramInt)
  {
    return appendDecimal(DateTimeFieldType.millisOfSecond(), paramInt, 3);
  }
  





  public DateTimeFormatterBuilder appendMillisOfDay(int paramInt)
  {
    return appendDecimal(DateTimeFieldType.millisOfDay(), paramInt, 8);
  }
  





  public DateTimeFormatterBuilder appendSecondOfMinute(int paramInt)
  {
    return appendDecimal(DateTimeFieldType.secondOfMinute(), paramInt, 2);
  }
  





  public DateTimeFormatterBuilder appendSecondOfDay(int paramInt)
  {
    return appendDecimal(DateTimeFieldType.secondOfDay(), paramInt, 5);
  }
  





  public DateTimeFormatterBuilder appendMinuteOfHour(int paramInt)
  {
    return appendDecimal(DateTimeFieldType.minuteOfHour(), paramInt, 2);
  }
  





  public DateTimeFormatterBuilder appendMinuteOfDay(int paramInt)
  {
    return appendDecimal(DateTimeFieldType.minuteOfDay(), paramInt, 4);
  }
  





  public DateTimeFormatterBuilder appendHourOfDay(int paramInt)
  {
    return appendDecimal(DateTimeFieldType.hourOfDay(), paramInt, 2);
  }
  





  public DateTimeFormatterBuilder appendClockhourOfDay(int paramInt)
  {
    return appendDecimal(DateTimeFieldType.clockhourOfDay(), paramInt, 2);
  }
  





  public DateTimeFormatterBuilder appendHourOfHalfday(int paramInt)
  {
    return appendDecimal(DateTimeFieldType.hourOfHalfday(), paramInt, 2);
  }
  





  public DateTimeFormatterBuilder appendClockhourOfHalfday(int paramInt)
  {
    return appendDecimal(DateTimeFieldType.clockhourOfHalfday(), paramInt, 2);
  }
  





  public DateTimeFormatterBuilder appendDayOfWeek(int paramInt)
  {
    return appendDecimal(DateTimeFieldType.dayOfWeek(), paramInt, 1);
  }
  





  public DateTimeFormatterBuilder appendDayOfMonth(int paramInt)
  {
    return appendDecimal(DateTimeFieldType.dayOfMonth(), paramInt, 2);
  }
  





  public DateTimeFormatterBuilder appendDayOfYear(int paramInt)
  {
    return appendDecimal(DateTimeFieldType.dayOfYear(), paramInt, 3);
  }
  





  public DateTimeFormatterBuilder appendWeekOfWeekyear(int paramInt)
  {
    return appendDecimal(DateTimeFieldType.weekOfWeekyear(), paramInt, 2);
  }
  







  public DateTimeFormatterBuilder appendWeekyear(int paramInt1, int paramInt2)
  {
    return appendSignedDecimal(DateTimeFieldType.weekyear(), paramInt1, paramInt2);
  }
  





  public DateTimeFormatterBuilder appendMonthOfYear(int paramInt)
  {
    return appendDecimal(DateTimeFieldType.monthOfYear(), paramInt, 2);
  }
  







  public DateTimeFormatterBuilder appendYear(int paramInt1, int paramInt2)
  {
    return appendSignedDecimal(DateTimeFieldType.year(), paramInt1, paramInt2);
  }
  

















  public DateTimeFormatterBuilder appendTwoDigitYear(int paramInt)
  {
    return appendTwoDigitYear(paramInt, false);
  }
  













  public DateTimeFormatterBuilder appendTwoDigitYear(int paramInt, boolean paramBoolean)
  {
    return append0(new TwoDigitYear(DateTimeFieldType.year(), paramInt, paramBoolean));
  }
  

















  public DateTimeFormatterBuilder appendTwoDigitWeekyear(int paramInt)
  {
    return appendTwoDigitWeekyear(paramInt, false);
  }
  













  public DateTimeFormatterBuilder appendTwoDigitWeekyear(int paramInt, boolean paramBoolean)
  {
    return append0(new TwoDigitYear(DateTimeFieldType.weekyear(), paramInt, paramBoolean));
  }
  







  public DateTimeFormatterBuilder appendYearOfEra(int paramInt1, int paramInt2)
  {
    return appendDecimal(DateTimeFieldType.yearOfEra(), paramInt1, paramInt2);
  }
  







  public DateTimeFormatterBuilder appendYearOfCentury(int paramInt1, int paramInt2)
  {
    return appendDecimal(DateTimeFieldType.yearOfCentury(), paramInt1, paramInt2);
  }
  







  public DateTimeFormatterBuilder appendCenturyOfEra(int paramInt1, int paramInt2)
  {
    return appendSignedDecimal(DateTimeFieldType.centuryOfEra(), paramInt1, paramInt2);
  }
  





  public DateTimeFormatterBuilder appendHalfdayOfDayText()
  {
    return appendText(DateTimeFieldType.halfdayOfDay());
  }
  





  public DateTimeFormatterBuilder appendDayOfWeekText()
  {
    return appendText(DateTimeFieldType.dayOfWeek());
  }
  






  public DateTimeFormatterBuilder appendDayOfWeekShortText()
  {
    return appendShortText(DateTimeFieldType.dayOfWeek());
  }
  






  public DateTimeFormatterBuilder appendMonthOfYearText()
  {
    return appendText(DateTimeFieldType.monthOfYear());
  }
  





  public DateTimeFormatterBuilder appendMonthOfYearShortText()
  {
    return appendShortText(DateTimeFieldType.monthOfYear());
  }
  





  public DateTimeFormatterBuilder appendEraText()
  {
    return appendText(DateTimeFieldType.era());
  }
  






  public DateTimeFormatterBuilder appendTimeZoneName()
  {
    return append0(new TimeZoneName(0), null);
  }
  






  public DateTimeFormatterBuilder appendTimeZoneShortName()
  {
    return append0(new TimeZoneName(1), null);
  }
  





  public DateTimeFormatterBuilder appendTimeZoneId()
  {
    return append0(new TimeZoneName(2), null);
  }
  















  public DateTimeFormatterBuilder appendTimeZoneOffset(String paramString, boolean paramBoolean, int paramInt1, int paramInt2)
  {
    return append0(new TimeZoneOffset(paramString, paramBoolean, paramInt1, paramInt2));
  }
  









  public DateTimeFormatterBuilder appendPattern(String paramString)
  {
    DateTimeFormat.appendPatternTo(this, paramString);
    return this;
  }
  
  private Object getFormatter()
  {
    Object localObject1 = iFormatter;
    
    if (localObject1 == null) {
      if (iElementPairs.size() == 2) {
        Object localObject2 = iElementPairs.get(0);
        Object localObject3 = iElementPairs.get(1);
        
        if (localObject2 != null) {
          if ((localObject2 == localObject3) || (localObject3 == null)) {
            localObject1 = localObject2;
          }
        } else {
          localObject1 = localObject3;
        }
      }
      
      if (localObject1 == null) {
        localObject1 = new Composite(iElementPairs);
      }
      
      iFormatter = localObject1;
    }
    
    return localObject1;
  }
  
  private boolean isPrinter(Object paramObject) {
    if ((paramObject instanceof DateTimePrinter)) {
      if ((paramObject instanceof Composite)) {
        return ((Composite)paramObject).isPrinter();
      }
      return true;
    }
    return false;
  }
  
  private boolean isParser(Object paramObject) {
    if ((paramObject instanceof DateTimeParser)) {
      if ((paramObject instanceof Composite)) {
        return ((Composite)paramObject).isParser();
      }
      return true;
    }
    return false;
  }
  
  private boolean isFormatter(Object paramObject) {
    return (isPrinter(paramObject)) || (isParser(paramObject));
  }
  
  static void appendUnknownString(StringBuffer paramStringBuffer, int paramInt) {
    int i = paramInt; for (;;) { i--; if (i < 0) break;
      paramStringBuffer.append(65533);
    }
  }
  
  static void printUnknownString(Writer paramWriter, int paramInt) throws IOException {
    int i = paramInt; for (;;) { i--; if (i < 0) break;
      paramWriter.write(65533);
    }
  }
  

  static class CharacterLiteral
    implements DateTimePrinter, DateTimeParser
  {
    private final char iValue;
    
    CharacterLiteral(char paramChar)
    {
      iValue = paramChar;
    }
    
    public int estimatePrintedLength() {
      return 1;
    }
    

    public void printTo(StringBuffer paramStringBuffer, long paramLong, Chronology paramChronology, int paramInt, DateTimeZone paramDateTimeZone, Locale paramLocale)
    {
      paramStringBuffer.append(iValue);
    }
    
    public void printTo(Writer paramWriter, long paramLong, Chronology paramChronology, int paramInt, DateTimeZone paramDateTimeZone, Locale paramLocale)
      throws IOException
    {
      paramWriter.write(iValue);
    }
    
    public void printTo(StringBuffer paramStringBuffer, ReadablePartial paramReadablePartial, Locale paramLocale) {
      paramStringBuffer.append(iValue);
    }
    
    public void printTo(Writer paramWriter, ReadablePartial paramReadablePartial, Locale paramLocale) throws IOException {
      paramWriter.write(iValue);
    }
    
    public int estimateParsedLength() {
      return 1;
    }
    
    public int parseInto(DateTimeParserBucket paramDateTimeParserBucket, String paramString, int paramInt) {
      if (paramInt >= paramString.length()) {
        return paramInt ^ 0xFFFFFFFF;
      }
      
      char c1 = paramString.charAt(paramInt);
      char c2 = iValue;
      
      if (c1 != c2) {
        c1 = Character.toUpperCase(c1);
        c2 = Character.toUpperCase(c2);
        if (c1 != c2) {
          c1 = Character.toLowerCase(c1);
          c2 = Character.toLowerCase(c2);
          if (c1 != c2) {
            return paramInt ^ 0xFFFFFFFF;
          }
        }
      }
      
      return paramInt + 1;
    }
  }
  

  static class StringLiteral
    implements DateTimePrinter, DateTimeParser
  {
    private final String iValue;
    
    StringLiteral(String paramString)
    {
      iValue = paramString;
    }
    
    public int estimatePrintedLength() {
      return iValue.length();
    }
    

    public void printTo(StringBuffer paramStringBuffer, long paramLong, Chronology paramChronology, int paramInt, DateTimeZone paramDateTimeZone, Locale paramLocale)
    {
      paramStringBuffer.append(iValue);
    }
    
    public void printTo(Writer paramWriter, long paramLong, Chronology paramChronology, int paramInt, DateTimeZone paramDateTimeZone, Locale paramLocale)
      throws IOException
    {
      paramWriter.write(iValue);
    }
    
    public void printTo(StringBuffer paramStringBuffer, ReadablePartial paramReadablePartial, Locale paramLocale) {
      paramStringBuffer.append(iValue);
    }
    
    public void printTo(Writer paramWriter, ReadablePartial paramReadablePartial, Locale paramLocale) throws IOException {
      paramWriter.write(iValue);
    }
    
    public int estimateParsedLength() {
      return iValue.length();
    }
    
    public int parseInto(DateTimeParserBucket paramDateTimeParserBucket, String paramString, int paramInt) {
      if (paramString.regionMatches(true, paramInt, iValue, 0, iValue.length())) {
        return paramInt + iValue.length();
      }
      return paramInt ^ 0xFFFFFFFF;
    }
  }
  

  static abstract class NumberFormatter
    implements DateTimePrinter, DateTimeParser
  {
    protected final DateTimeFieldType iFieldType;
    protected final int iMaxParsedDigits;
    protected final boolean iSigned;
    
    NumberFormatter(DateTimeFieldType paramDateTimeFieldType, int paramInt, boolean paramBoolean)
    {
      iFieldType = paramDateTimeFieldType;
      iMaxParsedDigits = paramInt;
      iSigned = paramBoolean;
    }
    
    public int estimateParsedLength() {
      return iMaxParsedDigits;
    }
    
    public int parseInto(DateTimeParserBucket paramDateTimeParserBucket, String paramString, int paramInt) {
      int i = Math.min(iMaxParsedDigits, paramString.length() - paramInt);
      
      int j = 0;
      int k = 0;
      int m; while (k < i) {
        m = paramString.charAt(paramInt + k);
        if ((k == 0) && ((m == 45) || (m == 43)) && (iSigned)) {
          j = m == 45 ? 1 : 0;
          

          if ((k + 1 >= i) || ((m = paramString.charAt(paramInt + k + 1)) < '0') || (m > 57)) {
            break;
          }
          


          if (j != 0) {
            k++;
          }
          else {
            paramInt++;
          }
          
          i = Math.min(i + 1, paramString.length() - paramInt);
        }
        else {
          if ((m < 48) || (m > 57)) {
            break;
          }
          k++;
        }
      }
      if (k == 0) {
        return paramInt ^ 0xFFFFFFFF;
      }
      

      if (k >= 9)
      {

        m = Integer.parseInt(paramString.substring(paramInt, paramInt += k));
      } else {
        int n = paramInt;
        if (j != 0) {
          n++;
        }
        try {
          m = paramString.charAt(n++) - '0';
        } catch (StringIndexOutOfBoundsException localStringIndexOutOfBoundsException) {
          return paramInt ^ 0xFFFFFFFF;
        }
        paramInt += k;
        while (n < paramInt) {
          m = (m << 3) + (m << 1) + paramString.charAt(n++) - 48;
        }
        if (j != 0) {
          m = -m;
        }
      }
      
      paramDateTimeParserBucket.saveField(iFieldType, m);
      return paramInt;
    }
  }
  

  static class UnpaddedNumber
    extends DateTimeFormatterBuilder.NumberFormatter
  {
    protected UnpaddedNumber(DateTimeFieldType paramDateTimeFieldType, int paramInt, boolean paramBoolean)
    {
      super(paramInt, paramBoolean);
    }
    
    public int estimatePrintedLength() {
      return iMaxParsedDigits;
    }
    
    public void printTo(StringBuffer paramStringBuffer, long paramLong, Chronology paramChronology, int paramInt, DateTimeZone paramDateTimeZone, Locale paramLocale)
    {
      try
      {
        DateTimeField localDateTimeField = iFieldType.getField(paramChronology);
        FormatUtils.appendUnpaddedInteger(paramStringBuffer, localDateTimeField.get(paramLong));
      } catch (RuntimeException localRuntimeException) {
        paramStringBuffer.append(65533);
      }
    }
    
    public void printTo(Writer paramWriter, long paramLong, Chronology paramChronology, int paramInt, DateTimeZone paramDateTimeZone, Locale paramLocale) throws IOException
    {
      try
      {
        DateTimeField localDateTimeField = iFieldType.getField(paramChronology);
        FormatUtils.writeUnpaddedInteger(paramWriter, localDateTimeField.get(paramLong));
      } catch (RuntimeException localRuntimeException) {
        paramWriter.write(65533);
      }
    }
    
    public void printTo(StringBuffer paramStringBuffer, ReadablePartial paramReadablePartial, Locale paramLocale) {
      if (paramReadablePartial.isSupported(iFieldType)) {
        try {
          FormatUtils.appendUnpaddedInteger(paramStringBuffer, paramReadablePartial.get(iFieldType));
        } catch (RuntimeException localRuntimeException) {
          paramStringBuffer.append(65533);
        }
      } else {
        paramStringBuffer.append(65533);
      }
    }
    
    public void printTo(Writer paramWriter, ReadablePartial paramReadablePartial, Locale paramLocale) throws IOException {
      if (paramReadablePartial.isSupported(iFieldType)) {
        try {
          FormatUtils.writeUnpaddedInteger(paramWriter, paramReadablePartial.get(iFieldType));
        } catch (RuntimeException localRuntimeException) {
          paramWriter.write(65533);
        }
      } else {
        paramWriter.write(65533);
      }
    }
  }
  

  static class PaddedNumber
    extends DateTimeFormatterBuilder.NumberFormatter
  {
    protected final int iMinPrintedDigits;
    
    protected PaddedNumber(DateTimeFieldType paramDateTimeFieldType, int paramInt1, boolean paramBoolean, int paramInt2)
    {
      super(paramInt1, paramBoolean);
      iMinPrintedDigits = paramInt2;
    }
    
    public int estimatePrintedLength() {
      return iMaxParsedDigits;
    }
    
    public void printTo(StringBuffer paramStringBuffer, long paramLong, Chronology paramChronology, int paramInt, DateTimeZone paramDateTimeZone, Locale paramLocale)
    {
      try
      {
        DateTimeField localDateTimeField = iFieldType.getField(paramChronology);
        FormatUtils.appendPaddedInteger(paramStringBuffer, localDateTimeField.get(paramLong), iMinPrintedDigits);
      } catch (RuntimeException localRuntimeException) {
        DateTimeFormatterBuilder.appendUnknownString(paramStringBuffer, iMinPrintedDigits);
      }
    }
    
    public void printTo(Writer paramWriter, long paramLong, Chronology paramChronology, int paramInt, DateTimeZone paramDateTimeZone, Locale paramLocale) throws IOException
    {
      try
      {
        DateTimeField localDateTimeField = iFieldType.getField(paramChronology);
        FormatUtils.writePaddedInteger(paramWriter, localDateTimeField.get(paramLong), iMinPrintedDigits);
      } catch (RuntimeException localRuntimeException) {
        DateTimeFormatterBuilder.printUnknownString(paramWriter, iMinPrintedDigits);
      }
    }
    
    public void printTo(StringBuffer paramStringBuffer, ReadablePartial paramReadablePartial, Locale paramLocale) {
      if (paramReadablePartial.isSupported(iFieldType)) {
        try {
          FormatUtils.appendPaddedInteger(paramStringBuffer, paramReadablePartial.get(iFieldType), iMinPrintedDigits);
        } catch (RuntimeException localRuntimeException) {
          DateTimeFormatterBuilder.appendUnknownString(paramStringBuffer, iMinPrintedDigits);
        }
      } else {
        DateTimeFormatterBuilder.appendUnknownString(paramStringBuffer, iMinPrintedDigits);
      }
    }
    
    public void printTo(Writer paramWriter, ReadablePartial paramReadablePartial, Locale paramLocale) throws IOException {
      if (paramReadablePartial.isSupported(iFieldType)) {
        try {
          FormatUtils.writePaddedInteger(paramWriter, paramReadablePartial.get(iFieldType), iMinPrintedDigits);
        } catch (RuntimeException localRuntimeException) {
          DateTimeFormatterBuilder.printUnknownString(paramWriter, iMinPrintedDigits);
        }
      } else {
        DateTimeFormatterBuilder.printUnknownString(paramWriter, iMinPrintedDigits);
      }
    }
  }
  
  static class FixedNumber extends DateTimeFormatterBuilder.PaddedNumber
  {
    protected FixedNumber(DateTimeFieldType paramDateTimeFieldType, int paramInt, boolean paramBoolean)
    {
      super(paramInt, paramBoolean, paramInt);
    }
    
    public int parseInto(DateTimeParserBucket paramDateTimeParserBucket, String paramString, int paramInt) {
      int i = super.parseInto(paramDateTimeParserBucket, paramString, paramInt);
      if (i < 0) {
        return i;
      }
      int j = paramInt + iMaxParsedDigits;
      if (i != j) {
        if (iSigned) {
          int k = paramString.charAt(paramInt);
          if ((k == 45) || (k == 43)) {
            j++;
          }
        }
        if (i > j)
        {
          return j + 1 ^ 0xFFFFFFFF; }
        if (i < j)
        {
          return i ^ 0xFFFFFFFF;
        }
      }
      return i;
    }
  }
  

  static class TwoDigitYear
    implements DateTimePrinter, DateTimeParser
  {
    private final DateTimeFieldType iType;
    
    private final int iPivot;
    
    private final boolean iLenientParse;
    
    TwoDigitYear(DateTimeFieldType paramDateTimeFieldType, int paramInt, boolean paramBoolean)
    {
      iType = paramDateTimeFieldType;
      iPivot = paramInt;
      iLenientParse = paramBoolean;
    }
    
    public int estimateParsedLength() {
      return iLenientParse ? 4 : 2;
    }
    
    public int parseInto(DateTimeParserBucket paramDateTimeParserBucket, String paramString, int paramInt) {
      int i = paramString.length() - paramInt;
      int i1;
      if (!iLenientParse) {
        i = Math.min(2, i);
        if (i < 2) {
          return paramInt ^ 0xFFFFFFFF;
        }
      } else {
        j = 0;
        k = 0;
        m = 0;
        while (m < i) {
          n = paramString.charAt(paramInt + m);
          if ((m == 0) && ((n == 45) || (n == 43))) {
            j = 1;
            k = n == 45 ? 1 : 0;
            if (k != 0) {
              m++;
            }
            else {
              paramInt++;
              i--;
            }
          }
          else {
            if ((n < 48) || (n > 57)) {
              break;
            }
            m++;
          }
        }
        if (m == 0) {
          return paramInt ^ 0xFFFFFFFF;
        }
        
        if ((j != 0) || (m != 2))
        {
          if (m >= 9)
          {

            n = Integer.parseInt(paramString.substring(paramInt, paramInt += m));
          } else {
            i1 = paramInt;
            if (k != 0) {
              i1++;
            }
            try {
              n = paramString.charAt(i1++) - '0';
            } catch (StringIndexOutOfBoundsException localStringIndexOutOfBoundsException) {
              return paramInt ^ 0xFFFFFFFF;
            }
            paramInt += m;
            while (i1 < paramInt) {
              n = (n << 3) + (n << 1) + paramString.charAt(i1++) - 48;
            }
            if (k != 0) {
              n = -n;
            }
          }
          
          paramDateTimeParserBucket.saveField(iType, n);
          return paramInt;
        }
      }
      

      int k = paramString.charAt(paramInt);
      if ((k < 48) || (k > 57)) {
        return paramInt ^ 0xFFFFFFFF;
      }
      int j = k - 48;
      k = paramString.charAt(paramInt + 1);
      if ((k < 48) || (k > 57)) {
        return paramInt ^ 0xFFFFFFFF;
      }
      j = (j << 3) + (j << 1) + k - 48;
      
      int m = iPivot;
      
      if (paramDateTimeParserBucket.getPivotYear() != null) {
        m = paramDateTimeParserBucket.getPivotYear().intValue();
      }
      
      int n = m - 50;
      

      if (n >= 0) {
        i1 = n % 100;
      } else {
        i1 = 99 + (n + 1) % 100;
      }
      
      j += n + (j < i1 ? 100 : 0) - i1;
      
      paramDateTimeParserBucket.saveField(iType, j);
      return paramInt + 2;
    }
    
    public int estimatePrintedLength() {
      return 2;
    }
    

    public void printTo(StringBuffer paramStringBuffer, long paramLong, Chronology paramChronology, int paramInt, DateTimeZone paramDateTimeZone, Locale paramLocale)
    {
      int i = getTwoDigitYear(paramLong, paramChronology);
      if (i < 0) {
        paramStringBuffer.append(65533);
        paramStringBuffer.append(65533);
      } else {
        FormatUtils.appendPaddedInteger(paramStringBuffer, i, 2);
      }
    }
    
    public void printTo(Writer paramWriter, long paramLong, Chronology paramChronology, int paramInt, DateTimeZone paramDateTimeZone, Locale paramLocale)
      throws IOException
    {
      int i = getTwoDigitYear(paramLong, paramChronology);
      if (i < 0) {
        paramWriter.write(65533);
        paramWriter.write(65533);
      } else {
        FormatUtils.writePaddedInteger(paramWriter, i, 2);
      }
    }
    
    private int getTwoDigitYear(long paramLong, Chronology paramChronology) {
      try {
        int i = iType.getField(paramChronology).get(paramLong);
        if (i < 0) {
          i = -i;
        }
        return i % 100;
      } catch (RuntimeException localRuntimeException) {}
      return -1;
    }
    
    public void printTo(StringBuffer paramStringBuffer, ReadablePartial paramReadablePartial, Locale paramLocale)
    {
      int i = getTwoDigitYear(paramReadablePartial);
      if (i < 0) {
        paramStringBuffer.append(65533);
        paramStringBuffer.append(65533);
      } else {
        FormatUtils.appendPaddedInteger(paramStringBuffer, i, 2);
      }
    }
    
    public void printTo(Writer paramWriter, ReadablePartial paramReadablePartial, Locale paramLocale) throws IOException {
      int i = getTwoDigitYear(paramReadablePartial);
      if (i < 0) {
        paramWriter.write(65533);
        paramWriter.write(65533);
      } else {
        FormatUtils.writePaddedInteger(paramWriter, i, 2);
      }
    }
    
    private int getTwoDigitYear(ReadablePartial paramReadablePartial) {
      if (paramReadablePartial.isSupported(iType)) {
        try {
          int i = paramReadablePartial.get(iType);
          if (i < 0) {
            i = -i;
          }
          return i % 100;
        } catch (RuntimeException localRuntimeException) {}
      }
      return -1;
    }
  }
  

  static class TextField
    implements DateTimePrinter, DateTimeParser
  {
    private static Map cParseCache = new HashMap();
    private final DateTimeFieldType iFieldType;
    private final boolean iShort;
    
    TextField(DateTimeFieldType paramDateTimeFieldType, boolean paramBoolean)
    {
      iFieldType = paramDateTimeFieldType;
      iShort = paramBoolean;
    }
    
    public int estimatePrintedLength() {
      return iShort ? 6 : 20;
    }
    
    public void printTo(StringBuffer paramStringBuffer, long paramLong, Chronology paramChronology, int paramInt, DateTimeZone paramDateTimeZone, Locale paramLocale)
    {
      try
      {
        paramStringBuffer.append(print(paramLong, paramChronology, paramLocale));
      } catch (RuntimeException localRuntimeException) {
        paramStringBuffer.append(65533);
      }
    }
    
    public void printTo(Writer paramWriter, long paramLong, Chronology paramChronology, int paramInt, DateTimeZone paramDateTimeZone, Locale paramLocale) throws IOException
    {
      try
      {
        paramWriter.write(print(paramLong, paramChronology, paramLocale));
      } catch (RuntimeException localRuntimeException) {
        paramWriter.write(65533);
      }
    }
    
    public void printTo(StringBuffer paramStringBuffer, ReadablePartial paramReadablePartial, Locale paramLocale) {
      try {
        paramStringBuffer.append(print(paramReadablePartial, paramLocale));
      } catch (RuntimeException localRuntimeException) {
        paramStringBuffer.append(65533);
      }
    }
    
    public void printTo(Writer paramWriter, ReadablePartial paramReadablePartial, Locale paramLocale) throws IOException {
      try {
        paramWriter.write(print(paramReadablePartial, paramLocale));
      } catch (RuntimeException localRuntimeException) {
        paramWriter.write(65533);
      }
    }
    
    private String print(long paramLong, Chronology paramChronology, Locale paramLocale) {
      DateTimeField localDateTimeField = iFieldType.getField(paramChronology);
      if (iShort) {
        return localDateTimeField.getAsShortText(paramLong, paramLocale);
      }
      return localDateTimeField.getAsText(paramLong, paramLocale);
    }
    
    private String print(ReadablePartial paramReadablePartial, Locale paramLocale)
    {
      if (paramReadablePartial.isSupported(iFieldType)) {
        DateTimeField localDateTimeField = iFieldType.getField(paramReadablePartial.getChronology());
        if (iShort) {
          return localDateTimeField.getAsShortText(paramReadablePartial, paramLocale);
        }
        return localDateTimeField.getAsText(paramReadablePartial, paramLocale);
      }
      
      return "�";
    }
    
    public int estimateParsedLength()
    {
      return estimatePrintedLength();
    }
    
    public int parseInto(DateTimeParserBucket paramDateTimeParserBucket, String paramString, int paramInt) {
      Locale localLocale = paramDateTimeParserBucket.getLocale();
      

      Object localObject1 = null;
      int i = 0;
      Object localObject3; synchronized (cParseCache) {
        localObject2 = (Map)cParseCache.get(localLocale);
        if (localObject2 == null) {
          localObject2 = new HashMap();
          cParseCache.put(localLocale, localObject2);
        }
        localObject3 = (Object[])((Map)localObject2).get(iFieldType);
        if (localObject3 == null) {
          localObject1 = new HashSet(32);
          MutableDateTime localMutableDateTime = new MutableDateTime(0L, DateTimeZone.UTC);
          MutableDateTime.Property localProperty = localMutableDateTime.property(iFieldType);
          int k = localProperty.getMinimumValueOverall();
          int m = localProperty.getMaximumValueOverall();
          if (m - k > 32) {
            return paramInt ^ 0xFFFFFFFF;
          }
          i = localProperty.getMaximumTextLength(localLocale);
          for (int n = k; n <= m; n++) {
            localProperty.set(n);
            ((Set)localObject1).add(localProperty.getAsShortText(localLocale));
            ((Set)localObject1).add(localProperty.getAsShortText(localLocale).toLowerCase(localLocale));
            ((Set)localObject1).add(localProperty.getAsShortText(localLocale).toUpperCase(localLocale));
            ((Set)localObject1).add(localProperty.getAsText(localLocale));
            ((Set)localObject1).add(localProperty.getAsText(localLocale).toLowerCase(localLocale));
            ((Set)localObject1).add(localProperty.getAsText(localLocale).toUpperCase(localLocale));
          }
          if (("en".equals(localLocale.getLanguage())) && (iFieldType == DateTimeFieldType.era()))
          {
            ((Set)localObject1).add("BCE");
            ((Set)localObject1).add("bce");
            ((Set)localObject1).add("CE");
            ((Set)localObject1).add("ce");
            i = 3;
          }
          localObject3 = new Object[] { localObject1, new Integer(i) };
          ((Map)localObject2).put(iFieldType, localObject3);
        } else {
          localObject1 = (Set)localObject3[0];
          i = ((Integer)localObject3[1]).intValue();
        }
      }
      
      int j = Math.min(paramString.length(), paramInt + i);
      for (Object localObject2 = j; localObject2 > paramInt; localObject2--) {
        localObject3 = paramString.substring(paramInt, localObject2);
        if (((Set)localObject1).contains(localObject3)) {
          paramDateTimeParserBucket.saveField(iFieldType, (String)localObject3, localLocale);
          return localObject2;
        }
      }
      return paramInt ^ 0xFFFFFFFF;
    }
  }
  

  static class Fraction
    implements DateTimePrinter, DateTimeParser
  {
    private final DateTimeFieldType iFieldType;
    protected int iMinDigits;
    protected int iMaxDigits;
    
    protected Fraction(DateTimeFieldType paramDateTimeFieldType, int paramInt1, int paramInt2)
    {
      iFieldType = paramDateTimeFieldType;
      
      if (paramInt2 > 18) {
        paramInt2 = 18;
      }
      iMinDigits = paramInt1;
      iMaxDigits = paramInt2;
    }
    
    public int estimatePrintedLength() {
      return iMaxDigits;
    }
    
    public void printTo(StringBuffer paramStringBuffer, long paramLong, Chronology paramChronology, int paramInt, DateTimeZone paramDateTimeZone, Locale paramLocale)
    {
      try
      {
        printTo(paramStringBuffer, null, paramLong, paramChronology);
      }
      catch (IOException localIOException) {}
    }
    

    public void printTo(Writer paramWriter, long paramLong, Chronology paramChronology, int paramInt, DateTimeZone paramDateTimeZone, Locale paramLocale)
      throws IOException
    {
      printTo(null, paramWriter, paramLong, paramChronology);
    }
    

    public void printTo(StringBuffer paramStringBuffer, ReadablePartial paramReadablePartial, Locale paramLocale)
    {
      long l = paramReadablePartial.getChronology().set(paramReadablePartial, 0L);
      try {
        printTo(paramStringBuffer, null, l, paramReadablePartial.getChronology());
      }
      catch (IOException localIOException) {}
    }
    

    public void printTo(Writer paramWriter, ReadablePartial paramReadablePartial, Locale paramLocale)
      throws IOException
    {
      long l = paramReadablePartial.getChronology().set(paramReadablePartial, 0L);
      printTo(null, paramWriter, l, paramReadablePartial.getChronology());
    }
    
    protected void printTo(StringBuffer paramStringBuffer, Writer paramWriter, long paramLong, Chronology paramChronology)
      throws IOException
    {
      DateTimeField localDateTimeField = iFieldType.getField(paramChronology);
      int i = iMinDigits;
      long l1;
      try
      {
        l1 = localDateTimeField.remainder(paramLong);
      } catch (RuntimeException localRuntimeException) {
        if (paramStringBuffer != null) {
          DateTimeFormatterBuilder.appendUnknownString(paramStringBuffer, i);
        } else {
          DateTimeFormatterBuilder.printUnknownString(paramWriter, i);
        }
        return;
      }
      
      if (l1 == 0L) {
        if (paramStringBuffer != null)
          for (;;) { i--; if (i < 0) break;
            paramStringBuffer.append('0');
          }
        for (;;) {
          i--; if (i < 0) break;
          paramWriter.write(48);
        }
        
        return;
      }
      

      long[] arrayOfLong = getFractionData(l1, localDateTimeField);
      long l2 = arrayOfLong[0];
      int j = (int)arrayOfLong[1];
      String str;
      if ((l2 & 0x7FFFFFFF) == l2) {
        str = Integer.toString((int)l2);
      } else {
        str = Long.toString(l2);
      }
      
      int k = str.length();
      int m = j;
      while (k < m) {
        if (paramStringBuffer != null) {
          paramStringBuffer.append('0');
        } else {
          paramWriter.write(48);
        }
        i--;
        m--;
      }
      
      if (i < m)
      {
        while ((i < m) && 
          (k > 1) && (str.charAt(k - 1) == '0'))
        {

          m--;
          k--;
        }
        if (k < str.length()) {
          if (paramStringBuffer != null) {
            for (n = 0; n < k; n++) {
              paramStringBuffer.append(str.charAt(n));
            }
          }
          for (int n = 0; n < k; n++) {
            paramWriter.write(str.charAt(n));
          }
          
          return;
        }
      }
      
      if (paramStringBuffer != null) {
        paramStringBuffer.append(str);
      } else {
        paramWriter.write(str);
      }
    }
    
    private long[] getFractionData(long paramLong, DateTimeField paramDateTimeField) {
      long l1 = paramDateTimeField.getDurationField().getUnitMillis();
      
      int i = iMaxDigits;
      long l2;
      for (;;) { switch (i) {
        default:  l2 = 1L; break;
        case 1:  l2 = 10L; break;
        case 2:  l2 = 100L; break;
        case 3:  l2 = 1000L; break;
        case 4:  l2 = 10000L; break;
        case 5:  l2 = 100000L; break;
        case 6:  l2 = 1000000L; break;
        case 7:  l2 = 10000000L; break;
        case 8:  l2 = 100000000L; break;
        case 9:  l2 = 1000000000L; break;
        case 10:  l2 = 10000000000L; break;
        case 11:  l2 = 100000000000L; break;
        case 12:  l2 = 1000000000000L; break;
        case 13:  l2 = 10000000000000L; break;
        case 14:  l2 = 100000000000000L; break;
        case 15:  l2 = 1000000000000000L; break;
        case 16:  l2 = 10000000000000000L; break;
        case 17:  l2 = 100000000000000000L; break;
        case 18:  l2 = 1000000000000000000L;
        }
        if (l1 * l2 / l2 == l1) {
          break;
        }
        
        i--;
      }
      
      return new long[] { paramLong * l2 / l1, i };
    }
    
    public int estimateParsedLength() {
      return iMaxDigits;
    }
    
    public int parseInto(DateTimeParserBucket paramDateTimeParserBucket, String paramString, int paramInt) {
      DateTimeField localDateTimeField = iFieldType.getField(paramDateTimeParserBucket.getChronology());
      
      int i = Math.min(iMaxDigits, paramString.length() - paramInt);
      
      long l1 = 0L;
      long l2 = localDateTimeField.getDurationField().getUnitMillis() * 10L;
      int j = 0;
      while (j < i) {
        int k = paramString.charAt(paramInt + j);
        if ((k < 48) || (k > 57)) {
          break;
        }
        j++;
        long l3 = l2 / 10L;
        l1 += (k - 48) * l3;
        l2 = l3;
      }
      
      l1 /= 10L;
      
      if (j == 0) {
        return paramInt ^ 0xFFFFFFFF;
      }
      
      if (l1 > 2147483647L) {
        return paramInt ^ 0xFFFFFFFF;
      }
      
      PreciseDateTimeField localPreciseDateTimeField = new PreciseDateTimeField(DateTimeFieldType.millisOfSecond(), MillisDurationField.INSTANCE, localDateTimeField.getDurationField());
      



      paramDateTimeParserBucket.saveField(localPreciseDateTimeField, (int)l1);
      
      return paramInt + j;
    }
  }
  

  static class TimeZoneOffset
    implements DateTimePrinter, DateTimeParser
  {
    private final String iZeroOffsetText;
    
    private final boolean iShowSeparators;
    
    private final int iMinFields;
    
    private final int iMaxFields;
    
    TimeZoneOffset(String paramString, boolean paramBoolean, int paramInt1, int paramInt2)
    {
      iZeroOffsetText = paramString;
      iShowSeparators = paramBoolean;
      if ((paramInt1 <= 0) || (paramInt2 < paramInt1)) {
        throw new IllegalArgumentException();
      }
      if (paramInt1 > 4) {
        paramInt1 = 4;
        paramInt2 = 4;
      }
      iMinFields = paramInt1;
      iMaxFields = paramInt2;
    }
    
    public int estimatePrintedLength() {
      int i = 1 + iMinFields << 1;
      if (iShowSeparators) {
        i += iMinFields - 1;
      }
      if ((iZeroOffsetText != null) && (iZeroOffsetText.length() > i)) {
        i = iZeroOffsetText.length();
      }
      return i;
    }
    

    public void printTo(StringBuffer paramStringBuffer, long paramLong, Chronology paramChronology, int paramInt, DateTimeZone paramDateTimeZone, Locale paramLocale)
    {
      if (paramDateTimeZone == null) {
        return;
      }
      if ((paramInt == 0) && (iZeroOffsetText != null)) {
        paramStringBuffer.append(iZeroOffsetText);
        return;
      }
      if (paramInt >= 0) {
        paramStringBuffer.append('+');
      } else {
        paramStringBuffer.append('-');
        paramInt = -paramInt;
      }
      
      int i = paramInt / 3600000;
      FormatUtils.appendPaddedInteger(paramStringBuffer, i, 2);
      if (iMaxFields == 1) {
        return;
      }
      paramInt -= i * 3600000;
      if ((paramInt == 0) && (iMinFields <= 1)) {
        return;
      }
      
      int j = paramInt / 60000;
      if (iShowSeparators) {
        paramStringBuffer.append(':');
      }
      FormatUtils.appendPaddedInteger(paramStringBuffer, j, 2);
      if (iMaxFields == 2) {
        return;
      }
      paramInt -= j * 60000;
      if ((paramInt == 0) && (iMinFields <= 2)) {
        return;
      }
      
      int k = paramInt / 1000;
      if (iShowSeparators) {
        paramStringBuffer.append(':');
      }
      FormatUtils.appendPaddedInteger(paramStringBuffer, k, 2);
      if (iMaxFields == 3) {
        return;
      }
      paramInt -= k * 1000;
      if ((paramInt == 0) && (iMinFields <= 3)) {
        return;
      }
      
      if (iShowSeparators) {
        paramStringBuffer.append('.');
      }
      FormatUtils.appendPaddedInteger(paramStringBuffer, paramInt, 3);
    }
    
    public void printTo(Writer paramWriter, long paramLong, Chronology paramChronology, int paramInt, DateTimeZone paramDateTimeZone, Locale paramLocale)
      throws IOException
    {
      if (paramDateTimeZone == null) {
        return;
      }
      if ((paramInt == 0) && (iZeroOffsetText != null)) {
        paramWriter.write(iZeroOffsetText);
        return;
      }
      if (paramInt >= 0) {
        paramWriter.write(43);
      } else {
        paramWriter.write(45);
        paramInt = -paramInt;
      }
      
      int i = paramInt / 3600000;
      FormatUtils.writePaddedInteger(paramWriter, i, 2);
      if (iMaxFields == 1) {
        return;
      }
      paramInt -= i * 3600000;
      if ((paramInt == 0) && (iMinFields == 1)) {
        return;
      }
      
      int j = paramInt / 60000;
      if (iShowSeparators) {
        paramWriter.write(58);
      }
      FormatUtils.writePaddedInteger(paramWriter, j, 2);
      if (iMaxFields == 2) {
        return;
      }
      paramInt -= j * 60000;
      if ((paramInt == 0) && (iMinFields == 2)) {
        return;
      }
      
      int k = paramInt / 1000;
      if (iShowSeparators) {
        paramWriter.write(58);
      }
      FormatUtils.writePaddedInteger(paramWriter, k, 2);
      if (iMaxFields == 3) {
        return;
      }
      paramInt -= k * 1000;
      if ((paramInt == 0) && (iMinFields == 3)) {
        return;
      }
      
      if (iShowSeparators) {
        paramWriter.write(46);
      }
      FormatUtils.writePaddedInteger(paramWriter, paramInt, 3);
    }
    

    public void printTo(StringBuffer paramStringBuffer, ReadablePartial paramReadablePartial, Locale paramLocale) {}
    
    public void printTo(Writer paramWriter, ReadablePartial paramReadablePartial, Locale paramLocale)
      throws IOException
    {}
    
    public int estimateParsedLength()
    {
      return estimatePrintedLength();
    }
    
    public int parseInto(DateTimeParserBucket paramDateTimeParserBucket, String paramString, int paramInt) {
      int i = paramString.length() - paramInt;
      
      int j;
      if (iZeroOffsetText != null) {
        if (iZeroOffsetText.length() == 0)
        {
          if (i > 0) {
            j = paramString.charAt(paramInt);
            if ((j == 45) || (j == 43)) {}
          }
          else
          {
            paramDateTimeParserBucket.setOffset(0);
            return paramInt;
          }
        } else if (paramString.regionMatches(true, paramInt, iZeroOffsetText, 0, iZeroOffsetText.length()))
        {
          paramDateTimeParserBucket.setOffset(0);
          return paramInt + iZeroOffsetText.length();
        }
      }
      


      if (i <= 1) {
        return paramInt ^ 0xFFFFFFFF;
      }
      

      int k = paramString.charAt(paramInt);
      if (k == 45) {
        j = 1;
      } else if (k == 43) {
        j = 0;
      } else {
        return paramInt ^ 0xFFFFFFFF;
      }
      
      i--;
      paramInt++;
      












      if (digitCount(paramString, paramInt, 2) < 2)
      {
        return paramInt ^ 0xFFFFFFFF;
      }
      


      int n = FormatUtils.parseTwoDigits(paramString, paramInt);
      if (n > 23) {
        return paramInt ^ 0xFFFFFFFF;
      }
      int m = n * 3600000;
      i -= 2;
      paramInt += 2;
      




      if (i > 0)
      {



        k = paramString.charAt(paramInt);
        int i1; if (k == 58) {
          i1 = 1;
          i--;
          paramInt++;
        } else { if ((k < 48) || (k > 57)) break label552;
          i1 = 0;
        }
        




        int i2 = digitCount(paramString, paramInt, 2);
        if ((i2 != 0) || (i1 != 0))
        {
          if (i2 < 2)
          {
            return paramInt ^ 0xFFFFFFFF;
          }
          
          int i3 = FormatUtils.parseTwoDigits(paramString, paramInt);
          if (i3 > 59) {
            return paramInt ^ 0xFFFFFFFF;
          }
          m += i3 * 60000;
          i -= 2;
          paramInt += 2;
          


          if (i > 0)
          {


            if (i1 != 0) {
              if (paramString.charAt(paramInt) == ':')
              {

                i--;
                paramInt++;
              }
            } else {
              i2 = digitCount(paramString, paramInt, 2);
              if ((i2 != 0) || (i1 != 0))
              {
                if (i2 < 2)
                {
                  return paramInt ^ 0xFFFFFFFF;
                }
                
                int i4 = FormatUtils.parseTwoDigits(paramString, paramInt);
                if (i4 > 59) {
                  return paramInt ^ 0xFFFFFFFF;
                }
                m += i4 * 1000;
                i -= 2;
                paramInt += 2;
                


                if (i > 0)
                {


                  if (i1 != 0) {
                    if ((paramString.charAt(paramInt) == '.') || (paramString.charAt(paramInt) == ','))
                    {

                      i--;
                      paramInt++;
                    }
                  } else {
                    i2 = digitCount(paramString, paramInt, 3);
                    if ((i2 != 0) || (i1 != 0))
                    {
                      if (i2 < 1)
                      {
                        return paramInt ^ 0xFFFFFFFF;
                      }
                      
                      m += (paramString.charAt(paramInt++) - '0') * 100;
                      if (i2 > 1) {
                        m += (paramString.charAt(paramInt++) - '0') * 10;
                        if (i2 > 2)
                          m += paramString.charAt(paramInt++) - '0';
                      }
                    }
                  } } } } } } }
      label552:
      paramDateTimeParserBucket.setOffset(j != 0 ? -m : m);
      return paramInt;
    }
    



    private int digitCount(String paramString, int paramInt1, int paramInt2)
    {
      int i = Math.min(paramString.length() - paramInt1, paramInt2);
      paramInt2 = 0;
      for (; i > 0; i--) {
        int j = paramString.charAt(paramInt1 + paramInt2);
        if ((j < 48) || (j > 57)) {
          break;
        }
        paramInt2++;
      }
      return paramInt2;
    }
  }
  

  static class TimeZoneName
    implements DateTimePrinter
  {
    static final int LONG_NAME = 0;
    
    static final int SHORT_NAME = 1;
    static final int ID = 2;
    private final int iType;
    
    TimeZoneName(int paramInt)
    {
      iType = paramInt;
    }
    
    public int estimatePrintedLength() {
      return iType == 1 ? 4 : 20;
    }
    

    public void printTo(StringBuffer paramStringBuffer, long paramLong, Chronology paramChronology, int paramInt, DateTimeZone paramDateTimeZone, Locale paramLocale)
    {
      paramStringBuffer.append(print(paramLong - paramInt, paramDateTimeZone, paramLocale));
    }
    
    public void printTo(Writer paramWriter, long paramLong, Chronology paramChronology, int paramInt, DateTimeZone paramDateTimeZone, Locale paramLocale)
      throws IOException
    {
      paramWriter.write(print(paramLong - paramInt, paramDateTimeZone, paramLocale));
    }
    
    private String print(long paramLong, DateTimeZone paramDateTimeZone, Locale paramLocale) {
      if (paramDateTimeZone == null) {
        return "";
      }
      switch (iType) {
      case 0: 
        return paramDateTimeZone.getName(paramLong, paramLocale);
      case 1: 
        return paramDateTimeZone.getShortName(paramLong, paramLocale);
      case 2: 
        return paramDateTimeZone.getID();
      }
      return "";
    }
    

    public void printTo(StringBuffer paramStringBuffer, ReadablePartial paramReadablePartial, Locale paramLocale) {}
    

    public void printTo(Writer paramWriter, ReadablePartial paramReadablePartial, Locale paramLocale)
      throws IOException
    {}
  }
  

  static class Composite
    implements DateTimePrinter, DateTimeParser
  {
    private final DateTimePrinter[] iPrinters;
    
    private final DateTimeParser[] iParsers;
    
    private final int iPrintedLengthEstimate;
    private final int iParsedLengthEstimate;
    
    Composite(List paramList)
    {
      ArrayList localArrayList1 = new ArrayList();
      ArrayList localArrayList2 = new ArrayList();
      
      decompose(paramList, localArrayList1, localArrayList2);
      int i;
      int j; int k; Object localObject; if (localArrayList1.size() <= 0) {
        iPrinters = null;
        iPrintedLengthEstimate = 0;
      } else {
        i = localArrayList1.size();
        iPrinters = new DateTimePrinter[i];
        j = 0;
        for (k = 0; k < i; k++) {
          localObject = (DateTimePrinter)localArrayList1.get(k);
          j += ((DateTimePrinter)localObject).estimatePrintedLength();
          iPrinters[k] = localObject;
        }
        iPrintedLengthEstimate = j;
      }
      
      if (localArrayList2.size() <= 0) {
        iParsers = null;
        iParsedLengthEstimate = 0;
      } else {
        i = localArrayList2.size();
        iParsers = new DateTimeParser[i];
        j = 0;
        for (k = 0; k < i; k++) {
          localObject = (DateTimeParser)localArrayList2.get(k);
          j += ((DateTimeParser)localObject).estimateParsedLength();
          iParsers[k] = localObject;
        }
        iParsedLengthEstimate = j;
      }
    }
    
    public int estimatePrintedLength() {
      return iPrintedLengthEstimate;
    }
    

    public void printTo(StringBuffer paramStringBuffer, long paramLong, Chronology paramChronology, int paramInt, DateTimeZone paramDateTimeZone, Locale paramLocale)
    {
      DateTimePrinter[] arrayOfDateTimePrinter = iPrinters;
      if (arrayOfDateTimePrinter == null) {
        throw new UnsupportedOperationException();
      }
      
      if (paramLocale == null)
      {
        paramLocale = Locale.getDefault();
      }
      
      int i = arrayOfDateTimePrinter.length;
      for (int j = 0; j < i; j++) {
        arrayOfDateTimePrinter[j].printTo(paramStringBuffer, paramLong, paramChronology, paramInt, paramDateTimeZone, paramLocale);
      }
    }
    
    public void printTo(Writer paramWriter, long paramLong, Chronology paramChronology, int paramInt, DateTimeZone paramDateTimeZone, Locale paramLocale)
      throws IOException
    {
      DateTimePrinter[] arrayOfDateTimePrinter = iPrinters;
      if (arrayOfDateTimePrinter == null) {
        throw new UnsupportedOperationException();
      }
      
      if (paramLocale == null)
      {
        paramLocale = Locale.getDefault();
      }
      
      int i = arrayOfDateTimePrinter.length;
      for (int j = 0; j < i; j++) {
        arrayOfDateTimePrinter[j].printTo(paramWriter, paramLong, paramChronology, paramInt, paramDateTimeZone, paramLocale);
      }
    }
    
    public void printTo(StringBuffer paramStringBuffer, ReadablePartial paramReadablePartial, Locale paramLocale) {
      DateTimePrinter[] arrayOfDateTimePrinter = iPrinters;
      if (arrayOfDateTimePrinter == null) {
        throw new UnsupportedOperationException();
      }
      
      if (paramLocale == null)
      {
        paramLocale = Locale.getDefault();
      }
      
      int i = arrayOfDateTimePrinter.length;
      for (int j = 0; j < i; j++) {
        arrayOfDateTimePrinter[j].printTo(paramStringBuffer, paramReadablePartial, paramLocale);
      }
    }
    
    public void printTo(Writer paramWriter, ReadablePartial paramReadablePartial, Locale paramLocale) throws IOException {
      DateTimePrinter[] arrayOfDateTimePrinter = iPrinters;
      if (arrayOfDateTimePrinter == null) {
        throw new UnsupportedOperationException();
      }
      
      if (paramLocale == null)
      {
        paramLocale = Locale.getDefault();
      }
      
      int i = arrayOfDateTimePrinter.length;
      for (int j = 0; j < i; j++) {
        arrayOfDateTimePrinter[j].printTo(paramWriter, paramReadablePartial, paramLocale);
      }
    }
    
    public int estimateParsedLength() {
      return iParsedLengthEstimate;
    }
    
    public int parseInto(DateTimeParserBucket paramDateTimeParserBucket, String paramString, int paramInt) {
      DateTimeParser[] arrayOfDateTimeParser = iParsers;
      if (arrayOfDateTimeParser == null) {
        throw new UnsupportedOperationException();
      }
      
      int i = arrayOfDateTimeParser.length;
      for (int j = 0; (j < i) && (paramInt >= 0); j++) {
        paramInt = arrayOfDateTimeParser[j].parseInto(paramDateTimeParserBucket, paramString, paramInt);
      }
      return paramInt;
    }
    
    boolean isPrinter() {
      return iPrinters != null;
    }
    
    boolean isParser() {
      return iParsers != null;
    }
    



    private void decompose(List paramList1, List paramList2, List paramList3)
    {
      int i = paramList1.size();
      for (int j = 0; j < i; j += 2) {
        Object localObject = paramList1.get(j);
        if ((localObject instanceof DateTimePrinter)) {
          if ((localObject instanceof Composite)) {
            addArrayToList(paramList2, iPrinters);
          } else {
            paramList2.add(localObject);
          }
        }
        
        localObject = paramList1.get(j + 1);
        if ((localObject instanceof DateTimeParser)) {
          if ((localObject instanceof Composite)) {
            addArrayToList(paramList3, iParsers);
          } else {
            paramList3.add(localObject);
          }
        }
      }
    }
    
    private void addArrayToList(List paramList, Object[] paramArrayOfObject) {
      if (paramArrayOfObject != null) {
        for (int i = 0; i < paramArrayOfObject.length; i++) {
          paramList.add(paramArrayOfObject[i]);
        }
      }
    }
  }
  

  static class MatchingParser
    implements DateTimeParser
  {
    private final DateTimeParser[] iParsers;
    private final int iParsedLengthEstimate;
    
    MatchingParser(DateTimeParser[] paramArrayOfDateTimeParser)
    {
      iParsers = paramArrayOfDateTimeParser;
      int i = 0;
      int j = paramArrayOfDateTimeParser.length; for (;;) { j--; if (j < 0) break;
        DateTimeParser localDateTimeParser = paramArrayOfDateTimeParser[j];
        if (localDateTimeParser != null) {
          int k = localDateTimeParser.estimateParsedLength();
          if (k > i) {
            i = k;
          }
        }
      }
      iParsedLengthEstimate = i;
    }
    
    public int estimateParsedLength() {
      return iParsedLengthEstimate;
    }
    
    public int parseInto(DateTimeParserBucket paramDateTimeParserBucket, String paramString, int paramInt) {
      DateTimeParser[] arrayOfDateTimeParser = iParsers;
      int i = arrayOfDateTimeParser.length;
      
      Object localObject1 = paramDateTimeParserBucket.saveState();
      int j = 0;
      
      int k = paramInt;
      Object localObject2 = null;
      
      int m = paramInt;
      
      for (int n = 0; n < i; n++) {
        DateTimeParser localDateTimeParser = arrayOfDateTimeParser[n];
        if (localDateTimeParser == null)
        {
          if (k <= paramInt) {
            return paramInt;
          }
          j = 1;
          break;
        }
        int i1 = localDateTimeParser.parseInto(paramDateTimeParserBucket, paramString, paramInt);
        if (i1 >= paramInt) {
          if (i1 > k) {
            if ((i1 >= paramString.length()) || (n + 1 >= i) || (arrayOfDateTimeParser[(n + 1)] == null))
            {



              return i1;
            }
            k = i1;
            localObject2 = paramDateTimeParserBucket.saveState();
          }
        }
        else if (i1 < 0) {
          i1 ^= 0xFFFFFFFF;
          if (i1 > m) {
            m = i1;
          }
        }
        
        paramDateTimeParserBucket.restoreState(localObject1);
      }
      
      if ((k > paramInt) || ((k == paramInt) && (j != 0)))
      {
        if (localObject2 != null) {
          paramDateTimeParserBucket.restoreState(localObject2);
        }
        return k;
      }
      
      return m ^ 0xFFFFFFFF;
    }
  }
}
