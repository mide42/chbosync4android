package com.funambol.org.joda.time.chrono;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.funambol.org.joda.time.Chronology;
import com.funambol.org.joda.time.DateTimeField;
import com.funambol.org.joda.time.DateTimeFieldType;
import com.funambol.org.joda.time.DateTimeZone;
import com.funambol.org.joda.time.field.DividedDateTimeField;
import com.funambol.org.joda.time.field.RemainderDateTimeField;









































public final class ISOChronology
  extends AssembledChronology
{
  private static final long serialVersionUID = -6212696554273812441L;
  private static final ISOChronology INSTANCE_UTC;
  private static final int FAST_CACHE_SIZE = 64;
  private static final ISOChronology[] cFastCache;
  private static final Map cCache = new HashMap();
  
  static { cFastCache = new ISOChronology[64];
    INSTANCE_UTC = new ISOChronology(GregorianChronology.getInstanceUTC());
    cCache.put(DateTimeZone.UTC, INSTANCE_UTC);
  }
  





  public static ISOChronology getInstanceUTC()
  {
    return INSTANCE_UTC;
  }
  




  public static ISOChronology getInstance()
  {
    return getInstance(DateTimeZone.getDefault());
  }
  





  public static ISOChronology getInstance(DateTimeZone paramDateTimeZone)
  {
    if (paramDateTimeZone == null) {
      paramDateTimeZone = DateTimeZone.getDefault();
    }
    int i = System.identityHashCode(paramDateTimeZone) & 0x3F;
    ISOChronology localISOChronology = cFastCache[i];
    if ((localISOChronology != null) && (localISOChronology.getZone() == paramDateTimeZone)) {
      return localISOChronology;
    }
    synchronized (cCache) {
      localISOChronology = (ISOChronology)cCache.get(paramDateTimeZone);
      if (localISOChronology == null) {
        localISOChronology = new ISOChronology(ZonedChronology.getInstance(INSTANCE_UTC, paramDateTimeZone));
        cCache.put(paramDateTimeZone, localISOChronology);
      }
    }
    cFastCache[i] = localISOChronology;
    return localISOChronology;
  }
  





  private ISOChronology(Chronology paramChronology)
  {
    super(paramChronology, null);
  }
  






  public Chronology withUTC()
  {
    return INSTANCE_UTC;
  }
  





  public Chronology withZone(DateTimeZone paramDateTimeZone)
  {
    if (paramDateTimeZone == null) {
      paramDateTimeZone = DateTimeZone.getDefault();
    }
    if (paramDateTimeZone == getZone()) {
      return this;
    }
    return getInstance(paramDateTimeZone);
  }
  






  public String toString()
  {
    String str = "ISOChronology";
    DateTimeZone localDateTimeZone = getZone();
    if (localDateTimeZone != null) {
      str = str + '[' + localDateTimeZone.getID() + ']';
    }
    return str;
  }
  
  protected void assemble(AssembledChronology.Fields paramFields) {
    if (getBase().getZone() == DateTimeZone.UTC)
    {
      centuryOfEra = new DividedDateTimeField(ISOYearOfEraDateTimeField.INSTANCE, DateTimeFieldType.centuryOfEra(), 100);
      
      yearOfCentury = new RemainderDateTimeField((DividedDateTimeField)centuryOfEra, DateTimeFieldType.yearOfCentury());
      
      weekyearOfCentury = new RemainderDateTimeField((DividedDateTimeField)centuryOfEra, DateTimeFieldType.weekyearOfCentury());
      

      centuries = centuryOfEra.getDurationField();
    }
  }
  






  public boolean equals(Object paramObject)
  {
    return super.equals(paramObject);
  }
  





  public int hashCode()
  {
    return "ISO".hashCode() * 11 + getZone().hashCode();
  }
  



  private Object writeReplace()
  {
    return new Stub(getZone());
  }
  
  private static final class Stub implements Serializable
  {
    private static final long serialVersionUID = -6212696554273812441L;
    private transient DateTimeZone iZone;
    
    Stub(DateTimeZone paramDateTimeZone) {
      iZone = paramDateTimeZone;
    }
    
    private Object readResolve() {
      return ISOChronology.getInstance(iZone);
    }
    
    private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
      paramObjectOutputStream.writeObject(iZone);
    }
    
    private void readObject(ObjectInputStream paramObjectInputStream)
      throws IOException, ClassNotFoundException
    {
      iZone = ((DateTimeZone)paramObjectInputStream.readObject());
    }
  }
}
