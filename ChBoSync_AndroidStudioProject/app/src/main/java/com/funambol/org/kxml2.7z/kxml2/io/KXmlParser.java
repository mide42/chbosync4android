package com.funambol.org.kxml2.io;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.Hashtable;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class KXmlParser
  implements XmlPullParser
{
  private Object location;
  private static final String UNEXPECTED_EOF = "Unexpected EOF";
  private static final String ILLEGAL_TYPE = "Wrong event type";
  private static final int LEGACY = 999;
  private static final int XML_DECL = 998;
  private String version;
  private Boolean standalone;
  private boolean processNsp;
  private boolean relaxed;
  private boolean normalize = true;
  private Hashtable entityMap;
  private int depth;
  private String[] elementStack = new String[16];
  private String[] nspStack = new String[8];
  private int[] nspCounts = new int[4];
  private Reader reader;
  private String encoding;
  private char[] srcBuf = new char[Runtime.getRuntime().freeMemory() >= 1048576L ? ' ' : ''];
  private int srcPos;
  private int srcCount;
  private int line;
  private int column;
  private char[] txtBuf = new char[''];
  private int txtPos;
  private int type;
  private boolean isWhitespace;
  private String namespace;
  private String prefix;
  private String name;
  private boolean degenerated;
  private int attributeCount;
  private String[] attributes = new String[16];
  private int stackMismatch = 0;
  private String error;
  private int[] peek = new int[2];
  private int peekCount;
  private boolean wasCR;
  private boolean unresolved;
  private boolean token;
  
  public KXmlParser() {}
  
  private final boolean isProp(String paramString1, boolean paramBoolean, String paramString2)
  {
    if (!paramString1.startsWith("http://xmlpull.org/v1/doc/")) {
      return false;
    }
    if (paramBoolean) {
      return paramString1.substring(42).equals(paramString2);
    }
    return paramString1.substring(40).equals(paramString2);
  }
  
  private final boolean adjustNsp()
    throws XmlPullParserException
  {
    boolean bool = false;
    String str1;
    int j;
    String str2;
    for (int i = 0; i < attributeCount << 2; i += 4)
    {
      str1 = attributes[(i + 2)];
      j = str1.indexOf(':');
      if (j != -1)
      {
        str2 = str1.substring(0, j);
        str1 = str1.substring(j + 1);
      }
      else
      {
        if (!str1.equals("xmlns")) {
          continue;
        }
        str2 = str1;
        str1 = null;
      }
      if (!str2.equals("xmlns"))
      {
        bool = true;
      }
      else
      {
        int tmp95_92 = depth;
        int[] tmp95_88 = nspCounts;
        int tmp97_96 = tmp95_88[tmp95_92];
        tmp95_88[tmp95_92] = (tmp97_96 + 1);
        int k = tmp97_96 << 1;
        nspStack = ensureCapacity(nspStack, k + 2);
        nspStack[k] = str1;
        nspStack[(k + 1)] = attributes[(i + 3)];
        if ((str1 != null) && (attributes[(i + 3)].equals(""))) {
          error("illegal empty namespace");
        }
        System.arraycopy(attributes, i + 4, attributes, i, (--attributeCount << 2) - i);
        i -= 4;
      }
    }
    if (bool) {
      for (i = (attributeCount << 2) - 4; i >= 0; i -= 4)
      {
        str1 = attributes[(i + 2)];
        j = str1.indexOf(':');
        if ((j == 0) && (!relaxed)) {
          throw new RuntimeException("illegal attribute name: " + str1 + " at " + this);
        }
        if (j != -1)
        {
          str2 = str1.substring(0, j);
          str1 = str1.substring(j + 1);
          String str3 = getNamespace(str2);
          if ((str3 == null) && (!relaxed)) {
            throw new RuntimeException("Undefined Prefix: " + str2 + " in " + this);
          }
          attributes[i] = str3;
          attributes[(i + 1)] = str2;
          attributes[(i + 2)] = str1;
        }
      }
    }
    i = name.indexOf(':');
    if (i == 0) {
      error("illegal tag name: " + name);
    }
    if (i != -1)
    {
      prefix = name.substring(0, i);
      name = name.substring(i + 1);
    }
    namespace = getNamespace(prefix);
    if (namespace == null)
    {
      if (prefix != null) {
        error("undefined prefix: " + prefix);
      }
      namespace = "";
    }
    return bool;
  }
  
  private final String[] ensureCapacity(String[] paramArrayOfString, int paramInt)
  {
    if (paramArrayOfString.length >= paramInt) {
      return paramArrayOfString;
    }
    String[] arrayOfString = new String[paramInt + 16];
    System.arraycopy(paramArrayOfString, 0, arrayOfString, 0, paramArrayOfString.length);
    return arrayOfString;
  }
  
  private final void error(String paramString)
    throws XmlPullParserException
  {
    if (relaxed)
    {
      if (error == null) {
        error = ("ERR: " + paramString);
      }
    }
    else {
      exception(paramString);
    }
  }
  
  private final void exception(String paramString)
    throws XmlPullParserException
  {
    throw new XmlPullParserException(paramString.substring(0, 100) + "\n", this, null);
  }
  
  private final void nextImpl()
    throws IOException, XmlPullParserException
  {
    if (reader == null) {
      exception("No Input specified");
    }
    if (type == 3) {
      depth -= 1;
    }
    do
    {
      attributeCount = -1;
      if (degenerated)
      {
        degenerated = false;
        type = 3;
        return;
      }
      int i;
      if (error != null)
      {
        for (i = 0; i < error.length(); i++) {
          push(error.charAt(i));
        }
        error = null;
        type = 9;
        return;
      }
      if ((relaxed) && ((stackMismatch > 0) || ((peek(0) == -1) && (depth > 0))))
      {
        i = depth - 1 << 2;
        type = 3;
        namespace = elementStack[i];
        prefix = elementStack[(i + 1)];
        name = elementStack[(i + 2)];
        if (stackMismatch != 1) {
          error = ("missing end tag /" + name + " inserted");
        }
        if (stackMismatch > 0) {
          stackMismatch -= 1;
        }
        return;
      }
      prefix = null;
      name = null;
      namespace = null;
      type = peekType();
      switch (type)
      {
      case 6: 
        pushEntity();
        return;
      case 2: 
        parseStartTag(false);
        return;
      case 3: 
        parseEndTag();
        return;
      case 1: 
        return;
      case 4: 
        pushText(60, !token);
        if ((depth == 0) && (isWhitespace)) {
          type = 7;
        }
        return;
      }
      type = parseLegacy(token);
    } while (type == 998);
  }
  
  private final int parseLegacy(boolean paramBoolean)
    throws IOException, XmlPullParserException
  {
    String str1 = "";
    int k = 0;
    read();
    int m = read();
    int i;
    int j;
    if (m == 63)
    {
      if (((peek(0) == 120) || (peek(0) == 88)) && ((peek(1) == 109) || (peek(1) == 77)))
      {
        if (paramBoolean)
        {
          push(peek(0));
          push(peek(1));
        }
        read();
        read();
        if (((peek(0) == 108) || (peek(0) == 76)) && (peek(1) <= 32))
        {
          if ((line != 1) || (column > 4)) {
            error("PI must not start with xml");
          }
          parseStartTag(true);
          if ((attributeCount < 1) || (!"version".equals(attributes[2]))) {
            error("version expected");
          }
          version = attributes[3];
          n = 1;
          if ((n < attributeCount) && ("encoding".equals(attributes[6])))
          {
            encoding = attributes[7];
            n++;
          }
          if ((n < attributeCount) && ("standalone".equals(attributes[(4 * n + 2)])))
          {
            String str2 = attributes[(3 + 4 * n)];
            if ("yes".equals(str2)) {
              standalone = new Boolean(true);
            } else if ("no".equals(str2)) {
              standalone = new Boolean(false);
            } else {
              error("illegal standalone value: " + str2);
            }
            n++;
          }
          if (n != attributeCount) {
            error("illegal xmldecl");
          }
          isWhitespace = true;
          txtPos = 0;
          return 998;
        }
      }
      i = 63;
      j = 8;
    }
    else if (m == 33)
    {
      if (peek(0) == 45)
      {
        j = 9;
        str1 = "--";
        i = 45;
      }
      else if (peek(0) == 91)
      {
        j = 5;
        str1 = "[CDATA[";
        i = 93;
        paramBoolean = true;
      }
      else
      {
        j = 10;
        str1 = "DOCTYPE";
        i = -1;
      }
    }
    else
    {
      error("illegal: <" + m);
      return 9;
    }
    for (int n = 0; n < str1.length(); n++) {
      read(str1.charAt(n));
    }
    if (j == 10)
    {
      parseDoctype(paramBoolean);
    }
    else
    {
      for (;;)
      {
        m = read();
        if (m == -1)
        {
          error("Unexpected EOF");
          return 9;
        }
        if (paramBoolean) {
          push(m);
        }
        if (((i == 63) || (m == i)) && (peek(0) == i) && (peek(1) == 62)) {
          break;
        }
        k = m;
      }
      if ((i == 45) && (k == 45)) {
        error("illegal comment delimiter: --->");
      }
      read();
      read();
      if ((paramBoolean) && (i != 63)) {
        txtPos -= 1;
      }
    }
    return j;
  }
  
  private final void parseDoctype(boolean paramBoolean)
    throws IOException, XmlPullParserException
  {
    int i = 1;
    int j = 0;
    for (;;)
    {
      int k = read();
      switch (k)
      {
      case -1: 
        error("Unexpected EOF");
        return;
      case 39: 
        j = j == 0 ? 1 : 0;
        break;
      case 60: 
        if (j == 0) {
          i++;
        }
        break;
      case 62: 
        if (j == 0)
        {
          i--;
          if (i == 0) {
            return;
          }
        }
        break;
      }
      if (paramBoolean) {
        push(k);
      }
    }
  }
  
  private final void parseEndTag()
    throws IOException, XmlPullParserException
  {
    read();
    read();
    name = readName();
    skip();
    read('>');
    int i = depth - 1 << 2;
    if (depth == 0)
    {
      error("element stack empty");
      type = 9;
      return;
    }
    if (!name.equals(elementStack[(i + 3)]))
    {
      error("expected: /" + elementStack[(i + 3)] + " read: " + name);
      for (int j = i; (j >= 0) && (!name.toLowerCase().equals(elementStack[(j + 3)].toLowerCase())); j -= 4) {
        stackMismatch += 1;
      }
      if (j < 0)
      {
        stackMismatch = 0;
        type = 9;
        return;
      }
    }
    namespace = elementStack[i];
    prefix = elementStack[(i + 1)];
    name = elementStack[(i + 2)];
  }
  
  private final int peekType()
    throws IOException
  {
    switch (peek(0))
    {
    case -1: 
      return 1;
    case 38: 
      return 6;
    case 60: 
      switch (peek(1))
      {
      case 47: 
        return 3;
      case 33: 
      case 63: 
        return 999;
      }
      return 2;
    }
    return 4;
  }
  
  private final String get(int paramInt)
  {
    return new String(txtBuf, paramInt, txtPos - paramInt);
  }
  
  private final void push(int paramInt)
  {
    isWhitespace &= paramInt <= 32;
    if (txtPos == txtBuf.length)
    {
      char[] arrayOfChar = new char[txtPos * 4 / 3 + 4];
      System.arraycopy(txtBuf, 0, arrayOfChar, 0, txtPos);
      txtBuf = arrayOfChar;
    }
    txtBuf[(txtPos++)] = ((char)paramInt);
  }
  
  private final void parseStartTag(boolean paramBoolean)
    throws IOException, XmlPullParserException
  {
    if (!paramBoolean) {
      read();
    }
    name = readName();
    attributeCount = 0;
    Object localObject;
    for (;;)
    {
      skip();
      i = peek(0);
      if (paramBoolean)
      {
        if (i == 63)
        {
          read();
          read('>');
        }
      }
      else
      {
        if (i == 47)
        {
          degenerated = true;
          read();
          skip();
          read('>');
          break;
        }
        if ((i == 62) && (!paramBoolean))
        {
          read();
          break;
        }
      }
      if (i == -1)
      {
        error("Unexpected EOF");
        return;
      }
      localObject = readName();
      if (((String)localObject).length() == 0)
      {
        error("attr name expected");
        break;
      }
      int j = attributeCount++ << 2;
      attributes = ensureCapacity(attributes, j + 4);
      attributes[(j++)] = "";
      attributes[(j++)] = null;
      attributes[(j++)] = localObject;
      skip();
      if (peek(0) != 61)
      {
        error("Attr.value missing f. " + (String)localObject);
        attributes[j] = "1";
      }
      else
      {
        read('=');
        skip();
        int k = peek(0);
        if ((k != 39) && (k != 34))
        {
          error("attr value delimiter missing!");
          k = 32;
        }
        else
        {
          read();
        }
        int m = txtPos;
        pushText(k, true);
        attributes[j] = get(m);
        txtPos = m;
        if (k != 32) {
          read();
        }
      }
    }
    int i = depth++ << 2;
    elementStack = ensureCapacity(elementStack, i + 4);
    elementStack[(i + 3)] = name;
    if (depth >= nspCounts.length)
    {
      localObject = new int[depth + 4];
      System.arraycopy(nspCounts, 0, localObject, 0, nspCounts.length);
      nspCounts = ((int[])localObject);
    }
    nspCounts[depth] = nspCounts[(depth - 1)];
    if (processNsp) {
      adjustNsp();
    } else {
      namespace = "";
    }
    elementStack[i] = namespace;
    elementStack[(i + 1)] = prefix;
    elementStack[(i + 2)] = name;
  }
  
  private final void pushEntity()
    throws IOException, XmlPullParserException
  {
    push(read());
    int i = txtPos;
    for (;;)
    {
      int j = read();
      if (j == 59) {
        break;
      }
      if ((j < 128) && ((j < 48) || (j > 57)) && ((j < 97) || (j > 122)) && ((j < 65) || (j > 90)) && (j != 95) && (j != 45) && (j != 35))
      {
        if (!relaxed) {
          error("unterminated entity ref");
        }
        if (j != -1) {
          push(j);
        }
        return;
      }
      push(j);
    }
    String str1 = get(i);
    txtPos = (i - 1);
    if ((token) && (type == 6)) {
      name = str1;
    }
    if (str1.charAt(0) == '#')
    {
      int k = str1.charAt(1) == 'x' ? Integer.parseInt(str1.substring(2), 16) : Integer.parseInt(str1.substring(1));
      push(k);
      return;
    }
    String str2 = (String)entityMap.get(str1);
    unresolved = (str2 == null);
    if (unresolved)
    {
      if (!token) {
        error("unresolved: &" + str1 + ";");
      }
    }
    else {
      for (int m = 0; m < str2.length(); m++) {
        push(str2.charAt(m));
      }
    }
  }
  
  private final void pushText(int paramInt, boolean paramBoolean)
    throws IOException, XmlPullParserException
  {
    int i = peek(0);
    int j = 0;
    while ((i != -1) && (i != paramInt) && ((paramInt != 32) || ((i > 32) && (i != 62))))
    {
      if (i == 38)
      {
        if (!paramBoolean) {
          break;
        }
        pushEntity();
      }
      else if ((i == 10) && (type == 2))
      {
        read();
        push(32);
      }
      else
      {
        push(read());
      }
      if ((i == 62) && (j >= 2) && (paramInt != 93)) {
        error("Illegal: ]]>");
      }
      if (i == 93) {
        j++;
      } else {
        j = 0;
      }
      i = peek(0);
    }
  }
  
  private final void read(char paramChar)
    throws IOException, XmlPullParserException
  {
    char c = read();
    if (c != paramChar) {
      error("expected: '" + paramChar + "' actual: '" + (char)c + "'");
    }
  }
  
  private final int read()
    throws IOException
  {
    int i;
    if (peekCount == 0)
    {
      i = peek(0);
    }
    else
    {
      i = peek[0];
      peek[0] = peek[1];
    }
    peekCount -= 1;
    column += 1;
    if (i == 10)
    {
      line += 1;
      column = 1;
    }
    return i;
  }
  
  private final int peek(int paramInt)
    throws IOException
  {
    while (paramInt >= peekCount)
    {
      int i;
      if (srcBuf.length <= 1)
      {
        i = reader.read();
      }
      else if (srcPos < srcCount)
      {
        i = srcBuf[(srcPos++)];
      }
      else
      {
        srcCount = reader.read(srcBuf, 0, srcBuf.length);
        if (srcCount <= 0) {
          i = -1;
        } else {
          i = srcBuf[0];
        }
        srcPos = 1;
      }
      if (normalize)
      {
        if (i == 13)
        {
          wasCR = true;
          peek[(peekCount++)] = 10;
        }
        else
        {
          if (i == 10)
          {
            if (!wasCR) {
              peek[(peekCount++)] = 10;
            }
          }
          else {
            peek[(peekCount++)] = i;
          }
          wasCR = false;
        }
      }
      else {
        peek[(peekCount++)] = i;
      }
    }
    return peek[paramInt];
  }
  
  private final String readName()
    throws IOException, XmlPullParserException
  {
    int i = txtPos;
    int j = peek(0);
    if (((j < 97) || (j > 122)) && ((j < 65) || (j > 90)) && (j != 95) && (j != 58) && (j < 192) && (!relaxed)) {
      error("name expected");
    }
    do
    {
      push(read());
      j = peek(0);
    } while (((j >= 97) && (j <= 122)) || ((j >= 65) && (j <= 90)) || ((j >= 48) && (j <= 57)) || (j == 95) || (j == 45) || (j == 58) || (j == 46) || (j >= 183));
    String str = get(i);
    txtPos = i;
    return str;
  }
  
  private final void skip()
    throws IOException
  {
    for (;;)
    {
      int i = peek(0);
      if ((i > 32) || (i == -1)) {
        break;
      }
      read();
    }
  }
  
  public void setInput(Reader paramReader)
    throws XmlPullParserException
  {
    reader = paramReader;
    line = 1;
    column = 0;
    type = 0;
    name = null;
    namespace = null;
    degenerated = false;
    attributeCount = -1;
    encoding = null;
    version = null;
    standalone = null;
    if (paramReader == null) {
      return;
    }
    srcPos = 0;
    srcCount = 0;
    peekCount = 0;
    depth = 0;
    entityMap = new Hashtable();
    entityMap.put("amp", "&");
    entityMap.put("apos", "'");
    entityMap.put("gt", ">");
    entityMap.put("lt", "<");
    entityMap.put("quot", "\"");
  }
  
  public void setInput(InputStream paramInputStream, String paramString)
    throws XmlPullParserException
  {
    srcPos = 0;
    srcCount = 0;
    String str1 = paramString;
    if (paramInputStream == null) {
      throw new IllegalArgumentException();
    }
    try
    {
      if (str1 == null)
      {
        i = 0;
        int j;
        while (srcCount < 4)
        {
          j = paramInputStream.read();
          if (j == -1) {
            break;
          }
          i = i << 8 | j;
          srcBuf[(srcCount++)] = ((char)j);
        }
        if (srcCount == 4) {
          switch (i)
          {
          case 65279: 
            str1 = "UTF-32BE";
            srcCount = 0;
            break;
          case -131072: 
            str1 = "UTF-32LE";
            srcCount = 0;
            break;
          case 60: 
            str1 = "UTF-32BE";
            srcBuf[0] = '<';
            srcCount = 1;
            break;
          case 1006632960: 
            str1 = "UTF-32LE";
            srcBuf[0] = '<';
            srcCount = 1;
            break;
          case 3932223: 
            str1 = "UTF-16BE";
            srcBuf[0] = '<';
            srcBuf[1] = '?';
            srcCount = 2;
            break;
          case 1006649088: 
            str1 = "UTF-16LE";
            srcBuf[0] = '<';
            srcBuf[1] = '?';
            srcCount = 2;
            break;
          case 1010792557: 
            for (;;)
            {
              j = paramInputStream.read();
              if (j == -1) {
                break;
              }
              srcBuf[(srcCount++)] = ((char)j);
              if (j == 62)
              {
                String str2 = new String(srcBuf, 0, srcCount);
                int k = str2.indexOf("encoding");
                if (k == -1) {
                  break;
                }
                while ((str2.charAt(k) != '"') && (str2.charAt(k) != '\'')) {
                  k++;
                }
                int m = str2.charAt(k++);
                int n = str2.indexOf(m, k);
                str1 = str2.substring(k, n);
                break;
              }
            }
          default: 
            if ((i & 0xFFFF0000) == -16842752)
            {
              str1 = "UTF-16BE";
              srcBuf[0] = ((char)(srcBuf[2] << '\b' | srcBuf[3]));
              srcCount = 1;
            }
            else if ((i & 0xFFFF0000) == -131072)
            {
              str1 = "UTF-16LE";
              srcBuf[0] = ((char)(srcBuf[3] << '\b' | srcBuf[2]));
              srcCount = 1;
            }
            else if ((i & 0xFF00) == -272908544)
            {
              str1 = "UTF-8";
              srcBuf[0] = srcBuf[3];
              srcCount = 1;
            }
            break;
          }
        }
      }
      if (str1 == null) {
        str1 = "UTF-8";
      }
      int i = srcCount;
      setInput(new InputStreamReader(paramInputStream, str1));
      encoding = paramString;
      srcCount = i;
    }
    catch (Exception localException)
    {
      throw new XmlPullParserException("Invalid stream or encoding: " + localException.toString(), this, localException);
    }
  }
  
  public boolean getFeature(String paramString)
  {
    if ("http://xmlpull.org/v1/doc/features.html#process-namespaces".equals(paramString)) {
      return processNsp;
    }
    if (isProp(paramString, false, "relaxed")) {
      return relaxed;
    }
    return false;
  }
  
  public String getInputEncoding()
  {
    return encoding;
  }
  
  public void defineEntityReplacementText(String paramString1, String paramString2)
    throws XmlPullParserException
  {
    if (entityMap == null) {
      throw new RuntimeException("entity replacement text must be defined after setInput!");
    }
    entityMap.put(paramString1, paramString2);
  }
  
  public Object getProperty(String paramString)
  {
    if (isProp(paramString, true, "xmldecl-version")) {
      return version;
    }
    if (isProp(paramString, true, "xmldecl-standalone")) {
      return standalone;
    }
    if (isProp(paramString, true, "location")) {
      return location != null ? location : reader.toString();
    }
    return null;
  }
  
  public int getNamespaceCount(int paramInt)
  {
    if (paramInt > depth) {
      throw new IndexOutOfBoundsException();
    }
    return nspCounts[paramInt];
  }
  
  public String getNamespacePrefix(int paramInt)
  {
    return nspStack[(paramInt << 1)];
  }
  
  public String getNamespaceUri(int paramInt)
  {
    return nspStack[((paramInt << 1) + 1)];
  }
  
  public String getNamespace(String paramString)
  {
    if ("xml".equals(paramString)) {
      return "http://www.w3.org/XML/1998/namespace";
    }
    if ("xmlns".equals(paramString)) {
      return "http://www.w3.org/2000/xmlns/";
    }
    for (int i = (getNamespaceCount(depth) << 1) - 2; i >= 0; i -= 2) {
      if (paramString == null)
      {
        if (nspStack[i] == null) {
          return nspStack[(i + 1)];
        }
      }
      else if (paramString.equals(nspStack[i])) {
        return nspStack[(i + 1)];
      }
    }
    return null;
  }
  
  public int getDepth()
  {
    return depth;
  }
  
  public String getPositionDescription()
  {
    StringBuffer localStringBuffer = new StringBuffer(type < XmlPullParser.TYPES.length ? XmlPullParser.TYPES[type] : "unknown");
    localStringBuffer.append(' ');
    if ((type == 2) || (type == 3))
    {
      if (degenerated) {
        localStringBuffer.append("(empty) ");
      }
      localStringBuffer.append('<');
      if (type == 3) {
        localStringBuffer.append('/');
      }
      if (prefix != null) {
        localStringBuffer.append("{" + namespace + "}" + prefix + ":");
      }
      localStringBuffer.append(name);
      int i = attributeCount << 2;
      for (int j = 0; j < i; j += 4)
      {
        localStringBuffer.append(' ');
        if (attributes[(j + 1)] != null) {
          localStringBuffer.append("{" + attributes[j] + "}" + attributes[(j + 1)] + ":");
        }
        localStringBuffer.append(attributes[(j + 2)] + "='" + attributes[(j + 3)] + "'");
      }
      localStringBuffer.append('>');
    }
    else if (type != 7)
    {
      if (type != 4)
      {
        localStringBuffer.append(getText());
      }
      else if (isWhitespace)
      {
        localStringBuffer.append("(whitespace)");
      }
      else
      {
        String str = getText();
        if (str.length() > 16) {
          str = str.substring(0, 16) + "...";
        }
        localStringBuffer.append(str);
      }
    }
    localStringBuffer.append("@" + line + ":" + column);
    if (location != null)
    {
      localStringBuffer.append(" in ");
      localStringBuffer.append(location);
    }
    else if (reader != null)
    {
      localStringBuffer.append(" in ");
      localStringBuffer.append(reader.toString());
    }
    return localStringBuffer.toString();
  }
  
  public int getLineNumber()
  {
    return line;
  }
  
  public int getColumnNumber()
  {
    return column;
  }
  
  public boolean isWhitespace()
    throws XmlPullParserException
  {
    if ((type != 4) && (type != 7) && (type != 5)) {
      exception("Wrong event type");
    }
    return isWhitespace;
  }
  
  public String getText()
  {
    return (type < 4) || ((type == 6) && (unresolved)) ? null : get(0);
  }
  
  public char[] getTextCharacters(int[] paramArrayOfInt)
  {
    if (type >= 4)
    {
      if (type == 6)
      {
        paramArrayOfInt[0] = 0;
        paramArrayOfInt[1] = name.length();
        return name.toCharArray();
      }
      paramArrayOfInt[0] = 0;
      paramArrayOfInt[1] = txtPos;
      return txtBuf;
    }
    paramArrayOfInt[0] = -1;
    paramArrayOfInt[1] = -1;
    return null;
  }
  
  public String getNamespace()
  {
    return namespace;
  }
  
  public String getName()
  {
    return name;
  }
  
  public String getPrefix()
  {
    return prefix;
  }
  
  public boolean isEmptyElementTag()
    throws XmlPullParserException
  {
    if (type != 2) {
      exception("Wrong event type");
    }
    return degenerated;
  }
  
  public int getAttributeCount()
  {
    return attributeCount;
  }
  
  public String getAttributeType(int paramInt)
  {
    return "CDATA";
  }
  
  public boolean isAttributeDefault(int paramInt)
  {
    return false;
  }
  
  public String getAttributeNamespace(int paramInt)
  {
    if (paramInt >= attributeCount) {
      throw new IndexOutOfBoundsException();
    }
    return attributes[(paramInt << 2)];
  }
  
  public String getAttributeName(int paramInt)
  {
    if (paramInt >= attributeCount) {
      throw new IndexOutOfBoundsException();
    }
    return attributes[((paramInt << 2) + 2)];
  }
  
  public String getAttributePrefix(int paramInt)
  {
    if (paramInt >= attributeCount) {
      throw new IndexOutOfBoundsException();
    }
    return attributes[((paramInt << 2) + 1)];
  }
  
  public String getAttributeValue(int paramInt)
  {
    if (paramInt >= attributeCount) {
      throw new IndexOutOfBoundsException();
    }
    return attributes[((paramInt << 2) + 3)];
  }
  
  public String getAttributeValue(String paramString1, String paramString2)
  {
    for (int i = (attributeCount << 2) - 4; i >= 0; i -= 4) {
      if ((attributes[(i + 2)].equals(paramString2)) && ((paramString1 == null) || (attributes[i].equals(paramString1)))) {
        return attributes[(i + 3)];
      }
    }
    return null;
  }
  
  public int getEventType()
    throws XmlPullParserException
  {
    return type;
  }
  
  public int next()
    throws XmlPullParserException, IOException
  {
    txtPos = 0;
    isWhitespace = true;
    int i = 9999;
    token = false;
    do
    {
      nextImpl();
      if (type < i) {
        i = type;
      }
    } while ((i > 6) || ((i >= 4) && (peekType() >= 4)));
    type = i;
    if (type > 4) {
      type = 4;
    }
    return type;
  }
  
  public int nextToken()
    throws XmlPullParserException, IOException
  {
    isWhitespace = true;
    txtPos = 0;
    token = true;
    nextImpl();
    return type;
  }
  
  public int nextTag()
    throws XmlPullParserException, IOException
  {
    next();
    if ((type == 4) && (isWhitespace)) {
      next();
    }
    if ((type != 3) && (type != 2)) {
      exception("unexpected type");
    }
    return type;
  }
  
  public void require(int paramInt, String paramString1, String paramString2)
    throws XmlPullParserException, IOException
  {
    if ((paramInt != type) || ((paramString1 != null) && (!paramString1.equals(getNamespace()))) || ((paramString2 != null) && (!paramString2.equals(getName())))) {
      exception("expected: " + XmlPullParser.TYPES[paramInt] + " {" + paramString1 + "}" + paramString2);
    }
  }
  
  public String nextText()
    throws XmlPullParserException, IOException
  {
    if (type != 2) {
      exception("precondition: START_TAG");
    }
    next();
    String str;
    if (type == 4)
    {
      str = getText();
      next();
    }
    else
    {
      str = "";
    }
    if (type != 3) {
      exception("END_TAG expected");
    }
    return str;
  }
  
  public void setFeature(String paramString, boolean paramBoolean)
    throws XmlPullParserException
  {
    if ("http://xmlpull.org/v1/doc/features.html#process-namespaces".equals(paramString)) {
      processNsp = paramBoolean;
    } else if (isProp(paramString, false, "relaxed")) {
      relaxed = paramBoolean;
    } else if ("NORMALIZE".equals(paramString)) {
      normalize = paramBoolean;
    } else {
      exception("unsupported feature: " + paramString);
    }
  }
  
  public void setProperty(String paramString, Object paramObject)
    throws XmlPullParserException
  {
    if (isProp(paramString, true, "location")) {
      location = paramObject;
    } else {
      throw new XmlPullParserException("unsupported property: " + paramString);
    }
  }
  
  public void skipSubTree()
    throws XmlPullParserException, IOException
  {
    require(2, null, null);
    int i = 1;
    while (i > 0)
    {
      int j = next();
      if (j == 3) {
        i--;
      } else if (j == 2) {
        i++;
      }
    }
  }
}
