package com.funambol.org.joda.time.base;

import java.io.Serializable;
import java.util.Locale;
import com.funambol.org.joda.time.Chronology;
import com.funambol.org.joda.time.DateTimeField;
import com.funambol.org.joda.time.DateTimeUtils;
import com.funambol.org.joda.time.ReadablePartial;
import com.funambol.org.joda.time.convert.ConverterManager;
import com.funambol.org.joda.time.convert.PartialConverter;
import com.funambol.org.joda.time.format.DateTimeFormat;
import com.funambol.org.joda.time.format.DateTimeFormatter;










































public abstract class BasePartial
  extends AbstractPartial
  implements ReadablePartial, Serializable
{
  private static final long serialVersionUID = 2353678632973660L;
  private Chronology iChronology;
  private int[] iValues;
  
  protected BasePartial()
  {
    this(DateTimeUtils.currentTimeMillis(), null);
  }
  









  protected BasePartial(Chronology paramChronology)
  {
    this(DateTimeUtils.currentTimeMillis(), paramChronology);
  }
  









  protected BasePartial(long paramLong)
  {
    this(paramLong, null);
  }
  











  protected BasePartial(long paramLong, Chronology paramChronology)
  {
    paramChronology = DateTimeUtils.getChronology(paramChronology);
    iChronology = paramChronology.withUTC();
    iValues = paramChronology.get(this, paramLong);
  }
  
















  protected BasePartial(Object paramObject, Chronology paramChronology)
  {
    PartialConverter localPartialConverter = ConverterManager.getInstance().getPartialConverter(paramObject);
    paramChronology = localPartialConverter.getChronology(paramObject, paramChronology);
    paramChronology = DateTimeUtils.getChronology(paramChronology);
    iChronology = paramChronology.withUTC();
    iValues = localPartialConverter.getPartialValues(this, paramObject, paramChronology);
  }
  


















  protected BasePartial(Object paramObject, Chronology paramChronology, DateTimeFormatter paramDateTimeFormatter)
  {
    PartialConverter localPartialConverter = ConverterManager.getInstance().getPartialConverter(paramObject);
    paramChronology = localPartialConverter.getChronology(paramObject, paramChronology);
    paramChronology = DateTimeUtils.getChronology(paramChronology);
    iChronology = paramChronology.withUTC();
    iValues = localPartialConverter.getPartialValues(this, paramObject, paramChronology, paramDateTimeFormatter);
  }
  













  protected BasePartial(int[] paramArrayOfInt, Chronology paramChronology)
  {
    paramChronology = DateTimeUtils.getChronology(paramChronology);
    iChronology = paramChronology.withUTC();
    paramChronology.validate(this, paramArrayOfInt);
    iValues = paramArrayOfInt;
  }
  








  protected BasePartial(BasePartial paramBasePartial, int[] paramArrayOfInt)
  {
    iChronology = iChronology;
    iValues = paramArrayOfInt;
  }
  









  protected BasePartial(BasePartial paramBasePartial, Chronology paramChronology)
  {
    iChronology = paramChronology.withUTC();
    iValues = iValues;
  }
  







  public int getValue(int paramInt)
  {
    return iValues[paramInt];
  }
  







  public int[] getValues()
  {
    return (int[])iValues.clone();
  }
  







  public Chronology getChronology()
  {
    return iChronology;
  }
  







  protected void setValue(int paramInt1, int paramInt2)
  {
    DateTimeField localDateTimeField = getField(paramInt1);
    iValues = localDateTimeField.set(this, paramInt1, iValues, paramInt2);
  }
  




  protected void setValues(int[] paramArrayOfInt)
  {
    getChronology().validate(this, paramArrayOfInt);
    iValues = paramArrayOfInt;
  }
  






  public String toString(String paramString)
  {
    if (paramString == null) {
      return toString();
    }
    return DateTimeFormat.forPattern(paramString).print(this);
  }
  





  public String toString(String paramString, Locale paramLocale)
    throws IllegalArgumentException
  {
    if (paramString == null) {
      return toString();
    }
    return DateTimeFormat.forPattern(paramString).withLocale(paramLocale).print(this);
  }
}
