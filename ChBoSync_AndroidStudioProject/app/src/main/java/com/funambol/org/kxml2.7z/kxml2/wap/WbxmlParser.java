package com.funambol.org.kxml2.wap;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.util.Hashtable;
import java.util.Vector;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class WbxmlParser
  implements XmlPullParser
{
  static final String HEX_DIGITS = "0123456789abcdef";
  public static final int WAP_EXTENSION = 64;
  private static final String UNEXPECTED_EOF = "Unexpected EOF";
  private static final String ILLEGAL_TYPE = "Wrong event type";
  private InputStream in;
  private int TAG_TABLE = 0;
  private int ATTR_START_TABLE = 1;
  private int ATTR_VALUE_TABLE = 2;
  private String[] attrStartTable;
  private String[] attrValueTable;
  private String[] tagTable;
  private byte[] stringTable;
  private Hashtable cacheStringTable = null;
  private boolean processNsp;
  private int depth;
  private String[] elementStack = new String[16];
  private String[] nspStack = new String[8];
  private int[] nspCounts = new int[4];
  private int attributeCount;
  private String[] attributes = new String[16];
  private int nextId = -2;
  private Vector tables = new Vector();
  private int version;
  private int publicIdentifierId;
  private String prefix;
  private String namespace;
  private String name;
  private String text;
  private Object wapExtensionData;
  private int wapCode;
  private int type;
  private boolean degenerated;
  private boolean isWhitespace;
  private String encoding;
  
  public WbxmlParser() {}
  
  public boolean getFeature(String paramString)
  {
    if ("http://xmlpull.org/v1/doc/features.html#process-namespaces".equals(paramString)) {
      return processNsp;
    }
    return false;
  }
  
  public String getInputEncoding()
  {
    return encoding;
  }
  
  public void defineEntityReplacementText(String paramString1, String paramString2)
    throws XmlPullParserException
  {}
  
  public Object getProperty(String paramString)
  {
    return null;
  }
  
  public int getNamespaceCount(int paramInt)
  {
    if (paramInt > depth) {
      throw new IndexOutOfBoundsException();
    }
    return nspCounts[paramInt];
  }
  
  public String getNamespacePrefix(int paramInt)
  {
    return nspStack[(paramInt << 1)];
  }
  
  public String getNamespaceUri(int paramInt)
  {
    return nspStack[((paramInt << 1) + 1)];
  }
  
  public String getNamespace(String paramString)
  {
    if ("xml".equals(paramString)) {
      return "http://www.w3.org/XML/1998/namespace";
    }
    if ("xmlns".equals(paramString)) {
      return "http://www.w3.org/2000/xmlns/";
    }
    for (int i = (getNamespaceCount(depth) << 1) - 2; i >= 0; i -= 2) {
      if (paramString == null)
      {
        if (nspStack[i] == null) {
          return nspStack[(i + 1)];
        }
      }
      else if (paramString.equals(nspStack[i])) {
        return nspStack[(i + 1)];
      }
    }
    return null;
  }
  
  public int getDepth()
  {
    return depth;
  }
  
  public String getPositionDescription()
  {
    StringBuffer localStringBuffer = new StringBuffer(type < XmlPullParser.TYPES.length ? XmlPullParser.TYPES[type] : "unknown");
    localStringBuffer.append(' ');
    if ((type == 2) || (type == 3))
    {
      if (degenerated) {
        localStringBuffer.append("(empty) ");
      }
      localStringBuffer.append('<');
      if (type == 3) {
        localStringBuffer.append('/');
      }
      if (prefix != null) {
        localStringBuffer.append("{" + namespace + "}" + prefix + ":");
      }
      localStringBuffer.append(name);
      int i = attributeCount << 2;
      for (int j = 0; j < i; j += 4)
      {
        localStringBuffer.append(' ');
        if (attributes[(j + 1)] != null) {
          localStringBuffer.append("{" + attributes[j] + "}" + attributes[(j + 1)] + ":");
        }
        localStringBuffer.append(attributes[(j + 2)] + "='" + attributes[(j + 3)] + "'");
      }
      localStringBuffer.append('>');
    }
    else if (type != 7)
    {
      if (type != 4)
      {
        localStringBuffer.append(getText());
      }
      else if (isWhitespace)
      {
        localStringBuffer.append("(whitespace)");
      }
      else
      {
        String str = getText();
        if (str.length() > 16) {
          str = str.substring(0, 16) + "...";
        }
        localStringBuffer.append(str);
      }
    }
    return localStringBuffer.toString();
  }
  
  public int getLineNumber()
  {
    return -1;
  }
  
  public int getColumnNumber()
  {
    return -1;
  }
  
  public boolean isWhitespace()
    throws XmlPullParserException
  {
    if ((type != 4) && (type != 7) && (type != 5)) {
      exception("Wrong event type");
    }
    return isWhitespace;
  }
  
  public String getText()
  {
    return text;
  }
  
  public char[] getTextCharacters(int[] paramArrayOfInt)
  {
    if (type >= 4)
    {
      paramArrayOfInt[0] = 0;
      paramArrayOfInt[1] = text.length();
      char[] arrayOfChar = new char[text.length()];
      text.getChars(0, text.length(), arrayOfChar, 0);
      return arrayOfChar;
    }
    paramArrayOfInt[0] = -1;
    paramArrayOfInt[1] = -1;
    return null;
  }
  
  public String getNamespace()
  {
    return namespace;
  }
  
  public String getName()
  {
    return name;
  }
  
  public String getPrefix()
  {
    return prefix;
  }
  
  public boolean isEmptyElementTag()
    throws XmlPullParserException
  {
    if (type != 2) {
      exception("Wrong event type");
    }
    return degenerated;
  }
  
  public int getAttributeCount()
  {
    return attributeCount;
  }
  
  public String getAttributeType(int paramInt)
  {
    return "CDATA";
  }
  
  public boolean isAttributeDefault(int paramInt)
  {
    return false;
  }
  
  public String getAttributeNamespace(int paramInt)
  {
    if (paramInt >= attributeCount) {
      throw new IndexOutOfBoundsException();
    }
    return attributes[(paramInt << 2)];
  }
  
  public String getAttributeName(int paramInt)
  {
    if (paramInt >= attributeCount) {
      throw new IndexOutOfBoundsException();
    }
    return attributes[((paramInt << 2) + 2)];
  }
  
  public String getAttributePrefix(int paramInt)
  {
    if (paramInt >= attributeCount) {
      throw new IndexOutOfBoundsException();
    }
    return attributes[((paramInt << 2) + 1)];
  }
  
  public String getAttributeValue(int paramInt)
  {
    if (paramInt >= attributeCount) {
      throw new IndexOutOfBoundsException();
    }
    return attributes[((paramInt << 2) + 3)];
  }
  
  public String getAttributeValue(String paramString1, String paramString2)
  {
    for (int i = (attributeCount << 2) - 4; i >= 0; i -= 4) {
      if ((attributes[(i + 2)].equals(paramString2)) && ((paramString1 == null) || (attributes[i].equals(paramString1)))) {
        return attributes[(i + 3)];
      }
    }
    return null;
  }
  
  public int getEventType()
    throws XmlPullParserException
  {
    return type;
  }
  
  public int next()
    throws XmlPullParserException, IOException
  {
    isWhitespace = true;
    int i = 9999;
    for (;;)
    {
      String str = text;
      nextImpl();
      if (type < i) {
        i = type;
      }
      if (i <= 5)
      {
        if (i < 4) {
          break;
        }
        if (str != null) {
          text = (str + text);
        }
        switch (peekId())
        {
        }
      }
    }
    type = i;
    if (type > 4) {
      type = 4;
    }
    return type;
  }
  
  public int nextToken()
    throws XmlPullParserException, IOException
  {
    isWhitespace = true;
    nextImpl();
    return type;
  }
  
  public int nextTag()
    throws XmlPullParserException, IOException
  {
    next();
    if ((type == 4) && (isWhitespace)) {
      next();
    }
    if ((type != 3) && (type != 2)) {
      exception("unexpected type");
    }
    return type;
  }
  
  public String nextText()
    throws XmlPullParserException, IOException
  {
    if (type != 2) {
      exception("precondition: START_TAG");
    }
    next();
    String str;
    if (type == 4)
    {
      str = getText();
      next();
    }
    else
    {
      str = "";
    }
    if (type != 3) {
      exception("END_TAG expected");
    }
    return str;
  }
  
  public void require(int paramInt, String paramString1, String paramString2)
    throws XmlPullParserException, IOException
  {
    if ((paramInt != type) || ((paramString1 != null) && (!paramString1.equals(getNamespace()))) || ((paramString2 != null) && (!paramString2.equals(getName())))) {
      exception("expected: " + (paramInt == 64 ? "WAP Ext." : new StringBuffer().append(XmlPullParser.TYPES[paramInt]).append(" {").append(paramString1).append("}").append(paramString2).toString()));
    }
  }
  
  public void setInput(Reader paramReader)
    throws XmlPullParserException
  {
    exception("InputStream required");
  }
  
  public void setInput(InputStream paramInputStream, String paramString)
    throws XmlPullParserException
  {
    in = paramInputStream;
    try
    {
      version = readByte();
      publicIdentifierId = readInt();
      if (publicIdentifierId == 0) {
        readInt();
      }
      int i = readInt();
      if (null == paramString) {
        switch (i)
        {
        case 4: 
          encoding = "ISO-8859-1";
          break;
        case 106: 
          encoding = "UTF-8";
          break;
        default: 
          throw new UnsupportedEncodingException("" + i);
        }
      } else {
        encoding = paramString;
      }
      int j = readInt();
      stringTable = new byte[j];
      int k = 0;
      while (k < j)
      {
        int m = paramInputStream.read(stringTable, k, j - k);
        if (m <= 0) {
          break;
        }
        k += m;
      }
      selectPage(0, true);
      selectPage(0, false);
    }
    catch (IOException localIOException)
    {
      exception("Illegal input format");
    }
  }
  
  public void setFeature(String paramString, boolean paramBoolean)
    throws XmlPullParserException
  {
    if ("http://xmlpull.org/v1/doc/features.html#process-namespaces".equals(paramString)) {
      processNsp = paramBoolean;
    } else {
      exception("unsupported feature: " + paramString);
    }
  }
  
  public void setProperty(String paramString, Object paramObject)
    throws XmlPullParserException
  {
    throw new XmlPullParserException("unsupported property: " + paramString);
  }
  
  private final boolean adjustNsp()
    throws XmlPullParserException
  {
    boolean bool = false;
    String str1;
    int j;
    String str2;
    for (int i = 0; i < attributeCount << 2; i += 4)
    {
      str1 = attributes[(i + 2)];
      j = str1.indexOf(':');
      if (j != -1)
      {
        str2 = str1.substring(0, j);
        str1 = str1.substring(j + 1);
      }
      else
      {
        if (!str1.equals("xmlns")) {
          continue;
        }
        str2 = str1;
        str1 = null;
      }
      if (!str2.equals("xmlns"))
      {
        bool = true;
      }
      else
      {
        int tmp95_92 = depth;
        int[] tmp95_88 = nspCounts;
        int tmp97_96 = tmp95_88[tmp95_92];
        tmp95_88[tmp95_92] = (tmp97_96 + 1);
        int k = tmp97_96 << 1;
        nspStack = ensureCapacity(nspStack, k + 2);
        nspStack[k] = str1;
        nspStack[(k + 1)] = attributes[(i + 3)];
        if ((str1 != null) && (attributes[(i + 3)].equals(""))) {
          exception("illegal empty namespace");
        }
        System.arraycopy(attributes, i + 4, attributes, i, (--attributeCount << 2) - i);
        i -= 4;
      }
    }
    if (bool) {
      for (i = (attributeCount << 2) - 4; i >= 0; i -= 4)
      {
        str1 = attributes[(i + 2)];
        j = str1.indexOf(':');
        if (j == 0) {
          throw new RuntimeException("illegal attribute name: " + str1 + " at " + this);
        }
        if (j != -1)
        {
          str2 = str1.substring(0, j);
          str1 = str1.substring(j + 1);
          String str3 = getNamespace(str2);
          if (str3 == null) {
            throw new RuntimeException("Undefined Prefix: " + str2 + " in " + this);
          }
          attributes[i] = str3;
          attributes[(i + 1)] = str2;
          attributes[(i + 2)] = str1;
          for (int m = (attributeCount << 2) - 4; m > i; m -= 4) {
            if ((str1.equals(attributes[(m + 2)])) && (str3.equals(attributes[m]))) {
              exception("Duplicate Attribute: {" + str3 + "}" + str1);
            }
          }
        }
      }
    }
    i = name.indexOf(':');
    if (i == 0)
    {
      exception("illegal tag name: " + name);
    }
    else if (i != -1)
    {
      prefix = name.substring(0, i);
      name = name.substring(i + 1);
    }
    namespace = getNamespace(prefix);
    if (namespace == null)
    {
      if (prefix != null) {
        exception("undefined prefix: " + prefix);
      }
      namespace = "";
    }
    return bool;
  }
  
  private final void setTable(int paramInt1, int paramInt2, String[] paramArrayOfString)
  {
    if (stringTable != null) {
      throw new RuntimeException("setXxxTable must be called before setInput!");
    }
    while (tables.size() < 3 * paramInt1 + 3) {
      tables.addElement(null);
    }
    tables.setElementAt(paramArrayOfString, paramInt1 * 3 + paramInt2);
  }
  
  private final void exception(String paramString)
    throws XmlPullParserException
  {
    throw new XmlPullParserException(paramString, this, null);
  }
  
  private void selectPage(int paramInt, boolean paramBoolean)
    throws XmlPullParserException
  {
    if ((tables.size() == 0) && (paramInt == 0)) {
      return;
    }
    if (paramInt * 3 > tables.size()) {
      exception("Code Page " + paramInt + " undefined!");
    }
    if (paramBoolean)
    {
      tagTable = ((String[])tables.elementAt(paramInt * 3 + TAG_TABLE));
    }
    else
    {
      attrStartTable = ((String[])tables.elementAt(paramInt * 3 + ATTR_START_TABLE));
      attrValueTable = ((String[])tables.elementAt(paramInt * 3 + ATTR_VALUE_TABLE));
    }
  }
  
  private final void nextImpl()
    throws IOException, XmlPullParserException
  {
    if (type == 3) {
      depth -= 1;
    }
    if (degenerated)
    {
      type = 3;
      degenerated = false;
      return;
    }
    text = null;
    prefix = null;
    name = null;
    for (int i = peekId(); i == 0; i = peekId())
    {
      nextId = -2;
      selectPage(readByte(), true);
    }
    nextId = -2;
    int j;
    switch (i)
    {
    case -1: 
      type = 1;
      break;
    case 1: 
      j = depth - 1 << 2;
      type = 3;
      namespace = elementStack[j];
      prefix = elementStack[(j + 1)];
      name = elementStack[(j + 2)];
      break;
    case 2: 
      type = 6;
      j = (char)readInt();
      text = ("" + j);
      name = ("#" + j);
      break;
    case 3: 
      type = 4;
      text = readStrI();
      break;
    case 64: 
    case 65: 
    case 66: 
    case 128: 
    case 129: 
    case 130: 
    case 192: 
    case 193: 
    case 194: 
    case 195: 
      type = 64;
      wapCode = i;
      wapExtensionData = parseWapExtension(i);
      break;
    case 67: 
      throw new RuntimeException("PI curr. not supp.");
    case 131: 
      type = 4;
      text = readStrT();
      break;
    default: 
      parseElement(i);
    }
  }
  
  public Object parseWapExtension(int paramInt)
    throws IOException, XmlPullParserException
  {
    switch (paramInt)
    {
    case 64: 
    case 65: 
    case 66: 
      return readStrI();
    case 128: 
    case 129: 
    case 130: 
      return new Integer(readInt());
    case 192: 
    case 193: 
    case 194: 
      return null;
    case 195: 
      int i = readInt();
      byte[] arrayOfByte = new byte[i];
      while (i > 0) {
        i -= in.read(arrayOfByte, arrayOfByte.length - i, i);
      }
      return arrayOfByte;
    }
    exception("illegal id: " + paramInt);
    return null;
  }
  
  public void readAttr()
    throws IOException, XmlPullParserException
  {
    int i = readByte();
    int j = 0;
    while (i != 1)
    {
      while (i == 0)
      {
        selectPage(readByte(), false);
        i = readByte();
      }
      String str = resolveId(attrStartTable, i);
      int k = str.indexOf('=');
      StringBuffer localStringBuffer;
      if (k == -1)
      {
        localStringBuffer = new StringBuffer();
      }
      else
      {
        localStringBuffer = new StringBuffer(str.substring(k + 1));
        str = str.substring(0, k);
      }
      for (i = readByte(); (i > 128) || (i == 0) || (i == 2) || (i == 3) || (i == 131) || ((i >= 64) && (i <= 66)) || ((i >= 128) && (i <= 130)); i = readByte()) {
        switch (i)
        {
        case 0: 
          selectPage(readByte(), false);
          break;
        case 2: 
          localStringBuffer.append((char)readInt());
          break;
        case 3: 
          localStringBuffer.append(readStrI());
          break;
        case 64: 
        case 65: 
        case 66: 
        case 128: 
        case 129: 
        case 130: 
        case 192: 
        case 193: 
        case 194: 
        case 195: 
          localStringBuffer.append(resolveWapExtension(i, parseWapExtension(i)));
          break;
        case 131: 
          localStringBuffer.append(readStrT());
          break;
        default: 
          localStringBuffer.append(resolveId(attrValueTable, i));
        }
      }
      attributes = ensureCapacity(attributes, j + 4);
      attributes[(j++)] = "";
      attributes[(j++)] = null;
      attributes[(j++)] = str;
      attributes[(j++)] = localStringBuffer.toString();
      attributeCount += 1;
    }
  }
  
  private int peekId()
    throws IOException
  {
    if (nextId == -2) {
      nextId = in.read();
    }
    return nextId;
  }
  
  protected String resolveWapExtension(int paramInt, Object paramObject)
  {
    if ((paramObject instanceof byte[]))
    {
      StringBuffer localStringBuffer = new StringBuffer();
      byte[] arrayOfByte = (byte[])paramObject;
      for (int i = 0; i < arrayOfByte.length; i++)
      {
        localStringBuffer.append("0123456789abcdef".charAt(arrayOfByte[i] >> 4 & 0xF));
        localStringBuffer.append("0123456789abcdef".charAt(arrayOfByte[i] & 0xF));
      }
      return localStringBuffer.toString();
    }
    return "$(" + paramObject + ")";
  }
  
  String resolveId(String[] paramArrayOfString, int paramInt)
    throws IOException
  {
    int i = (paramInt & 0x7F) - 5;
    if (i == -1)
    {
      wapCode = -1;
      return readStrT();
    }
    if ((i < 0) || (paramArrayOfString == null) || (i >= paramArrayOfString.length) || (paramArrayOfString[i] == null)) {
      throw new IOException("id " + paramInt + " undef.");
    }
    wapCode = (i + 5);
    return paramArrayOfString[i];
  }
  
  void parseElement(int paramInt)
    throws IOException, XmlPullParserException
  {
    type = 2;
    name = resolveId(tagTable, paramInt & 0x3F);
    attributeCount = 0;
    if ((paramInt & 0x80) != 0) {
      readAttr();
    }
    degenerated = ((paramInt & 0x40) == 0);
    int i = depth++ << 2;
    elementStack = ensureCapacity(elementStack, i + 4);
    elementStack[(i + 3)] = name;
    if (depth >= nspCounts.length)
    {
      int[] arrayOfInt = new int[depth + 4];
      System.arraycopy(nspCounts, 0, arrayOfInt, 0, nspCounts.length);
      nspCounts = arrayOfInt;
    }
    nspCounts[depth] = nspCounts[(depth - 1)];
    for (int j = attributeCount - 1; j > 0; j--) {
      for (int k = 0; k < j; k++) {
        if (getAttributeName(j).equals(getAttributeName(k))) {
          exception("Duplicate Attribute: " + getAttributeName(j));
        }
      }
    }
    if (processNsp) {
      adjustNsp();
    } else {
      namespace = "";
    }
    elementStack[i] = namespace;
    elementStack[(i + 1)] = prefix;
    elementStack[(i + 2)] = name;
  }
  
  private final String[] ensureCapacity(String[] paramArrayOfString, int paramInt)
  {
    if (paramArrayOfString.length >= paramInt) {
      return paramArrayOfString;
    }
    String[] arrayOfString = new String[paramInt + 16];
    System.arraycopy(paramArrayOfString, 0, arrayOfString, 0, paramArrayOfString.length);
    return arrayOfString;
  }
  
  int readByte()
    throws IOException
  {
    int i = in.read();
    if (i == -1) {
      throw new IOException("Unexpected EOF");
    }
    return i;
  }
  
  int readInt()
    throws IOException
  {
    int i = 0;
    int j;
    do
    {
      j = readByte();
      i = i << 7 | j & 0x7F;
    } while ((j & 0x80) != 0);
    return i;
  }
  
  String readStrI()
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    boolean bool = true;
    for (;;)
    {
      int i = in.read();
      if (i == 0) {
        break;
      }
      if (i == -1) {
        throw new IOException("Unexpected EOF");
      }
      if (i > 32) {
        bool = false;
      }
      localByteArrayOutputStream.write(i);
    }
    isWhitespace = bool;
    String str = new String(localByteArrayOutputStream.toByteArray(), encoding);
    localByteArrayOutputStream.close();
    return str;
  }
  
  String readStrT()
    throws IOException
  {
    int i = readInt();
    if (cacheStringTable == null) {
      cacheStringTable = new Hashtable();
    }
    String str = (String)cacheStringTable.get(new Integer(i));
    if (str == null)
    {
      for (int j = i; (j < stringTable.length) && (stringTable[j] != 0); j++) {}
      str = new String(stringTable, i, j - i, encoding);
      cacheStringTable.put(new Integer(i), str);
    }
    return str;
  }
  
  public void setTagTable(int paramInt, String[] paramArrayOfString)
  {
    setTable(paramInt, TAG_TABLE, paramArrayOfString);
  }
  
  public void setAttrStartTable(int paramInt, String[] paramArrayOfString)
  {
    setTable(paramInt, ATTR_START_TABLE, paramArrayOfString);
  }
  
  public void setAttrValueTable(int paramInt, String[] paramArrayOfString)
  {
    setTable(paramInt, ATTR_VALUE_TABLE, paramArrayOfString);
  }
  
  public int getWapCode()
  {
    return wapCode;
  }
  
  public Object getWapExtensionData()
  {
    return wapExtensionData;
  }
}
