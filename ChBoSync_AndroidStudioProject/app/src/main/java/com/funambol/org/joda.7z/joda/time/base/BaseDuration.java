package com.funambol.org.joda.time.base;

import java.io.Serializable;
import com.funambol.org.joda.time.Chronology;
import com.funambol.org.joda.time.DateTimeUtils;
import com.funambol.org.joda.time.Interval;
import com.funambol.org.joda.time.Period;
import com.funambol.org.joda.time.PeriodType;
import com.funambol.org.joda.time.ReadableDuration;
import com.funambol.org.joda.time.ReadableInstant;
import com.funambol.org.joda.time.convert.ConverterManager;
import com.funambol.org.joda.time.convert.DurationConverter;
import com.funambol.org.joda.time.field.FieldUtils;







































public abstract class BaseDuration
  extends AbstractDuration
  implements ReadableDuration, Serializable
{
  private static final long serialVersionUID = 2581698638990L;
  private long iMillis;
  
  protected BaseDuration(long paramLong)
  {
    iMillis = paramLong;
  }
  







  protected BaseDuration(long paramLong1, long paramLong2)
  {
    iMillis = FieldUtils.safeAdd(paramLong2, -paramLong1);
  }
  







  protected BaseDuration(ReadableInstant paramReadableInstant1, ReadableInstant paramReadableInstant2)
  {
    if (paramReadableInstant1 == paramReadableInstant2) {
      iMillis = 0L;
    } else {
      long l1 = DateTimeUtils.getInstantMillis(paramReadableInstant1);
      long l2 = DateTimeUtils.getInstantMillis(paramReadableInstant2);
      iMillis = FieldUtils.safeAdd(l2, -l1);
    }
  }
  







  protected BaseDuration(Object paramObject)
  {
    DurationConverter localDurationConverter = ConverterManager.getInstance().getDurationConverter(paramObject);
    iMillis = localDurationConverter.getDurationMillis(paramObject);
  }
  





  public long getMillis()
  {
    return iMillis;
  }
  





  protected void setMillis(long paramLong)
  {
    iMillis = paramLong;
  }
  














  public Period toPeriod(PeriodType paramPeriodType)
  {
    return new Period(getMillis(), paramPeriodType);
  }
  















  public Period toPeriod(Chronology paramChronology)
  {
    return new Period(getMillis(), paramChronology);
  }
  
















  public Period toPeriod(PeriodType paramPeriodType, Chronology paramChronology)
  {
    return new Period(getMillis(), paramPeriodType, paramChronology);
  }
  










  public Period toPeriodFrom(ReadableInstant paramReadableInstant)
  {
    return new Period(paramReadableInstant, this);
  }
  











  public Period toPeriodFrom(ReadableInstant paramReadableInstant, PeriodType paramPeriodType)
  {
    return new Period(paramReadableInstant, this, paramPeriodType);
  }
  











  public Period toPeriodTo(ReadableInstant paramReadableInstant)
  {
    return new Period(this, paramReadableInstant);
  }
  












  public Period toPeriodTo(ReadableInstant paramReadableInstant, PeriodType paramPeriodType)
  {
    return new Period(this, paramReadableInstant, paramPeriodType);
  }
  





  public Interval toIntervalFrom(ReadableInstant paramReadableInstant)
  {
    return new Interval(paramReadableInstant, this);
  }
  





  public Interval toIntervalTo(ReadableInstant paramReadableInstant)
  {
    return new Interval(this, paramReadableInstant);
  }
}
