package com.funambol.org.joda.time;

import com.funambol.org.joda.time.chrono.ISOChronology;

























public class DateTimeUtils
{
  private static final SystemMillisProvider SYSTEM_MILLIS_PROVIDER = new SystemMillisProvider();
  

  private static MillisProvider cMillisProvider = SYSTEM_MILLIS_PROVIDER;
  







  protected DateTimeUtils() {}
  






  public static final long currentTimeMillis()
  {
    return cMillisProvider.getMillis();
  }
  






  public static final void setCurrentMillisSystem()
    throws SecurityException
  {
    checkPermission();
    cMillisProvider = SYSTEM_MILLIS_PROVIDER;
  }
  







  public static final void setCurrentMillisFixed(long paramLong)
    throws SecurityException
  {
    checkPermission();
    cMillisProvider = new FixedMillisProvider(paramLong);
  }
  




  public static final void setCurrentMillisOffset(long paramLong)
    throws SecurityException
  {
    
    



    if (paramLong == 0L) {
      cMillisProvider = SYSTEM_MILLIS_PROVIDER;
    } else {
      cMillisProvider = new OffsetMillisProvider(paramLong);
    }
  }
  



  private static void checkPermission()
    throws SecurityException
  {
    SecurityManager localSecurityManager = System.getSecurityManager();
    if (localSecurityManager != null) {
      localSecurityManager.checkPermission(new JodaTimePermission("CurrentTime.setProvider"));
    }
  }
  









  public static final long getInstantMillis(ReadableInstant paramReadableInstant)
  {
    if (paramReadableInstant == null) {
      return currentTimeMillis();
    }
    return paramReadableInstant.getMillis();
  }
  










  public static final Chronology getInstantChronology(ReadableInstant paramReadableInstant)
  {
    if (paramReadableInstant == null) {
      return ISOChronology.getInstance();
    }
    Chronology localChronology = paramReadableInstant.getChronology();
    if (localChronology == null) {
      return ISOChronology.getInstance();
    }
    return localChronology;
  }
  











  public static final Chronology getIntervalChronology(ReadableInstant paramReadableInstant1, ReadableInstant paramReadableInstant2)
  {
    Object localObject = null;
    if (paramReadableInstant1 != null) {
      localObject = paramReadableInstant1.getChronology();
    } else if (paramReadableInstant2 != null) {
      localObject = paramReadableInstant2.getChronology();
    }
    if (localObject == null) {
      localObject = ISOChronology.getInstance();
    }
    return localObject;
  }
  










  public static final Chronology getIntervalChronology(ReadableInterval paramReadableInterval)
  {
    if (paramReadableInterval == null) {
      return ISOChronology.getInstance();
    }
    Chronology localChronology = paramReadableInterval.getChronology();
    if (localChronology == null) {
      return ISOChronology.getInstance();
    }
    return localChronology;
  }
  











  public static final ReadableInterval getReadableInterval(ReadableInterval paramReadableInterval)
  {
    if (paramReadableInterval == null) {
      long l = currentTimeMillis();
      paramReadableInterval = new Interval(l, l);
    }
    return paramReadableInterval;
  }
  









  public static final Chronology getChronology(Chronology paramChronology)
  {
    if (paramChronology == null) {
      return ISOChronology.getInstance();
    }
    return paramChronology;
  }
  









  public static final DateTimeZone getZone(DateTimeZone paramDateTimeZone)
  {
    if (paramDateTimeZone == null) {
      return DateTimeZone.getDefault();
    }
    return paramDateTimeZone;
  }
  









  public static final PeriodType getPeriodType(PeriodType paramPeriodType)
  {
    if (paramPeriodType == null) {
      return PeriodType.standard();
    }
    return paramPeriodType;
  }
  









  public static final long getDurationMillis(ReadableDuration paramReadableDuration)
  {
    if (paramReadableDuration == null) {
      return 0L;
    }
    return paramReadableDuration.getMillis();
  }
  























  public static final boolean isContiguous(ReadablePartial paramReadablePartial)
  {
    if (paramReadablePartial == null) {
      throw new IllegalArgumentException("Partial must not be null");
    }
    DurationFieldType localDurationFieldType = null;
    for (int i = 0; i < paramReadablePartial.size(); i++) {
      DateTimeField localDateTimeField = paramReadablePartial.getField(i);
      if ((i > 0) && 
        (localDateTimeField.getRangeDurationField().getType() != localDurationFieldType)) {
        return false;
      }
      
      localDurationFieldType = localDateTimeField.getDurationField().getType();
    }
    return true;
  }
  


  static abstract class MillisProvider
  {
    MillisProvider() {}
    


    abstract long getMillis();
  }
  


  static class SystemMillisProvider
    extends DateTimeUtils.MillisProvider
  {
    SystemMillisProvider() {}
    

    long getMillis()
    {
      return System.currentTimeMillis();
    }
  }
  



  static class FixedMillisProvider
    extends DateTimeUtils.MillisProvider
  {
    private final long iMillis;
    


    FixedMillisProvider(long paramLong)
    {
      iMillis = paramLong;
    }
    



    long getMillis()
    {
      return iMillis;
    }
  }
  



  static class OffsetMillisProvider
    extends DateTimeUtils.MillisProvider
  {
    private final long iMillis;
    


    OffsetMillisProvider(long paramLong)
    {
      iMillis = paramLong;
    }
    



    long getMillis()
    {
      return System.currentTimeMillis() + iMillis;
    }
  }
}
