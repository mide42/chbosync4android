package com.funambol.org.joda.time.chrono;

import java.util.HashMap;
import java.util.Map;
import com.funambol.org.joda.time.Chronology;
import com.funambol.org.joda.time.DateTime;
import com.funambol.org.joda.time.DateTimeField;
import com.funambol.org.joda.time.DateTimeZone;
import com.funambol.org.joda.time.field.SkipDateTimeField;
















































public final class CopticChronology
  extends BasicFixedMonthChronology
{
  private static final long serialVersionUID = -5972804258688333942L;
  public static final int AM = 1;
  private static final DateTimeField ERA_FIELD = new BasicSingleEraDateTimeField("AM");
  

  private static final int MIN_YEAR = -292269337;
  

  private static final int MAX_YEAR = 292272708;
  

  private static final Map cCache = new HashMap();
  




  private static final CopticChronology INSTANCE_UTC = getInstance(DateTimeZone.UTC);
  







  public static CopticChronology getInstanceUTC()
  {
    return INSTANCE_UTC;
  }
  




  public static CopticChronology getInstance()
  {
    return getInstance(DateTimeZone.getDefault(), 4);
  }
  





  public static CopticChronology getInstance(DateTimeZone paramDateTimeZone)
  {
    return getInstance(paramDateTimeZone, 4);
  }
  






  public static CopticChronology getInstance(DateTimeZone paramDateTimeZone, int paramInt)
  {
    if (paramDateTimeZone == null) {
      paramDateTimeZone = DateTimeZone.getDefault();
    }
    CopticChronology localCopticChronology;
    synchronized (cCache) {
      CopticChronology[] arrayOfCopticChronology = (CopticChronology[])cCache.get(paramDateTimeZone);
      if (arrayOfCopticChronology == null) {
        arrayOfCopticChronology = new CopticChronology[7];
        cCache.put(paramDateTimeZone, arrayOfCopticChronology);
      }
      try {
        localCopticChronology = arrayOfCopticChronology[(paramInt - 1)];
      } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException) {
        throw new IllegalArgumentException("Invalid min days in first week: " + paramInt);
      }
      
      if (localCopticChronology == null) {
        if (paramDateTimeZone == DateTimeZone.UTC)
        {
          localCopticChronology = new CopticChronology(null, null, paramInt);
          
          DateTime localDateTime = new DateTime(1, 1, 1, 0, 0, 0, 0, localCopticChronology);
          localCopticChronology = new CopticChronology(LimitChronology.getInstance(localCopticChronology, localDateTime, null), null, paramInt);
        }
        else
        {
          localCopticChronology = getInstance(DateTimeZone.UTC, paramInt);
          localCopticChronology = new CopticChronology(ZonedChronology.getInstance(localCopticChronology, paramDateTimeZone), null, paramInt);
        }
        
        arrayOfCopticChronology[(paramInt - 1)] = localCopticChronology;
      }
    }
    return localCopticChronology;
  }
  




  CopticChronology(Chronology paramChronology, Object paramObject, int paramInt)
  {
    super(paramChronology, paramObject, paramInt);
  }
  


  private Object readResolve()
  {
    Chronology localChronology = getBase();
    int i = getMinimumDaysInFirstWeek();
    i = i == 0 ? 4 : i;
    return localChronology == null ? getInstance(DateTimeZone.UTC, i) : getInstance(localChronology.getZone(), i);
  }
  








  public Chronology withUTC()
  {
    return INSTANCE_UTC;
  }
  





  public Chronology withZone(DateTimeZone paramDateTimeZone)
  {
    if (paramDateTimeZone == null) {
      paramDateTimeZone = DateTimeZone.getDefault();
    }
    if (paramDateTimeZone == getZone()) {
      return this;
    }
    return getInstance(paramDateTimeZone);
  }
  




  long calculateFirstDayOfYearMillis(int paramInt)
  {
    int i = paramInt - 1687;
    int j;
    if (i <= 0)
    {

      j = i + 3 >> 2;
    } else {
      j = i >> 2;
      
      if (!isLeapYear(paramInt)) {
        j++;
      }
    }
    
    long l = (i * 365L + j) * 86400000L;
    



    return l + 21859200000L;
  }
  
  int getMinYear()
  {
    return -292269337;
  }
  
  int getMaxYear()
  {
    return 292272708;
  }
  
  long getApproxMillisAtEpochDividedByTwo()
  {
    return 26607895200000L;
  }
  
  protected void assemble(AssembledChronology.Fields paramFields)
  {
    if (getBase() == null) {
      super.assemble(paramFields);
      

      year = new SkipDateTimeField(this, year);
      weekyear = new SkipDateTimeField(this, weekyear);
      
      era = ERA_FIELD;
      monthOfYear = new BasicMonthOfYearDateTimeField(this, 13);
      months = monthOfYear.getDurationField();
    }
  }
}
