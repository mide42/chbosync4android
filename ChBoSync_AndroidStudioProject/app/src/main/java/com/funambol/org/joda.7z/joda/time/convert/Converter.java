package com.funambol.org.joda.time.convert;

public abstract interface Converter
{
  public abstract Class getSupportedType();
}
