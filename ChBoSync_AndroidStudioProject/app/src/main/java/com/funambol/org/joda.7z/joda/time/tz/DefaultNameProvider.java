package com.funambol.org.joda.time.tz;

import java.text.DateFormatSymbols;
import java.util.HashMap;
import java.util.Locale;
























public class DefaultNameProvider
  implements NameProvider
{
  private HashMap iByLocaleCache = createCache();
  
  public DefaultNameProvider() {}
  
  public String getShortName(Locale paramLocale, String paramString1, String paramString2)
  {
    String[] arrayOfString = getNameSet(paramLocale, paramString1, paramString2);
    return arrayOfString == null ? null : arrayOfString[0];
  }
  
  public String getName(Locale paramLocale, String paramString1, String paramString2) {
    String[] arrayOfString = getNameSet(paramLocale, paramString1, paramString2);
    return arrayOfString == null ? null : arrayOfString[1];
  }
  
  private synchronized String[] getNameSet(Locale paramLocale, String paramString1, String paramString2) {
    if ((paramLocale == null) || (paramString1 == null) || (paramString2 == null)) {
      return null;
    }
    
    HashMap localHashMap1 = (HashMap)iByLocaleCache.get(paramLocale);
    if (localHashMap1 == null) {
      iByLocaleCache.put(paramLocale, localHashMap1 = createCache());
    }
    
    HashMap localHashMap2 = (HashMap)localHashMap1.get(paramString1);
    if (localHashMap2 == null) {
      localHashMap1.put(paramString1, localHashMap2 = createCache());
      String[][] arrayOfString = new DateFormatSymbols(paramLocale).getZoneStrings();
      for (int i = 0; i < arrayOfString.length; i++) {
        String[] arrayOfString1 = arrayOfString[i];
        if ((arrayOfString1 != null) && (arrayOfString1.length == 5) && (paramString1.equals(arrayOfString1[0]))) {
          localHashMap2.put(arrayOfString1[2], new String[] { arrayOfString1[2], arrayOfString1[1] });
          


          if (arrayOfString1[2].equals(arrayOfString1[4])) {
            localHashMap2.put(arrayOfString1[4] + "-Summer", new String[] { arrayOfString1[4], arrayOfString1[3] }); break;
          }
          localHashMap2.put(arrayOfString1[4], new String[] { arrayOfString1[4], arrayOfString1[3] });
          
          break;
        }
      }
    }
    
    return (String[])localHashMap2.get(paramString2);
  }
  
  private HashMap createCache() {
    return new HashMap(7);
  }
}
