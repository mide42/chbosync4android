package com.funambol.org.joda.time;

import com.funambol.org.joda.time.chrono.BaseChronology;
import com.funambol.org.joda.time.chrono.ISOChronology;
import com.funambol.org.joda.time.field.FieldUtils;
import com.funambol.org.joda.time.format.DateTimeFormat;
import com.funambol.org.joda.time.format.DateTimeFormatter;
import com.funambol.org.joda.time.format.DateTimeFormatterBuilder;
import com.funambol.org.joda.time.format.FormatUtils;
import com.funambol.org.joda.time.tz.DefaultNameProvider;
import com.funambol.org.joda.time.tz.FixedDateTimeZone;
import com.funambol.org.joda.time.tz.NameProvider;
import com.funambol.org.joda.time.tz.Provider;
import com.funambol.org.joda.time.tz.UTCProvider;
import com.funambol.org.joda.time.tz.ZoneInfoProvider;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamException;
import java.io.Serializable;
import java.lang.ref.Reference;
import java.lang.ref.SoftReference;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;






























































public abstract class DateTimeZone
  implements Serializable
{
  private static final long serialVersionUID = 5546345482340108586L;
  public static final DateTimeZone UTC = new FixedDateTimeZone("UTC", "UTC", 0, 0);
  
  private static Provider cProvider;
  
  private static NameProvider cNameProvider;
  
  private static Set cAvailableIDs;
  
  private static DateTimeZone cDefault;
  
  private static DateTimeFormatter cOffsetFormatter;
  
  private static Map iFixedOffsetCache;
  
  private static Map cZoneIdConversion;
  
  private final String iID;
  
  static
  {
    setProvider0(null);
    setNameProvider0(null);
    try
    {
      try {
        cDefault = forID(System.getProperty("user.timezone"));
      }
      catch (RuntimeException localRuntimeException) {}
      
      if (cDefault == null) {
        cDefault = forTimeZone(TimeZone.getDefault());
      }
    }
    catch (IllegalArgumentException localIllegalArgumentException) {}
    

    if (cDefault == null) {
      cDefault = UTC;
    }
  }
  





  public static DateTimeZone getDefault()
  {
    return cDefault;
  }
  





  public static void setDefault(DateTimeZone paramDateTimeZone)
    throws SecurityException
  {
    SecurityManager localSecurityManager = System.getSecurityManager();
    if (localSecurityManager != null) {
      localSecurityManager.checkPermission(new JodaTimePermission("DateTimeZone.setDefault"));
    }
    if (paramDateTimeZone == null) {
      throw new IllegalArgumentException("The datetime zone must not be null");
    }
    cDefault = paramDateTimeZone;
  }
  















  public static DateTimeZone forID(String paramString)
  {
    if (paramString == null) {
      return getDefault();
    }
    if (paramString.equals("UTC")) {
      return UTC;
    }
    DateTimeZone localDateTimeZone = cProvider.getZone(paramString);
    if (localDateTimeZone != null) {
      return localDateTimeZone;
    }
    if ((paramString.startsWith("+")) || (paramString.startsWith("-"))) {
      int i = parseOffset(paramString);
      if (i == 0L) {
        return UTC;
      }
      paramString = printOffset(i);
      return fixedOffsetZone(paramString, i);
    }
    
    throw new IllegalArgumentException("The datetime zone id is not recognised: " + paramString);
  }
  








  public static DateTimeZone forOffsetHours(int paramInt)
    throws IllegalArgumentException
  {
    return forOffsetHoursMinutes(paramInt, 0);
  }
  











  public static DateTimeZone forOffsetHoursMinutes(int paramInt1, int paramInt2)
    throws IllegalArgumentException
  {
    if ((paramInt1 == 0) && (paramInt2 == 0)) {
      return UTC;
    }
    if ((paramInt2 < 0) || (paramInt2 > 59)) {
      throw new IllegalArgumentException("Minutes out of range: " + paramInt2);
    }
    int i = 0;
    try {
      int j = FieldUtils.safeMultiply(paramInt1, 60);
      if (j < 0) {
        paramInt2 = FieldUtils.safeAdd(j, -paramInt2);
      } else {
        paramInt2 = FieldUtils.safeAdd(j, paramInt2);
      }
      i = FieldUtils.safeMultiply(paramInt2, 60000);
    } catch (ArithmeticException localArithmeticException) {
      throw new IllegalArgumentException("Offset is too large");
    }
    return forOffsetMillis(i);
  }
  





  public static DateTimeZone forOffsetMillis(int paramInt)
  {
    String str = printOffset(paramInt);
    return fixedOffsetZone(str, paramInt);
  }
  














  public static DateTimeZone forTimeZone(TimeZone paramTimeZone)
  {
    if (paramTimeZone == null) {
      return getDefault();
    }
    String str1 = paramTimeZone.getID();
    if (str1.equals("UTC")) {
      return UTC;
    }
    

    DateTimeZone localDateTimeZone = null;
    String str2 = getConvertedId(str1);
    if (str2 != null) {
      localDateTimeZone = cProvider.getZone(str2);
    }
    if (localDateTimeZone == null) {
      localDateTimeZone = cProvider.getZone(str1);
    }
    if (localDateTimeZone != null) {
      return localDateTimeZone;
    }
    

    if (str2 == null) {
      str2 = paramTimeZone.getDisplayName();
      if ((str2.startsWith("GMT+")) || (str2.startsWith("GMT-"))) {
        str2 = str2.substring(3);
        int i = parseOffset(str2);
        if (i == 0L) {
          return UTC;
        }
        str2 = printOffset(i);
        return fixedOffsetZone(str2, i);
      }
    }
    

    throw new IllegalArgumentException("The datetime zone id is not recognised: " + str1);
  }
  







  private static synchronized DateTimeZone fixedOffsetZone(String paramString, int paramInt)
  {
    if (paramInt == 0) {
      return UTC;
    }
    if (iFixedOffsetCache == null) {
      iFixedOffsetCache = new HashMap();
    }
    
    Reference localReference = (Reference)iFixedOffsetCache.get(paramString);
    if (localReference != null) {
      DateTimeZone localObject = (DateTimeZone)localReference.get();
      if (localObject != null) {
        return localObject;
      }
    }
    DateTimeZone localObject = new FixedDateTimeZone(paramString, null, paramInt, paramInt);
    iFixedOffsetCache.put(paramString, new SoftReference(localObject));
    return localObject;
  }
  




  public static Set getAvailableIDs()
  {
    return cAvailableIDs;
  }
  








  public static Provider getProvider()
  {
    return cProvider;
  }
  








  public static void setProvider(Provider paramProvider)
    throws SecurityException
  {
    SecurityManager localSecurityManager = System.getSecurityManager();
    if (localSecurityManager != null) {
      localSecurityManager.checkPermission(new JodaTimePermission("DateTimeZone.setProvider"));
    }
    setProvider0(paramProvider);
  }
  





  private static void setProvider0(Provider paramProvider)
  {
    if (paramProvider == null) {
      paramProvider = getDefaultProvider();
    }
    Set localSet = paramProvider.getAvailableIDs();
    if ((localSet == null) || (localSet.size() == 0)) {
      throw new IllegalArgumentException("The provider doesn't have any available ids");
    }
    
    if (!localSet.contains("UTC")) {
      throw new IllegalArgumentException("The provider doesn't support UTC");
    }
    if (!UTC.equals(paramProvider.getZone("UTC"))) {
      throw new IllegalArgumentException("Invalid UTC zone provided");
    }
    cProvider = paramProvider;
    cAvailableIDs = localSet;
  }
  








  private static Provider getDefaultProvider()
  {
    Object localObject = null;
    try
    {
      String str = System.getProperty("org.joda.time.DateTimeZone.Provider");
      
      if (str != null) {
        try {
          localObject = (Provider)Class.forName(str).newInstance();
        } catch (Exception localException2) {
          Thread localThread2 = Thread.currentThread();
          localThread2.getThreadGroup().uncaughtException(localThread2, localException2);
        }
      }
    }
    catch (SecurityException localSecurityException) {}
    

    if (localObject == null) {
      try {
        localObject = new ZoneInfoProvider("org/joda/time/tz/data");
      } catch (Exception localException1) {
        Thread localThread1 = Thread.currentThread();
        localThread1.getThreadGroup().uncaughtException(localThread1, localException1);
      }
    }
    
    if (localObject == null) {
      localObject = new UTCProvider();
    }
    
    return (Provider)localObject;
  }
  








  public static NameProvider getNameProvider()
  {
    return cNameProvider;
  }
  








  public static void setNameProvider(NameProvider paramNameProvider)
    throws SecurityException
  {
    SecurityManager localSecurityManager = System.getSecurityManager();
    if (localSecurityManager != null) {
      localSecurityManager.checkPermission(new JodaTimePermission("DateTimeZone.setNameProvider"));
    }
    setNameProvider0(paramNameProvider);
  }
  





  private static void setNameProvider0(NameProvider paramNameProvider)
  {
    if (paramNameProvider == null) {
      paramNameProvider = getDefaultNameProvider();
    }
    cNameProvider = paramNameProvider;
  }
  







  private static NameProvider getDefaultNameProvider()
  {
    Object localObject = null;
    try {
      String str = System.getProperty("org.joda.time.DateTimeZone.NameProvider");
      if (str != null) {
        try {
          localObject = (NameProvider)Class.forName(str).newInstance();
        } catch (Exception localException) {
          Thread localThread = Thread.currentThread();
          localThread.getThreadGroup().uncaughtException(localThread, localException);
        }
      }
    }
    catch (SecurityException localSecurityException) {}
    

    if (localObject == null) {
      localObject = new DefaultNameProvider();
    }
    
    return (NameProvider)localObject;
  }
  






  private static synchronized String getConvertedId(String paramString)
  {
    Object localObject = cZoneIdConversion;
    if (localObject == null)
    {
      localObject = new HashMap();
      ((Map)localObject).put("GMT", "UTC");
      ((Map)localObject).put("MIT", "Pacific/Apia");
      ((Map)localObject).put("HST", "Pacific/Honolulu");
      ((Map)localObject).put("AST", "America/Anchorage");
      ((Map)localObject).put("PST", "America/Los_Angeles");
      ((Map)localObject).put("MST", "America/Denver");
      ((Map)localObject).put("PNT", "America/Phoenix");
      ((Map)localObject).put("CST", "America/Chicago");
      ((Map)localObject).put("EST", "America/New_York");
      ((Map)localObject).put("IET", "America/Indianapolis");
      ((Map)localObject).put("PRT", "America/Puerto_Rico");
      ((Map)localObject).put("CNT", "America/St_Johns");
      ((Map)localObject).put("AGT", "America/Buenos_Aires");
      ((Map)localObject).put("BET", "America/Sao_Paulo");
      ((Map)localObject).put("WET", "Europe/London");
      ((Map)localObject).put("ECT", "Europe/Paris");
      ((Map)localObject).put("ART", "Africa/Cairo");
      ((Map)localObject).put("CAT", "Africa/Harare");
      ((Map)localObject).put("EET", "Europe/Bucharest");
      ((Map)localObject).put("EAT", "Africa/Addis_Ababa");
      ((Map)localObject).put("MET", "Asia/Tehran");
      ((Map)localObject).put("NET", "Asia/Yerevan");
      ((Map)localObject).put("PLT", "Asia/Karachi");
      ((Map)localObject).put("IST", "Asia/Calcutta");
      ((Map)localObject).put("BST", "Asia/Dhaka");
      ((Map)localObject).put("VST", "Asia/Saigon");
      ((Map)localObject).put("CTT", "Asia/Shanghai");
      ((Map)localObject).put("JST", "Asia/Tokyo");
      ((Map)localObject).put("ACT", "Australia/Darwin");
      ((Map)localObject).put("AET", "Australia/Sydney");
      ((Map)localObject).put("SST", "Pacific/Guadalcanal");
      ((Map)localObject).put("NST", "Pacific/Auckland");
      cZoneIdConversion = (Map)localObject;
    }
    return (String)((Map)localObject).get(paramString);
  }
  
  private static int parseOffset(String paramString) {
    Object localObject;
    if (cDefault != null) {
      localObject = ISOChronology.getInstanceUTC();
    }
    else
    {
      localObject = new BaseChronology() {
        public DateTimeZone getZone() {
          return null;
        }
        
        public Chronology withUTC() { return this; }
        
        public Chronology withZone(DateTimeZone paramAnonymousDateTimeZone) {
          return this;
        }
        
        public String toString() { return getClass().getName(); }
      };
    }
    

    return -(int)offsetFormatter().withChronology((Chronology)localObject).parseMillis(paramString);
  }
  








  private static String printOffset(int paramInt)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    if (paramInt >= 0) {
      localStringBuffer.append('+');
    } else {
      localStringBuffer.append('-');
      paramInt = -paramInt;
    }
    
    int i = paramInt / 3600000;
    FormatUtils.appendPaddedInteger(localStringBuffer, i, 2);
    paramInt -= i * 3600000;
    
    int j = paramInt / 60000;
    localStringBuffer.append(':');
    FormatUtils.appendPaddedInteger(localStringBuffer, j, 2);
    paramInt -= j * 60000;
    if (paramInt == 0) {
      return localStringBuffer.toString();
    }
    
    int k = paramInt / 1000;
    localStringBuffer.append(':');
    FormatUtils.appendPaddedInteger(localStringBuffer, k, 2);
    paramInt -= k * 1000;
    if (paramInt == 0) {
      return localStringBuffer.toString();
    }
    
    localStringBuffer.append('.');
    FormatUtils.appendPaddedInteger(localStringBuffer, paramInt, 3);
    return localStringBuffer.toString();
  }
  




  private static synchronized DateTimeFormatter offsetFormatter()
  {
    if (cOffsetFormatter == null) {
      cOffsetFormatter = new DateTimeFormatterBuilder().appendTimeZoneOffset(null, true, 2, 4).toFormatter();
    }
    

    return cOffsetFormatter;
  }
  










  protected DateTimeZone(String paramString)
  {
    if (paramString == null) {
      throw new IllegalArgumentException("Id must not be null");
    }
    iID = paramString;
  }
  







  public final String getID()
  {
    return iID;
  }
  


















  public final String getShortName(long paramLong)
  {
    return getShortName(paramLong, null);
  }
  










  public String getShortName(long paramLong, Locale paramLocale)
  {
    if (paramLocale == null) {
      paramLocale = Locale.getDefault();
    }
    String str1 = getNameKey(paramLong);
    if (str1 == null) {
      return iID;
    }
    String str2 = cNameProvider.getShortName(paramLocale, iID, str1);
    if (str2 != null) {
      return str2;
    }
    return printOffset(getOffset(paramLong));
  }
  









  public final String getName(long paramLong)
  {
    return getName(paramLong, null);
  }
  










  public String getName(long paramLong, Locale paramLocale)
  {
    if (paramLocale == null) {
      paramLocale = Locale.getDefault();
    }
    String str1 = getNameKey(paramLong);
    if (str1 == null) {
      return iID;
    }
    String str2 = cNameProvider.getName(paramLocale, iID, str1);
    if (str2 != null) {
      return str2;
    }
    return printOffset(getOffset(paramLong));
  }
  













  public final int getOffset(ReadableInstant paramReadableInstant)
  {
    if (paramReadableInstant == null) {
      return getOffset(DateTimeUtils.currentTimeMillis());
    }
    return getOffset(paramReadableInstant.getMillis());
  }
  























  public boolean isStandardOffset(long paramLong)
  {
    return getOffset(paramLong) == getStandardOffset(paramLong);
  }
  






























  public int getOffsetFromLocal(long paramLong)
  {
    int i = getOffset(paramLong);
    
    int j = getOffset(paramLong - i);
    
    if (i != j)
    {

      if (i - j < 0)
      {


        long l1 = nextTransition(paramLong - i);
        long l2 = nextTransition(paramLong - j);
        if (l1 != l2) {
          return i;
        }
      }
    }
    return j;
  }
  









  public long convertUTCToLocal(long paramLong)
  {
    int i = getOffset(paramLong);
    long l = paramLong + i;
    
    if (((paramLong ^ l) < 0L) && ((paramLong ^ i) >= 0L)) {
      throw new ArithmeticException("Adding time zone offset caused overflow");
    }
    return l;
  }
  












  public long convertLocalToUTC(long paramLong, boolean paramBoolean)
  {
    int i = getOffset(paramLong);
    
    int j = getOffset(paramLong - i);
    
    if (i != j)
    {


      if ((paramBoolean) || (i < 0))
      {
        long l1 = nextTransition(paramLong - i);
        long l2 = nextTransition(paramLong - j);
        if (l1 != l2)
        {
          if (paramBoolean)
          {
            throw new IllegalArgumentException("Illegal instant due to time zone offset transition: " + DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSS").print(new Instant(paramLong)) + " (" + getID() + ")");
          }
          




          j = i;
        }
      }
    }
    

    long l1 = paramLong - j;
    
    if (((paramLong ^ l1) < 0L) && ((paramLong ^ j) < 0L)) {
      throw new ArithmeticException("Subtracting time zone offset caused overflow");
    }
    return l1;
  }
  









  public long getMillisKeepLocal(DateTimeZone paramDateTimeZone, long paramLong)
  {
    if (paramDateTimeZone == null) {
      paramDateTimeZone = getDefault();
    }
    if (paramDateTimeZone == this) {
      return paramLong;
    }
    long l = paramLong + getOffset(paramLong);
    return l - paramDateTimeZone.getOffsetFromLocal(l);
  }
  









































































































  public boolean isLocalDateTimeGap(LocalDateTime paramLocalDateTime)
  {
    if (isFixed()) {
      return false;
    }
    try {
      paramLocalDateTime.toDateTime(this);
      return false;
    } catch (IllegalArgumentException localIllegalArgumentException) {}
    return true;
  }
  




































  public TimeZone toTimeZone()
  {
    return TimeZone.getTimeZone(iID);
  }
  












  public int hashCode()
  {
    return 57 + getID().hashCode();
  }
  



  public String toString()
  {
    return getID();
  }
  






  protected Object writeReplace()
    throws ObjectStreamException { return new Stub(iID); }
  
  public abstract String getNameKey(long paramLong);
  
  public abstract int getOffset(long paramLong);
  
  public abstract int getStandardOffset(long paramLong);
  
  public abstract boolean isFixed();
  
  public abstract long nextTransition(long paramLong);
  
  public abstract long previousTransition(long paramLong);
  
  public abstract boolean equals(Object paramObject);
  
  private static final class Stub implements Serializable {
    Stub(String paramString) { iID = paramString; }
    
    private static final long serialVersionUID = -6471952376487863581L;
    private transient String iID;
    private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException { paramObjectOutputStream.writeUTF(iID); }
    
    private void readObject(ObjectInputStream paramObjectInputStream) throws IOException
    {
      iID = paramObjectInputStream.readUTF();
    }
    
    private Object readResolve() throws ObjectStreamException {
      return DateTimeZone.forID(iID);
    }
  }
}
