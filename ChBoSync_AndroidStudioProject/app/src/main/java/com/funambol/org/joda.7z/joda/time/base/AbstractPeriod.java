package com.funambol.org.joda.time.base;

import com.funambol.org.joda.time.DurationFieldType;
import com.funambol.org.joda.time.MutablePeriod;
import com.funambol.org.joda.time.Period;
import com.funambol.org.joda.time.PeriodType;
import com.funambol.org.joda.time.ReadablePeriod;
import com.funambol.org.joda.time.format.ISOPeriodFormat;
import com.funambol.org.joda.time.format.PeriodFormatter;







































public abstract class AbstractPeriod
  implements ReadablePeriod
{
  protected AbstractPeriod() {}
  
  public DurationFieldType[] getFieldTypes()
  {
    DurationFieldType[] arrayOfDurationFieldType = new DurationFieldType[size()];
    for (int i = 0; i < arrayOfDurationFieldType.length; i++) {
      arrayOfDurationFieldType[i] = getFieldType(i);
    }
    return arrayOfDurationFieldType;
  }
  







  public int[] getValues()
  {
    int[] arrayOfInt = new int[size()];
    for (int i = 0; i < arrayOfInt.length; i++) {
      arrayOfInt[i] = getValue(i);
    }
    return arrayOfInt;
  }
  









  public int get(DurationFieldType paramDurationFieldType)
  {
    int i = indexOf(paramDurationFieldType);
    if (i == -1) {
      return 0;
    }
    return getValue(i);
  }
  





  public boolean isSupported(DurationFieldType paramDurationFieldType)
  {
    return getPeriodType().isSupported(paramDurationFieldType);
  }
  





  public int indexOf(DurationFieldType paramDurationFieldType)
  {
    return getPeriodType().indexOf(paramDurationFieldType);
  }
  





  public Period toPeriod()
  {
    return new Period(this);
  }
  






  public MutablePeriod toMutablePeriod()
  {
    return new MutablePeriod(this);
  }
  




















  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {
      return true;
    }
    if (!(paramObject instanceof ReadablePeriod)) {
      return false;
    }
    ReadablePeriod localReadablePeriod = (ReadablePeriod)paramObject;
    if (size() != localReadablePeriod.size()) {
      return false;
    }
    int i = 0; for (int j = size(); i < j; i++) {
      if ((getValue(i) != localReadablePeriod.getValue(i)) || (getFieldType(i) != localReadablePeriod.getFieldType(i))) {
        return false;
      }
    }
    return true;
  }
  




  public int hashCode()
  {
    int i = 17;
    int j = 0; for (int k = size(); j < k; j++) {
      i = 27 * i + getValue(j);
      i = 27 * i + getFieldType(j).hashCode();
    }
    return i;
  }
  










  public String toString()
  {
    return ISOPeriodFormat.standard().print(this);
  }
  







  public String toString(PeriodFormatter paramPeriodFormatter)
  {
    if (paramPeriodFormatter == null) {
      return toString();
    }
    return paramPeriodFormatter.print(this);
  }
}
