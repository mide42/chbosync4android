package com.funambol.org.kxml2.kdom;

import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

public class Document
  extends Node
{
  protected int rootIndex = -1;
  String encoding;
  Boolean standalone;
  
  public Document() {}
  
  public String getEncoding()
  {
    return encoding;
  }
  
  public void setEncoding(String paramString)
  {
    encoding = paramString;
  }
  
  public void setStandalone(Boolean paramBoolean)
  {
    standalone = paramBoolean;
  }
  
  public Boolean getStandalone()
  {
    return standalone;
  }
  
  public String getName()
  {
    return "#document";
  }
  
  public void addChild(int paramInt1, int paramInt2, Object paramObject)
  {
    if (paramInt2 == 2) {
      rootIndex = paramInt1;
    } else if (rootIndex >= paramInt1) {
      rootIndex += 1;
    }
    super.addChild(paramInt1, paramInt2, paramObject);
  }
  
  public void parse(XmlPullParser paramXmlPullParser)
    throws IOException, XmlPullParserException
  {
    paramXmlPullParser.require(0, null, null);
    paramXmlPullParser.nextToken();
    encoding = paramXmlPullParser.getInputEncoding();
    standalone = ((Boolean)paramXmlPullParser.getProperty("http://xmlpull.org/v1/doc/properties.html#xmldecl-standalone"));
    super.parse(paramXmlPullParser);
    if (paramXmlPullParser.getEventType() != 1) {
      throw new RuntimeException("Document end expected!");
    }
  }
  
  public void removeChild(int paramInt)
  {
    if (paramInt == rootIndex) {
      rootIndex = -1;
    } else if (paramInt < rootIndex) {
      rootIndex -= 1;
    }
    super.removeChild(paramInt);
  }
  
  public Element getRootElement()
  {
    if (rootIndex == -1) {
      throw new RuntimeException("Document has no root element!");
    }
    return (Element)getChild(rootIndex);
  }
  
  public void write(XmlSerializer paramXmlSerializer)
    throws IOException
  {
    paramXmlSerializer.startDocument(encoding, standalone);
    writeChildren(paramXmlSerializer);
    paramXmlSerializer.endDocument();
  }
}
