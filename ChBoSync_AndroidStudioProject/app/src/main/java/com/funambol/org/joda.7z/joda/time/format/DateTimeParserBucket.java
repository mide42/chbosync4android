package com.funambol.org.joda.time.format;

import com.funambol.org.joda.time.Chronology;
import com.funambol.org.joda.time.DateTimeField;
import com.funambol.org.joda.time.DateTimeFieldType;
import com.funambol.org.joda.time.DateTimeUtils;
import com.funambol.org.joda.time.DateTimeZone;
import com.funambol.org.joda.time.DurationField;
import com.funambol.org.joda.time.IllegalFieldValueException;

import java.util.Arrays;
import java.util.Locale;
















































public class DateTimeParserBucket
{
  private final Chronology iChrono;
  private final long iMillis;
  private DateTimeZone iZone;
  private int iOffset;
  private Locale iLocale;
  private Integer iPivotYear;
  private SavedField[] iSavedFields = new SavedField[8];
  

  private int iSavedFieldsCount;
  

  private boolean iSavedFieldsShared;
  

  private Object iSavedState;
  

  public DateTimeParserBucket(long paramLong, Chronology paramChronology, Locale paramLocale)
  {
    this(paramLong, paramChronology, paramLocale, null);
  }
  










  public DateTimeParserBucket(long paramLong, Chronology paramChronology, Locale paramLocale, Integer paramInteger)
  {
    paramChronology = DateTimeUtils.getChronology(paramChronology);
    iMillis = paramLong;
    iChrono = paramChronology.withUTC();
    iLocale = (paramLocale == null ? Locale.getDefault() : paramLocale);
    setZone(paramChronology.getZone());
    iPivotYear = paramInteger;
  }
  



  public Chronology getChronology()
  {
    return iChrono;
  }
  





  public Locale getLocale()
  {
    return iLocale;
  }
  




  public DateTimeZone getZone()
  {
    return iZone;
  }
  





  public void setZone(DateTimeZone paramDateTimeZone)
  {
    iSavedState = null;
    iZone = (paramDateTimeZone == DateTimeZone.UTC ? null : paramDateTimeZone);
    iOffset = 0;
  }
  




  public int getOffset()
  {
    return iOffset;
  }
  



  public void setOffset(int paramInt)
  {
    iSavedState = null;
    iOffset = paramInt;
    iZone = null;
  }
  








  public Integer getPivotYear()
  {
    return iPivotYear;
  }
  








  public void setPivotYear(Integer paramInteger)
  {
    iPivotYear = paramInteger;
  }
  






  public void saveField(DateTimeField paramDateTimeField, int paramInt)
  {
    saveField(new SavedField(paramDateTimeField, paramInt));
  }
  





  public void saveField(DateTimeFieldType paramDateTimeFieldType, int paramInt)
  {
    saveField(new SavedField(paramDateTimeFieldType.getField(iChrono), paramInt));
  }
  






  public void saveField(DateTimeFieldType paramDateTimeFieldType, String paramString, Locale paramLocale)
  {
    saveField(new SavedField(paramDateTimeFieldType.getField(iChrono), paramString, paramLocale));
  }
  /*
  private void saveField(SavedField paramSavedField)
  {
    Object localObject = iSavedFields;
    int i = iSavedFieldsCount;
    
    if ((i == localObject.length) || (iSavedFieldsShared))
    {
      SavedField[] arrayOfSavedField = new SavedField[i == localObject.length ? i * 2 : localObject.length];
      
      System.arraycopy(localObject, 0, arrayOfSavedField, 0, i);
      iSavedFields = (localObject = arrayOfSavedField);
      iSavedFieldsShared = false;
    }
    
    iSavedState = null;
    localObject[i] = paramSavedField;
    iSavedFieldsCount = (i + 1);
  }
*/

  private void saveField(SavedField field) {
    SavedField[] savedFields = iSavedFields;
    int savedFieldsCount = iSavedFieldsCount;

    if (savedFieldsCount == savedFields.length || iSavedFieldsShared) {
      // Expand capacity or merely copy if saved fields are shared.
      SavedField[] newArray = new SavedField
              [savedFieldsCount == savedFields.length ? savedFieldsCount * 2 : savedFields.length];
      System.arraycopy(savedFields, 0, newArray, 0, savedFieldsCount);
      iSavedFields = savedFields = newArray;
      iSavedFieldsShared = false;
    }

    iSavedState = null;
    savedFields[savedFieldsCount] = field;
    iSavedFieldsCount = savedFieldsCount + 1;
  }








  public Object saveState()
  {
    if (iSavedState == null) {
      iSavedState = new SavedState();
    }
    return iSavedState;
  }
  







  public boolean restoreState(Object paramObject)
  {
    if (((paramObject instanceof SavedState)) && 
      (((SavedState)paramObject).restoreState(this))) {
      iSavedState = paramObject;
      return true;
    }
    
    return false;
  }
  






  public long computeMillis()
  {
    return computeMillis(false, null);
  }
  







  public long computeMillis(boolean paramBoolean)
  {
    return computeMillis(paramBoolean, null);
  }
  









  public long computeMillis(boolean paramBoolean, String paramString)
  {
    SavedField[] arrayOfSavedField = iSavedFields;
    int i = iSavedFieldsCount;
    if (iSavedFieldsShared) {
      iSavedFields = (arrayOfSavedField = (SavedField[])iSavedFields.clone());
      iSavedFieldsShared = false;
    }
    sort(arrayOfSavedField, i);
    
    long l = iMillis;
    try {
      for (int j = 0; j < i; j++) {
        l = arrayOfSavedField[j].set(l, paramBoolean);
      }
    } catch (IllegalFieldValueException localIllegalFieldValueException) {
      if (paramString != null) {
        localIllegalFieldValueException.prependMessage("Cannot parse \"" + paramString + '"');
      }
      throw localIllegalFieldValueException;
    }
    
    if (iZone == null) {
      l -= iOffset;
    } else {
      int k = iZone.getOffsetFromLocal(l);
      l -= k;
      if (k != iZone.getOffset(l)) {
        String str = "Illegal instant due to time zone offset transition (" + iZone + ')';
        
        if (paramString != null) {
          str = "Cannot parse \"" + paramString + "\": " + str;
        }
        throw new IllegalArgumentException(str);
      }
    }
    
    return l;
  }
  

















  private static void sort(Comparable[] paramArrayOfComparable, int paramInt)
  {
    if (paramInt > 10) {
      Arrays.sort(paramArrayOfComparable, 0, paramInt);
    } else {
      for (int i = 0; i < paramInt; i++) {
        for (int j = i; (j > 0) && (paramArrayOfComparable[(j - 1)].compareTo(paramArrayOfComparable[j]) > 0); j--) {
          Comparable localComparable = paramArrayOfComparable[j];
          paramArrayOfComparable[j] = paramArrayOfComparable[(j - 1)];
          paramArrayOfComparable[(j - 1)] = localComparable;
        }
      }
    }
  }
  
  class SavedState {
    final DateTimeZone iZone;
    final int iOffset;
    final DateTimeParserBucket.SavedField[] iSavedFields;
    final int iSavedFieldsCount;

    SavedState() {
      this.iZone = DateTimeParserBucket.this.iZone;
      this.iOffset = DateTimeParserBucket.this.iOffset;
      this.iSavedFields = DateTimeParserBucket.this.iSavedFields;
      this.iSavedFieldsCount = DateTimeParserBucket.this.iSavedFieldsCount;
    }
/*
    SavedState() {
      iZone = iZone;
      iOffset = iOffset;
      iSavedFields = iSavedFields;
      iSavedFieldsCount = iSavedFieldsCount;
    }
*/

    public boolean restoreState(Object savedState) {
      if (savedState instanceof SavedState) {
        if (((SavedState) savedState).restoreState(this)) {
          iSavedState = savedState;
          return true;
        }
      }
      return false;
    }
/*


    boolean restoreState(DateTimeParserBucket paramDateTimeParserBucket) {
      if (paramDateTimeParserBucket != DateTimeParserBucket.this) {
        return false;
      }
      iZone = iZone;
      iOffset = iOffset;
      iSavedFields = iSavedFields;
      if (iSavedFieldsCount < iSavedFieldsCount)
      {



        iSavedFieldsShared = true;
      }
      iSavedFieldsCount = iSavedFieldsCount;
      return true;
    }
  */
  }

  static class SavedField implements Comparable {
    final DateTimeField iField;
    final int iValue;
    final String iText;
    final Locale iLocale;
    
    SavedField(DateTimeField paramDateTimeField, int paramInt) {
      iField = paramDateTimeField;
      iValue = paramInt;
      iText = null;
      iLocale = null;
    }
    
    SavedField(DateTimeField paramDateTimeField, String paramString, Locale paramLocale) {
      iField = paramDateTimeField;
      iValue = 0;
      iText = paramString;
      iLocale = paramLocale;
    }
    
    long set(long paramLong, boolean paramBoolean) {
      if (iText == null) {
        paramLong = iField.set(paramLong, iValue);
      } else {
        paramLong = iField.set(paramLong, iText, iLocale);
      }
      if (paramBoolean) {
        paramLong = iField.roundFloor(paramLong);
      }
      return paramLong;
    }
    




    public int compareTo(Object paramObject)
    {
      DateTimeField localDateTimeField = iField;
      int i = compareReverse(iField.getRangeDurationField(), localDateTimeField.getRangeDurationField());
      
      if (i != 0) {
        return i;
      }
      return compareReverse(iField.getDurationField(), localDateTimeField.getDurationField());
    }
    
    private int compareReverse(DurationField paramDurationField1, DurationField paramDurationField2)
    {
      if ((paramDurationField1 == null) || (!paramDurationField1.isSupported())) {
        if ((paramDurationField2 == null) || (!paramDurationField2.isSupported())) {
          return 0;
        }
        return -1;
      }
      if ((paramDurationField2 == null) || (!paramDurationField2.isSupported())) {
        return 1;
      }
      return -paramDurationField1.compareTo(paramDurationField2);
    }
  }
}
