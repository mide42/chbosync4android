package com.funambol.org.joda.time.base;

import java.util.Date;
import com.funambol.org.joda.time.Chronology;
import com.funambol.org.joda.time.DateTime;
import com.funambol.org.joda.time.DateTimeField;
import com.funambol.org.joda.time.DateTimeFieldType;
import com.funambol.org.joda.time.DateTimeUtils;
import com.funambol.org.joda.time.DateTimeZone;
import com.funambol.org.joda.time.Instant;
import com.funambol.org.joda.time.MutableDateTime;
import com.funambol.org.joda.time.ReadableInstant;
import com.funambol.org.joda.time.chrono.ISOChronology;
import com.funambol.org.joda.time.field.FieldUtils;
import com.funambol.org.joda.time.format.DateTimeFormatter;
import com.funambol.org.joda.time.format.ISODateTimeFormat;














































public abstract class AbstractInstant
  implements ReadableInstant
{
  protected AbstractInstant() {}
  
  public DateTimeZone getZone()
  {
    return getChronology().getZone();
  }
  













  public int get(DateTimeFieldType paramDateTimeFieldType)
  {
    if (paramDateTimeFieldType == null) {
      throw new IllegalArgumentException("The DateTimeFieldType must not be null");
    }
    return paramDateTimeFieldType.getField(getChronology()).get(getMillis());
  }
  






  public boolean isSupported(DateTimeFieldType paramDateTimeFieldType)
  {
    if (paramDateTimeFieldType == null) {
      return false;
    }
    return paramDateTimeFieldType.getField(getChronology()).isSupported();
  }
  













  public int get(DateTimeField paramDateTimeField)
  {
    if (paramDateTimeField == null) {
      throw new IllegalArgumentException("The DateTimeField must not be null");
    }
    return paramDateTimeField.get(getMillis());
  }
  





  public Instant toInstant()
  {
    return new Instant(getMillis());
  }
  




  public DateTime toDateTime()
  {
    return new DateTime(getMillis(), getZone());
  }
  




  public DateTime toDateTimeISO()
  {
    return new DateTime(getMillis(), ISOChronology.getInstance(getZone()));
  }
  





  public DateTime toDateTime(DateTimeZone paramDateTimeZone)
  {
    Chronology localChronology = DateTimeUtils.getChronology(getChronology());
    localChronology = localChronology.withZone(paramDateTimeZone);
    return new DateTime(getMillis(), localChronology);
  }
  





  public DateTime toDateTime(Chronology paramChronology)
  {
    return new DateTime(getMillis(), paramChronology);
  }
  









  public MutableDateTime toMutableDateTime()
  {
    return new MutableDateTime(getMillis(), getZone());
  }
  




  public MutableDateTime toMutableDateTimeISO()
  {
    return new MutableDateTime(getMillis(), ISOChronology.getInstance(getZone()));
  }
  





  public MutableDateTime toMutableDateTime(DateTimeZone paramDateTimeZone)
  {
    Chronology localChronology = DateTimeUtils.getChronology(getChronology());
    localChronology = localChronology.withZone(paramDateTimeZone);
    return new MutableDateTime(getMillis(), localChronology);
  }
  





  public MutableDateTime toMutableDateTime(Chronology paramChronology)
  {
    return new MutableDateTime(getMillis(), paramChronology);
  }
  








  public Date toDate()
  {
    return new Date(getMillis());
  }
  



















  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {
      return true;
    }
    if (!(paramObject instanceof ReadableInstant)) {
      return false;
    }
    ReadableInstant localReadableInstant = (ReadableInstant)paramObject;
    return (getMillis() == localReadableInstant.getMillis()) && (FieldUtils.equals(getChronology(), localReadableInstant.getChronology()));
  }
  







  public int hashCode()
  {
    return (int)(getMillis() ^ getMillis() >>> 32) + getChronology().hashCode();
  }
  













  public int compareTo(Object paramObject)
  {
    if (this == paramObject) {
      return 0;
    }
    
    ReadableInstant localReadableInstant = (ReadableInstant)paramObject;
    
    long l1 = localReadableInstant.getMillis();
    long l2 = getMillis();
    

    if (l2 == l1) {
      return 0;
    }
    if (l2 < l1) {
      return -1;
    }
    return 1;
  }
  








  public boolean isAfter(long paramLong)
  {
    return getMillis() > paramLong;
  }
  





  public boolean isAfterNow()
  {
    return isAfter(DateTimeUtils.currentTimeMillis());
  }
  






  public boolean isAfter(ReadableInstant paramReadableInstant)
  {
    long l = DateTimeUtils.getInstantMillis(paramReadableInstant);
    return isAfter(l);
  }
  







  public boolean isBefore(long paramLong)
  {
    return getMillis() < paramLong;
  }
  





  public boolean isBeforeNow()
  {
    return isBefore(DateTimeUtils.currentTimeMillis());
  }
  






  public boolean isBefore(ReadableInstant paramReadableInstant)
  {
    long l = DateTimeUtils.getInstantMillis(paramReadableInstant);
    return isBefore(l);
  }
  







  public boolean isEqual(long paramLong)
  {
    return getMillis() == paramLong;
  }
  





  public boolean isEqualNow()
  {
    return isEqual(DateTimeUtils.currentTimeMillis());
  }
  






  public boolean isEqual(ReadableInstant paramReadableInstant)
  {
    long l = DateTimeUtils.getInstantMillis(paramReadableInstant);
    return isEqual(l);
  }
  





  public String toString()
  {
    return ISODateTimeFormat.dateTime().print(this);
  }
  







  public String toString(DateTimeFormatter paramDateTimeFormatter)
  {
    if (paramDateTimeFormatter == null) {
      return toString();
    }
    return paramDateTimeFormatter.print(this);
  }
}
