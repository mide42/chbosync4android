package com.funambol.org.kxml2.wap;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.Hashtable;
import java.util.Vector;
import org.xmlpull.v1.XmlSerializer;

public class WbxmlSerializer
  implements XmlSerializer
{
  Hashtable stringTable = new Hashtable();
  OutputStream out;
  ByteArrayOutputStream buf = new ByteArrayOutputStream();
  ByteArrayOutputStream stringTableBuf = new ByteArrayOutputStream();
  String pending;
  int depth;
  String name;
  String namespace;
  Vector attributes = new Vector();
  Hashtable attrStartTable = new Hashtable();
  Hashtable attrValueTable = new Hashtable();
  Hashtable tagTable = new Hashtable();
  private int attrPage;
  private int tagPage;
  private String encoding;
  
  public WbxmlSerializer() {}
  
  public XmlSerializer attribute(String paramString1, String paramString2, String paramString3)
  {
    attributes.addElement(paramString2);
    attributes.addElement(paramString3);
    return this;
  }
  
  public void cdsect(String paramString)
    throws IOException
  {
    text(paramString);
  }
  
  public void comment(String paramString) {}
  
  public void docdecl(String paramString)
  {
    throw new RuntimeException("Cannot write docdecl for WBXML");
  }
  
  public void entityRef(String paramString)
  {
    throw new RuntimeException("EntityReference not supported for WBXML");
  }
  
  public int getDepth()
  {
    return depth;
  }
  
  public boolean getFeature(String paramString)
  {
    return false;
  }
  
  public String getNamespace()
  {
    throw new RuntimeException("NYI");
  }
  
  public String getName()
  {
    throw new RuntimeException("NYI");
  }
  
  public String getPrefix(String paramString, boolean paramBoolean)
  {
    throw new RuntimeException("NYI");
  }
  
  public Object getProperty(String paramString)
  {
    return null;
  }
  
  public void ignorableWhitespace(String paramString) {}
  
  public void endDocument()
    throws IOException
  {
    writeInt(out, stringTableBuf.size());
    out.write(stringTableBuf.toByteArray());
    out.write(buf.toByteArray());
    out.flush();
  }
  
  public void flush() {}
  
  public void checkPending(boolean paramBoolean)
    throws IOException
  {
    if (pending == null) {
      return;
    }
    int i = attributes.size();
    int[] arrayOfInt = (int[])tagTable.get(pending);
    if (arrayOfInt == null)
    {
      buf.write(paramBoolean ? 132 : i == 0 ? 68 : paramBoolean ? 4 : 196);
      writeStrT(pending, false);
    }
    else
    {
      if (arrayOfInt[0] != tagPage)
      {
        tagPage = arrayOfInt[0];
        buf.write(0);
        buf.write(tagPage);
      }
      buf.write(paramBoolean ? arrayOfInt[1] | 0x80 : i == 0 ? arrayOfInt[1] | 0x40 : paramBoolean ? arrayOfInt[1] : arrayOfInt[1] | 0xC0);
    }
    int j = 1;
    int k;
    if (j != 0) {
      for (k = 0; k < i; k++)
      {
        buf.write(4);
        writeStrT((String)attributes.elementAt(k), false);
        buf.write(3);
        writeStrI(buf, (String)attributes.elementAt(++k));
      }
    } else {
      for (k = 0; k < i; k++)
      {
        arrayOfInt = (int[])attrStartTable.get(attributes.elementAt(k));
        if (arrayOfInt == null)
        {
          buf.write(4);
          writeStrT((String)attributes.elementAt(k), false);
        }
        else
        {
          if (arrayOfInt[0] != attrPage)
          {
            attrPage = arrayOfInt[0];
            buf.write(0);
            buf.write(attrPage);
          }
          buf.write(arrayOfInt[1]);
        }
        arrayOfInt = (int[])attrValueTable.get(attributes.elementAt(++k));
        if (arrayOfInt == null)
        {
          writeStr((String)attributes.elementAt(k));
        }
        else
        {
          if (arrayOfInt[0] != attrPage)
          {
            attrPage = arrayOfInt[0];
            buf.write(0);
            buf.write(attrPage);
          }
          buf.write(arrayOfInt[1]);
        }
      }
    }
    if (i > 0) {
      buf.write(1);
    }
    pending = null;
    attributes.removeAllElements();
  }
  
  public void processingInstruction(String paramString)
  {
    throw new RuntimeException("PI NYI");
  }
  
  public void setFeature(String paramString, boolean paramBoolean)
  {
    throw new IllegalArgumentException("unknown feature " + paramString);
  }
  
  public void setOutput(Writer paramWriter)
  {
    throw new RuntimeException("Wbxml requires an OutputStream!");
  }
  
  public void setOutput(OutputStream paramOutputStream, String paramString)
    throws IOException
  {
    encoding = (paramString == null ? "UTF-8" : paramString);
    out = paramOutputStream;
    buf = new ByteArrayOutputStream();
    stringTableBuf = new ByteArrayOutputStream();
  }
  
  public void setPrefix(String paramString1, String paramString2)
  {
    throw new RuntimeException("NYI");
  }
  
  public void setProperty(String paramString, Object paramObject)
  {
    throw new IllegalArgumentException("unknown property " + paramString);
  }
  
  public void startDocument(String paramString, Boolean paramBoolean)
    throws IOException
  {
    out.write(3);
    out.write(1);
    if (paramString != null) {
      encoding = paramString;
    }
    if (encoding.toUpperCase().equals("UTF-8")) {
      out.write(106);
    } else if (encoding.toUpperCase().equals("ISO-8859-1")) {
      out.write(4);
    } else {
      throw new UnsupportedEncodingException(paramString);
    }
  }
  
  public XmlSerializer startTag(String paramString1, String paramString2)
    throws IOException
  {
    if ((paramString1 != null) && (!"".equals(paramString1))) {
      throw new RuntimeException("NSP NYI");
    }
    checkPending(false);
    pending = paramString2;
    depth += 1;
    return this;
  }
  
  public XmlSerializer text(char[] paramArrayOfChar, int paramInt1, int paramInt2)
    throws IOException
  {
    checkPending(false);
    writeStr(new String(paramArrayOfChar, paramInt1, paramInt2));
    return this;
  }
  
  public XmlSerializer text(String paramString)
    throws IOException
  {
    checkPending(false);
    writeStr(paramString);
    return this;
  }
  
  private void writeStr(String paramString)
    throws IOException
  {
    int i = 0;
    int j = 0;
    int k = paramString.length();
    while (i < k)
    {
      while ((i < k) && (paramString.charAt(i) < 'A')) {
        i++;
      }
      for (int m = i; (m < k) && (paramString.charAt(m) >= 'A'); m++) {}
      if (m - i > 10)
      {
        if ((i > j) && (paramString.charAt(i - 1) == ' ') && (stringTable.get(paramString.substring(i, m)) == null))
        {
          buf.write(131);
          writeStrT(paramString.substring(j, m), false);
        }
        else
        {
          if ((i > j) && (paramString.charAt(i - 1) == ' ')) {
            i--;
          }
          if (i > j)
          {
            buf.write(131);
            writeStrT(paramString.substring(j, i), false);
          }
          buf.write(131);
          writeStrT(paramString.substring(i, m), true);
        }
        j = m;
      }
      i = m;
    }
    if (j < k)
    {
      buf.write(131);
      writeStrT(paramString.substring(j, k), false);
    }
  }
  
  public XmlSerializer endTag(String paramString1, String paramString2)
    throws IOException
  {
    if (pending != null) {
      checkPending(true);
    } else {
      buf.write(1);
    }
    depth -= 1;
    return this;
  }
  
  public void writeWapExtension(int paramInt, Object paramObject)
    throws IOException
  {
    checkPending(false);
    buf.write(paramInt);
    switch (paramInt)
    {
    case 192: 
    case 193: 
    case 194: 
      break;
    case 195: 
      byte[] arrayOfByte = (byte[])paramObject;
      writeInt(buf, arrayOfByte.length);
      buf.write(arrayOfByte);
      break;
    case 64: 
    case 65: 
    case 66: 
      writeStrI(buf, (String)paramObject);
      break;
    case 128: 
    case 129: 
    case 130: 
      writeStrT((String)paramObject, false);
      break;
    default: 
      throw new IllegalArgumentException();
    }
  }
  
  static void writeInt(OutputStream paramOutputStream, int paramInt)
    throws IOException
  {
    byte[] arrayOfByte = new byte[5];
    int i = 0;
    do
    {
      arrayOfByte[(i++)] = ((byte)(paramInt & 0x7F));
      paramInt >>= 7;
    } while (paramInt != 0);
    while (i > 1) {
      paramOutputStream.write(arrayOfByte[(--i)] | 0x80);
    }
    paramOutputStream.write(arrayOfByte[0]);
  }
  
  void writeStrI(OutputStream paramOutputStream, String paramString)
    throws IOException
  {
    byte[] arrayOfByte = paramString.getBytes(encoding);
    paramOutputStream.write(arrayOfByte);
    paramOutputStream.write(0);
  }
  
  private final void writeStrT(String paramString, boolean paramBoolean)
    throws IOException
  {
    Integer localInteger = (Integer)stringTable.get(paramString);
    if (localInteger != null)
    {
      writeInt(buf, localInteger.intValue());
    }
    else
    {
      int i = stringTableBuf.size();
      if ((paramString.charAt(0) >= '0') && (paramBoolean))
      {
        paramString = ' ' + paramString;
        writeInt(buf, i + 1);
      }
      else
      {
        writeInt(buf, i);
      }
      stringTable.put(paramString, new Integer(i));
      if (paramString.charAt(0) == ' ') {
        stringTable.put(paramString.substring(1), new Integer(i + 1));
      }
      int j = paramString.lastIndexOf(' ');
      if (j > 1)
      {
        stringTable.put(paramString.substring(j), new Integer(i + j));
        stringTable.put(paramString.substring(j + 1), new Integer(i + j + 1));
      }
      writeStrI(stringTableBuf, paramString);
      stringTableBuf.flush();
    }
  }
  
  public void setTagTable(int paramInt, String[] paramArrayOfString)
  {
    for (int i = 0; i < paramArrayOfString.length; i++) {
      if (paramArrayOfString[i] != null)
      {
        int[] arrayOfInt = { paramInt, i + 5 };
        tagTable.put(paramArrayOfString[i], arrayOfInt);
      }
    }
  }
  
  public void setAttrStartTable(int paramInt, String[] paramArrayOfString)
  {
    for (int i = 0; i < paramArrayOfString.length; i++) {
      if (paramArrayOfString[i] != null)
      {
        int[] arrayOfInt = { paramInt, i + 5 };
        attrStartTable.put(paramArrayOfString[i], arrayOfInt);
      }
    }
  }
  
  public void setAttrValueTable(int paramInt, String[] paramArrayOfString)
  {
    for (int i = 0; i < paramArrayOfString.length; i++) {
      if (paramArrayOfString[i] != null)
      {
        int[] arrayOfInt = { paramInt, i + 133 };
        attrValueTable.put(paramArrayOfString[i], arrayOfInt);
      }
    }
  }
}
