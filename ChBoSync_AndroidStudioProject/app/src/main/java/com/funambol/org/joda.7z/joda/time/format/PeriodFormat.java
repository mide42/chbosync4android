package com.funambol.org.joda.time.format;

















public class PeriodFormat
{
  private static PeriodFormatter cEnglishWords;
  















  protected PeriodFormat() {}
  















  public static PeriodFormatter getDefault()
  {
    if (cEnglishWords == null) {
      String[] arrayOfString = { " ", ",", ",and ", ", and " };
      cEnglishWords = new PeriodFormatterBuilder().appendYears().appendSuffix(" year", " years").appendSeparator(", ", " and ", arrayOfString).appendMonths().appendSuffix(" month", " months").appendSeparator(", ", " and ", arrayOfString).appendWeeks().appendSuffix(" week", " weeks").appendSeparator(", ", " and ", arrayOfString).appendDays().appendSuffix(" day", " days").appendSeparator(", ", " and ", arrayOfString).appendHours().appendSuffix(" hour", " hours").appendSeparator(", ", " and ", arrayOfString).appendMinutes().appendSuffix(" minute", " minutes").appendSeparator(", ", " and ", arrayOfString).appendSeconds().appendSuffix(" second", " seconds").appendSeparator(", ", " and ", arrayOfString).appendMillis().appendSuffix(" millisecond", " milliseconds").toFormatter();
    }
    























    return cEnglishWords;
  }
}
