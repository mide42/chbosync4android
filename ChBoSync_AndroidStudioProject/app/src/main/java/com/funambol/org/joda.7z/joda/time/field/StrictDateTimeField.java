package com.funambol.org.joda.time.field;

import com.funambol.org.joda.time.DateTimeField;






























public class StrictDateTimeField
  extends DelegatedDateTimeField
{
  private static final long serialVersionUID = 3154803964207950910L;
  
  public static DateTimeField getInstance(DateTimeField paramDateTimeField)
  {
    if (paramDateTimeField == null) {
      return null;
    }
    if ((paramDateTimeField instanceof LenientDateTimeField)) {
      paramDateTimeField = ((LenientDateTimeField)paramDateTimeField).getWrappedField();
    }
    if (!paramDateTimeField.isLenient()) {
      return paramDateTimeField;
    }
    return new StrictDateTimeField(paramDateTimeField);
  }
  
  protected StrictDateTimeField(DateTimeField paramDateTimeField) {
    super(paramDateTimeField);
  }
  
  public final boolean isLenient() {
    return false;
  }
  




  public long set(long paramLong, int paramInt)
  {
    FieldUtils.verifyValueBounds(this, paramInt, getMinimumValue(paramLong), getMaximumValue(paramLong));
    
    return super.set(paramLong, paramInt);
  }
}
