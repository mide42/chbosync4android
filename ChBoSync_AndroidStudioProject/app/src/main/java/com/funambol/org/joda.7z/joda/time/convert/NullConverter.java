package com.funambol.org.joda.time.convert;

import com.funambol.org.joda.time.Chronology;
import com.funambol.org.joda.time.DateTimeUtils;
import com.funambol.org.joda.time.Period;
import com.funambol.org.joda.time.ReadWritableInterval;
import com.funambol.org.joda.time.ReadWritablePeriod;



























class NullConverter
  extends AbstractConverter
  implements InstantConverter, PartialConverter, DurationConverter, PeriodConverter, IntervalConverter
{
  static final NullConverter INSTANCE = new NullConverter();
  






  protected NullConverter() {}
  





  public long getDurationMillis(Object paramObject)
  {
    return 0L;
  }
  








  public void setInto(ReadWritablePeriod paramReadWritablePeriod, Object paramObject, Chronology paramChronology)
  {
    paramReadWritablePeriod.setPeriod((Period)null);
  }
  









  public void setInto(ReadWritableInterval paramReadWritableInterval, Object paramObject, Chronology paramChronology)
  {
    paramReadWritableInterval.setChronology(paramChronology);
    long l = DateTimeUtils.currentTimeMillis();
    paramReadWritableInterval.setInterval(l, l);
  }
  





  public Class getSupportedType()
  {
    return null;
  }
}
