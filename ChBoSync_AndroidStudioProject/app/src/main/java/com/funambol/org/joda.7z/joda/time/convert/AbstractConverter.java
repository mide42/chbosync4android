package com.funambol.org.joda.time.convert;

import com.funambol.org.joda.time.Chronology;
import com.funambol.org.joda.time.DateTimeUtils;
import com.funambol.org.joda.time.DateTimeZone;
import com.funambol.org.joda.time.PeriodType;
import com.funambol.org.joda.time.ReadablePartial;
import com.funambol.org.joda.time.chrono.ISOChronology;
import com.funambol.org.joda.time.format.DateTimeFormatter;



































public abstract class AbstractConverter
  implements Converter
{
  protected AbstractConverter() {}
  
  public long getInstantMillis(Object paramObject, Chronology paramChronology)
  {
    return DateTimeUtils.currentTimeMillis();
  }
  










  public Chronology getChronology(Object paramObject, DateTimeZone paramDateTimeZone)
  {
    return ISOChronology.getInstance(paramDateTimeZone);
  }
  










  public Chronology getChronology(Object paramObject, Chronology paramChronology)
  {
    return DateTimeUtils.getChronology(paramChronology);
  }
  














  public int[] getPartialValues(ReadablePartial paramReadablePartial, Object paramObject, Chronology paramChronology)
  {
    long l = getInstantMillis(paramObject, paramChronology);
    return paramChronology.get(paramReadablePartial, l);
  }
  
















  public int[] getPartialValues(ReadablePartial paramReadablePartial, Object paramObject, Chronology paramChronology, DateTimeFormatter paramDateTimeFormatter)
  {
    return getPartialValues(paramReadablePartial, paramObject, paramChronology);
  }
  






  public PeriodType getPeriodType(Object paramObject)
  {
    return PeriodType.standard();
  }
  









  public boolean isReadableInterval(Object paramObject, Chronology paramChronology)
  {
    return false;
  }
  





  public String toString()
  {
    return "Converter[" + (getSupportedType() == null ? "null" : getSupportedType().getName()) + "]";
  }
}
