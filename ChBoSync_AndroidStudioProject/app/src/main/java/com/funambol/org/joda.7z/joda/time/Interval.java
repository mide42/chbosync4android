package com.funambol.org.joda.time;

import java.io.Serializable;
import com.funambol.org.joda.time.base.BaseInterval;
import com.funambol.org.joda.time.chrono.ISOChronology;





















































public final class Interval
  extends BaseInterval
  implements ReadableInterval, Serializable
{
  private static final long serialVersionUID = 4922451897541386752L;
  
  public Interval(long paramLong1, long paramLong2)
  {
    super(paramLong1, paramLong2, null);
  }
  









  public Interval(long paramLong1, long paramLong2, DateTimeZone paramDateTimeZone)
  {
    super(paramLong1, paramLong2, ISOChronology.getInstance(paramDateTimeZone));
  }
  








  public Interval(long paramLong1, long paramLong2, Chronology paramChronology)
  {
    super(paramLong1, paramLong2, paramChronology);
  }
  








  public Interval(ReadableInstant paramReadableInstant1, ReadableInstant paramReadableInstant2)
  {
    super(paramReadableInstant1, paramReadableInstant2);
  }
  







  public Interval(ReadableInstant paramReadableInstant, ReadableDuration paramReadableDuration)
  {
    super(paramReadableInstant, paramReadableDuration);
  }
  







  public Interval(ReadableDuration paramReadableDuration, ReadableInstant paramReadableInstant)
  {
    super(paramReadableDuration, paramReadableInstant);
  }
  










  public Interval(ReadableInstant paramReadableInstant, ReadablePeriod paramReadablePeriod)
  {
    super(paramReadableInstant, paramReadablePeriod);
  }
  










  public Interval(ReadablePeriod paramReadablePeriod, ReadableInstant paramReadableInstant)
  {
    super(paramReadablePeriod, paramReadableInstant);
  }
  












  public Interval(Object paramObject)
  {
    super(paramObject, null);
  }
  














  public Interval(Object paramObject, Chronology paramChronology)
  {
    super(paramObject, paramChronology);
  }
  






  public Interval toInterval()
  {
    return this;
  }
  























  public Interval overlap(ReadableInterval paramReadableInterval)
  {
    paramReadableInterval = DateTimeUtils.getReadableInterval(paramReadableInterval);
    if (!overlaps(paramReadableInterval)) {
      return null;
    }
    long l1 = Math.max(getStartMillis(), paramReadableInterval.getStartMillis());
    long l2 = Math.min(getEndMillis(), paramReadableInterval.getEndMillis());
    return new Interval(l1, l2, getChronology());
  }
  
























  public Interval gap(ReadableInterval paramReadableInterval)
  {
    paramReadableInterval = DateTimeUtils.getReadableInterval(paramReadableInterval);
    long l1 = paramReadableInterval.getStartMillis();
    long l2 = paramReadableInterval.getEndMillis();
    long l3 = getStartMillis();
    long l4 = getEndMillis();
    if (l3 > l2)
      return new Interval(l2, l3, getChronology());
    if (l1 > l4) {
      return new Interval(l4, l1, getChronology());
    }
    return null;
  }
  





































  public boolean abuts(ReadableInterval paramReadableInterval)
  {
    if (paramReadableInterval == null) {
      long l = DateTimeUtils.currentTimeMillis();
      return (getStartMillis() == l) || (getEndMillis() == l);
    }
    return (paramReadableInterval.getEndMillis() == getStartMillis()) || (getEndMillis() == paramReadableInterval.getStartMillis());
  }
  








  public Interval withChronology(Chronology paramChronology)
  {
    if (getChronology() == paramChronology) {
      return this;
    }
    return new Interval(getStartMillis(), getEndMillis(), paramChronology);
  }
  






  public Interval withStartMillis(long paramLong)
  {
    if (paramLong == getStartMillis()) {
      return this;
    }
    return new Interval(paramLong, getEndMillis(), getChronology());
  }
  






  public Interval withStart(ReadableInstant paramReadableInstant)
  {
    long l = DateTimeUtils.getInstantMillis(paramReadableInstant);
    return withStartMillis(l);
  }
  






  public Interval withEndMillis(long paramLong)
  {
    if (paramLong == getEndMillis()) {
      return this;
    }
    return new Interval(getStartMillis(), paramLong, getChronology());
  }
  






  public Interval withEnd(ReadableInstant paramReadableInstant)
  {
    long l = DateTimeUtils.getInstantMillis(paramReadableInstant);
    return withEndMillis(l);
  }
  







  public Interval withDurationAfterStart(ReadableDuration paramReadableDuration)
  {
    long l1 = DateTimeUtils.getDurationMillis(paramReadableDuration);
    if (l1 == toDurationMillis()) {
      return this;
    }
    Chronology localChronology = getChronology();
    long l2 = getStartMillis();
    long l3 = localChronology.add(l2, l1, 1);
    return new Interval(l2, l3, localChronology);
  }
  






  public Interval withDurationBeforeEnd(ReadableDuration paramReadableDuration)
  {
    long l1 = DateTimeUtils.getDurationMillis(paramReadableDuration);
    if (l1 == toDurationMillis()) {
      return this;
    }
    Chronology localChronology = getChronology();
    long l2 = getEndMillis();
    long l3 = localChronology.add(l2, l1, -1);
    return new Interval(l3, l2, localChronology);
  }
  







  public Interval withPeriodAfterStart(ReadablePeriod paramReadablePeriod)
  {
    if (paramReadablePeriod == null) {
      return withDurationAfterStart(null);
    }
    Chronology localChronology = getChronology();
    long l1 = getStartMillis();
    long l2 = localChronology.add(paramReadablePeriod, l1, 1);
    return new Interval(l1, l2, localChronology);
  }
  






  public Interval withPeriodBeforeEnd(ReadablePeriod paramReadablePeriod)
  {
    if (paramReadablePeriod == null) {
      return withDurationBeforeEnd(null);
    }
    Chronology localChronology = getChronology();
    long l1 = getEndMillis();
    long l2 = localChronology.add(paramReadablePeriod, l1, -1);
    return new Interval(l2, l1, localChronology);
  }
}
