package com.funambol.org.joda.time;

import com.funambol.org.joda.time.chrono.BuddhistChronology;
import com.funambol.org.joda.time.chrono.CopticChronology;
import com.funambol.org.joda.time.chrono.GJChronology;
import com.funambol.org.joda.time.chrono.GregorianChronology;
import com.funambol.org.joda.time.chrono.ISOChronology;
import com.funambol.org.joda.time.chrono.JulianChronology;

































































public abstract class Chronology
{
  public Chronology() {}
  
  /**
   * @deprecated
   */
  public static Chronology getISO()
  {
    return ISOChronology.getInstance();
  }
  







  /**
   * @deprecated
   */
  public static Chronology getISOUTC()
  {
    return ISOChronology.getInstanceUTC();
  }
  








  /**
   * @deprecated
   */
  public static Chronology getISO(DateTimeZone paramDateTimeZone)
  {
    return ISOChronology.getInstance(paramDateTimeZone);
  }
  


















  /**
   * @deprecated
   */
  public static Chronology getGJ()
  {
    return GJChronology.getInstance();
  }
  

















  /**
   * @deprecated
   */
  public static Chronology getGJUTC()
  {
    return GJChronology.getInstanceUTC();
  }
  


















  /**
   * @deprecated
   */
  public static Chronology getGJ(DateTimeZone paramDateTimeZone)
  {
    return GJChronology.getInstance(paramDateTimeZone);
  }
  














  /**
   * @deprecated
   */
  public static Chronology getGregorian()
  {
    return GregorianChronology.getInstance();
  }
  













  /**
   * @deprecated
   */
  public static Chronology getGregorianUTC()
  {
    return GregorianChronology.getInstanceUTC();
  }
  














  /**
   * @deprecated
   */
  public static Chronology getGregorian(DateTimeZone paramDateTimeZone)
  {
    return GregorianChronology.getInstance(paramDateTimeZone);
  }
  







  /**
   * @deprecated
   */
  public static Chronology getJulian()
  {
    return JulianChronology.getInstance();
  }
  






  /**
   * @deprecated
   */
  public static Chronology getJulianUTC()
  {
    return JulianChronology.getInstanceUTC();
  }
  







  /**
   * @deprecated
   */
  public static Chronology getJulian(DateTimeZone paramDateTimeZone)
  {
    return JulianChronology.getInstance(paramDateTimeZone);
  }
  







  /**
   * @deprecated
   */
  public static Chronology getBuddhist()
  {
    return BuddhistChronology.getInstance();
  }
  






  /**
   * @deprecated
   */
  public static Chronology getBuddhistUTC()
  {
    return BuddhistChronology.getInstanceUTC();
  }
  







  /**
   * @deprecated
   */
  public static Chronology getBuddhist(DateTimeZone paramDateTimeZone)
  {
    return BuddhistChronology.getInstance(paramDateTimeZone);
  }
  











  /**
   * @deprecated
   */
  public static Chronology getCoptic()
  {
    return CopticChronology.getInstance();
  }
  










  /**
   * @deprecated
   */
  public static Chronology getCopticUTC()
  {
    return CopticChronology.getInstanceUTC();
  }
  











  /**
   * @deprecated
   */
  public static Chronology getCoptic(DateTimeZone paramDateTimeZone)
  {
    return CopticChronology.getInstance(paramDateTimeZone);
  }
  
  public abstract DateTimeZone getZone();
  
  public abstract Chronology withUTC();
  
  public abstract Chronology withZone(DateTimeZone paramDateTimeZone);
  
  public abstract long getDateTimeMillis(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public abstract long getDateTimeMillis(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7);
  
  public abstract long getDateTimeMillis(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public abstract void validate(ReadablePartial paramReadablePartial, int[] paramArrayOfInt);
  
  public abstract int[] get(ReadablePartial paramReadablePartial, long paramLong);
  
  public abstract long set(ReadablePartial paramReadablePartial, long paramLong);
  
  public abstract int[] get(ReadablePeriod paramReadablePeriod, long paramLong1, long paramLong2);
  
  public abstract int[] get(ReadablePeriod paramReadablePeriod, long paramLong);
  
  public abstract long add(ReadablePeriod paramReadablePeriod, long paramLong, int paramInt);
  
  public abstract long add(long paramLong1, long paramLong2, int paramInt);
  
  public abstract DurationField millis();
  
  public abstract DateTimeField millisOfSecond();
  
  public abstract DateTimeField millisOfDay();
  
  public abstract DurationField seconds();
  
  public abstract DateTimeField secondOfMinute();
  
  public abstract DateTimeField secondOfDay();
  
  public abstract DurationField minutes();
  
  public abstract DateTimeField minuteOfHour();
  
  public abstract DateTimeField minuteOfDay();
  
  public abstract DurationField hours();
  
  public abstract DateTimeField hourOfDay();
  
  public abstract DateTimeField clockhourOfDay();
  
  public abstract DurationField halfdays();
  
  public abstract DateTimeField hourOfHalfday();
  
  public abstract DateTimeField clockhourOfHalfday();
  
  public abstract DateTimeField halfdayOfDay();
  
  public abstract DurationField days();
  
  public abstract DateTimeField dayOfWeek();
  
  public abstract DateTimeField dayOfMonth();
  
  public abstract DateTimeField dayOfYear();
  
  public abstract DurationField weeks();
  
  public abstract DateTimeField weekOfWeekyear();
  
  public abstract DurationField weekyears();
  
  public abstract DateTimeField weekyear();
  
  public abstract DateTimeField weekyearOfCentury();
  
  public abstract DurationField months();
  
  public abstract DateTimeField monthOfYear();
  
  public abstract DurationField years();
  
  public abstract DateTimeField year();
  
  public abstract DateTimeField yearOfEra();
  
  public abstract DateTimeField yearOfCentury();
  
  public abstract DurationField centuries();
  
  public abstract DateTimeField centuryOfEra();
  
  public abstract DurationField eras();
  
  public abstract DateTimeField era();
  
  public abstract String toString();
}
