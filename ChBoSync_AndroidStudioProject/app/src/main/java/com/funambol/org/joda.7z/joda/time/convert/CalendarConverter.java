package com.funambol.org.joda.time.convert;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import com.funambol.org.joda.time.Chronology;
import com.funambol.org.joda.time.DateTimeZone;
import com.funambol.org.joda.time.chrono.BuddhistChronology;
import com.funambol.org.joda.time.chrono.GJChronology;
import com.funambol.org.joda.time.chrono.GregorianChronology;
import com.funambol.org.joda.time.chrono.ISOChronology;
import com.funambol.org.joda.time.chrono.JulianChronology;


























final class CalendarConverter
  extends AbstractConverter
  implements InstantConverter, PartialConverter
{
  static final CalendarConverter INSTANCE = new CalendarConverter();
  










  protected CalendarConverter() {}
  









  public Chronology getChronology(Object paramObject, Chronology paramChronology)
  {
    if (paramChronology != null) {
      return paramChronology;
    }
    Calendar localCalendar = (Calendar)paramObject;
    DateTimeZone localDateTimeZone = null;
    try {
      localDateTimeZone = DateTimeZone.forTimeZone(localCalendar.getTimeZone());
    }
    catch (IllegalArgumentException localIllegalArgumentException) {
      localDateTimeZone = DateTimeZone.getDefault();
    }
    return getChronology(localCalendar, localDateTimeZone);
  }
  










  public Chronology getChronology(Object paramObject, DateTimeZone paramDateTimeZone)
  {
    if (paramObject.getClass().getName().endsWith(".BuddhistCalendar"))
      return BuddhistChronology.getInstance(paramDateTimeZone);
    if ((paramObject instanceof GregorianCalendar)) {
      GregorianCalendar localGregorianCalendar = (GregorianCalendar)paramObject;
      long l = localGregorianCalendar.getGregorianChange().getTime();
      if (l == Long.MIN_VALUE)
        return GregorianChronology.getInstance(paramDateTimeZone);
      if (l == Long.MAX_VALUE) {
        return JulianChronology.getInstance(paramDateTimeZone);
      }
      return GJChronology.getInstance(paramDateTimeZone, l, 4);
    }
    
    return ISOChronology.getInstance(paramDateTimeZone);
  }
  









  public long getInstantMillis(Object paramObject, Chronology paramChronology)
  {
    Calendar localCalendar = (Calendar)paramObject;
    return localCalendar.getTime().getTime();
  }
  





  public Class getSupportedType()
  {
    return Calendar.class;
  }
}
