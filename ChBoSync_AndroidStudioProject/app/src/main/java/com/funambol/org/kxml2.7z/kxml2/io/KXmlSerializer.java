package com.funambol.org.kxml2.io;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import org.xmlpull.v1.XmlSerializer;

public class KXmlSerializer
  implements XmlSerializer
{
  private Writer writer;
  private boolean pending;
  private int auto;
  private int depth;
  private String[] elementStack = new String[12];
  private int[] nspCounts = new int[4];
  private String[] nspStack = new String[8];
  private boolean[] indent = new boolean[4];
  private boolean unicode;
  private String encoding;
  
  public KXmlSerializer() {}
  
  private final void check(boolean paramBoolean)
    throws IOException
  {
    if (!pending) {
      return;
    }
    depth += 1;
    pending = false;
    if (indent.length <= depth)
    {
      boolean[] arrayOfBoolean = new boolean[depth + 4];
      System.arraycopy(indent, 0, arrayOfBoolean, 0, depth);
      indent = arrayOfBoolean;
    }
    indent[depth] = indent[(depth - 1)];
    for (int i = nspCounts[(depth - 1)]; i < nspCounts[depth]; i++)
    {
      writer.write(32);
      writer.write("xmlns");
      if (!"".equals(nspStack[(i * 2)]))
      {
        writer.write(58);
        writer.write(nspStack[(i * 2)]);
      }
      else if (("".equals(getNamespace())) && (!"".equals(nspStack[(i * 2 + 1)])))
      {
        throw new IllegalStateException("Cannot set default namespace for elements in no namespace");
      }
      writer.write("=\"");
      writeEscaped(nspStack[(i * 2 + 1)], 34);
      writer.write(34);
    }
    if (nspCounts.length <= depth + 1)
    {
      int[] arrayOfInt = new int[depth + 8];
      System.arraycopy(nspCounts, 0, arrayOfInt, 0, depth + 1);
      nspCounts = arrayOfInt;
    }
    nspCounts[(depth + 1)] = nspCounts[depth];
    writer.write(paramBoolean ? " />" : ">");
  }
  
  private final void writeEscaped(String paramString, int paramInt)
    throws IOException
  {
    for (int i = 0; i < paramString.length(); i++)
    {
      int j = paramString.charAt(i);
      switch (j)
      {
      case 9: 
      case 10: 
      case 13: 
        if (paramInt == -1) {
          writer.write(j);
        } else {
          writer.write("&#" + j + ';');
        }
        break;
      case 38: 
        writer.write("&amp;");
        break;
      case 62: 
        writer.write("&gt;");
        break;
      case 60: 
        writer.write("&lt;");
        break;
      case 34: 
      case 39: 
        if (j == paramInt) {
          writer.write(j == 34 ? "&quot;" : "&apos;");
        }
        break;
      }
      if ((j >= 32) && (j != 64) && ((j < 127) || (unicode))) {
        writer.write(j);
      } else {
        writer.write("&#" + j + ";");
      }
    }
  }
  
  public void docdecl(String paramString)
    throws IOException
  {
    writer.write("<!DOCTYPE");
    writer.write(paramString);
    writer.write(">");
  }
  
  public void endDocument()
    throws IOException
  {
    while (depth > 0) {
      endTag(elementStack[(depth * 3 - 3)], elementStack[(depth * 3 - 1)]);
    }
    flush();
  }
  
  public void entityRef(String paramString)
    throws IOException
  {
    check(false);
    writer.write(38);
    writer.write(paramString);
    writer.write(59);
  }
  
  public boolean getFeature(String paramString)
  {
    return "http://xmlpull.org/v1/doc/features.html#indent-output".equals(paramString) ? indent[depth] : false;
  }
  
  public String getPrefix(String paramString, boolean paramBoolean)
  {
    try
    {
      return getPrefix(paramString, false, paramBoolean);
    }
    catch (IOException localIOException)
    {
      throw new RuntimeException(localIOException.toString());
    }
  }
  
  private final String getPrefix(String paramString, boolean paramBoolean1, boolean paramBoolean2)
    throws IOException
  {
    for (int i = nspCounts[(depth + 1)] * 2 - 2; i >= 0; i -= 2) {
      if ((nspStack[(i + 1)].equals(paramString)) && ((paramBoolean1) || (!nspStack[i].equals(""))))
      {
        String str2 = nspStack[i];
        for (int k = i + 2; k < nspCounts[(depth + 1)] * 2; k++) {
          if (nspStack[k].equals(str2))
          {
            str2 = null;
            break;
          }
        }
        if (str2 != null) {
          return str2;
        }
      }
    }
    if (!paramBoolean2) {
      return null;
    }
    String str1;
    if ("".equals(paramString)) {
      str1 = "";
    } else {
      do
      {
        str1 = "n" + auto++;
        for (int j = nspCounts[(depth + 1)] * 2 - 2; j >= 0; j -= 2) {
          if (str1.equals(nspStack[j]))
          {
            str1 = null;
            break;
          }
        }
      } while (str1 == null);
    }
    boolean bool = pending;
    pending = false;
    setPrefix(str1, paramString);
    pending = bool;
    return str1;
  }
  
  public Object getProperty(String paramString)
  {
    throw new RuntimeException("Unsupported property");
  }
  
  public void ignorableWhitespace(String paramString)
    throws IOException
  {
    text(paramString);
  }
  
  public void setFeature(String paramString, boolean paramBoolean)
  {
    if ("http://xmlpull.org/v1/doc/features.html#indent-output".equals(paramString)) {
      indent[depth] = paramBoolean;
    } else {
      throw new RuntimeException("Unsupported Feature");
    }
  }
  
  public void setProperty(String paramString, Object paramObject)
  {
    throw new RuntimeException("Unsupported Property:" + paramObject);
  }
  
  public void setPrefix(String paramString1, String paramString2)
    throws IOException
  {
    check(false);
    if (paramString1 == null) {
      paramString1 = "";
    }
    if (paramString2 == null) {
      paramString2 = "";
    }
    String str = getPrefix(paramString2, true, false);
    if (paramString1.equals(str)) {
      return;
    }
    int tmp46_45 = (depth + 1);
    int[] tmp46_37 = nspCounts;
    int tmp48_47 = tmp46_37[tmp46_45];
    tmp46_37[tmp46_45] = (tmp48_47 + 1);
    int i = tmp48_47 << 1;
    if (nspStack.length < i + 1)
    {
      String[] arrayOfString = new String[nspStack.length + 16];
      System.arraycopy(nspStack, 0, arrayOfString, 0, i);
      nspStack = arrayOfString;
    }
    nspStack[(i++)] = paramString1;
    nspStack[i] = paramString2;
  }
  
  public void setOutput(Writer paramWriter)
  {
    writer = paramWriter;
    nspCounts[0] = 2;
    nspCounts[1] = 2;
    nspStack[0] = "";
    nspStack[1] = "";
    nspStack[2] = "xml";
    nspStack[3] = "http://www.w3.org/XML/1998/namespace";
    pending = false;
    auto = 0;
    depth = 0;
    unicode = false;
  }
  
  public void setOutput(OutputStream paramOutputStream, String paramString)
    throws IOException
  {
    if (paramOutputStream == null) {
      throw new IllegalArgumentException();
    }
    setOutput(paramString == null ? new OutputStreamWriter(paramOutputStream) : new OutputStreamWriter(paramOutputStream, paramString));
    encoding = paramString;
    if ((paramString != null) && (paramString.toLowerCase().startsWith("utf"))) {
      unicode = true;
    }
  }
  
  public void startDocument(String paramString, Boolean paramBoolean)
    throws IOException
  {
    writer.write("<?xml version='1.0' ");
    if (paramString != null)
    {
      encoding = paramString;
      if (paramString.toLowerCase().startsWith("utf")) {
        unicode = true;
      }
    }
    if (encoding != null)
    {
      writer.write("encoding='");
      writer.write(encoding);
      writer.write("' ");
    }
    if (paramBoolean != null)
    {
      writer.write("standalone='");
      writer.write(paramBoolean.booleanValue() ? "yes" : "no");
      writer.write("' ");
    }
    writer.write("?>");
  }
  
  public XmlSerializer startTag(String paramString1, String paramString2)
    throws IOException
  {
    check(false);
    if (indent[depth] != 0)
    {
      writer.write("\r\n");
      for (i = 0; i < depth; i++) {
        writer.write("  ");
      }
    }
    int i = depth * 3;
    if (elementStack.length < i + 3)
    {
      localObject = new String[elementStack.length + 12];
      System.arraycopy(elementStack, 0, localObject, 0, i);
      elementStack = ((String[])localObject);
    }
    Object localObject = paramString1 == null ? "" : getPrefix(paramString1, true, true);
    if ("".equals(paramString1)) {
      for (int j = nspCounts[depth]; j < nspCounts[(depth + 1)]; j++) {
        if (("".equals(nspStack[(j * 2)])) && (!"".equals(nspStack[(j * 2 + 1)]))) {
          throw new IllegalStateException("Cannot set default namespace for elements in no namespace");
        }
      }
    }
    elementStack[(i++)] = paramString1;
    elementStack[(i++)] = localObject;
    elementStack[i] = paramString2;
    writer.write(60);
    if (!"".equals(localObject))
    {
      writer.write((String)localObject);
      writer.write(58);
    }
    writer.write(paramString2);
    pending = true;
    return this;
  }
  
  public XmlSerializer attribute(String paramString1, String paramString2, String paramString3)
    throws IOException
  {
    if (!pending) {
      throw new IllegalStateException("illegal position for attribute");
    }
    if (paramString1 == null) {
      paramString1 = "";
    }
    String str = "".equals(paramString1) ? "" : getPrefix(paramString1, false, true);
    writer.write(32);
    if (!"".equals(str))
    {
      writer.write(str);
      writer.write(58);
    }
    writer.write(paramString2);
    writer.write(61);
    int i = paramString3.indexOf('"') == -1 ? 34 : 39;
    writer.write(i);
    writeEscaped(paramString3, i);
    writer.write(i);
    return this;
  }
  
  public void flush()
    throws IOException
  {
    check(false);
    writer.flush();
  }
  
  public XmlSerializer endTag(String paramString1, String paramString2)
    throws IOException
  {
    if (!pending) {
      depth -= 1;
    }
    if (((paramString1 == null) && (elementStack[(depth * 3)] != null)) || ((paramString1 != null) && (!paramString1.equals(elementStack[(depth * 3)]))) || (!elementStack[(depth * 3 + 2)].equals(paramString2))) {
      throw new IllegalArgumentException("</{" + paramString1 + "}" + paramString2 + "> does not match start");
    }
    if (pending)
    {
      check(true);
      depth -= 1;
    }
    else
    {
      if (indent[(depth + 1)] != 0)
      {
        writer.write("\r\n");
        for (int i = 0; i < depth; i++) {
          writer.write("  ");
        }
      }
      writer.write("</");
      String str = elementStack[(depth * 3 + 1)];
      if (!"".equals(str))
      {
        writer.write(str);
        writer.write(58);
      }
      writer.write(paramString2);
      writer.write(62);
    }
    nspCounts[(depth + 1)] = nspCounts[depth];
    return this;
  }
  
  public String getNamespace()
  {
    return getDepth() == 0 ? null : elementStack[(getDepth() * 3 - 3)];
  }
  
  public String getName()
  {
    return getDepth() == 0 ? null : elementStack[(getDepth() * 3 - 1)];
  }
  
  public int getDepth()
  {
    return pending ? depth + 1 : depth;
  }
  
  public XmlSerializer text(String paramString)
    throws IOException
  {
    check(false);
    indent[depth] = false;
    writeEscaped(paramString, -1);
    return this;
  }
  
  public XmlSerializer text(char[] paramArrayOfChar, int paramInt1, int paramInt2)
    throws IOException
  {
    text(new String(paramArrayOfChar, paramInt1, paramInt2));
    return this;
  }
  
  public void cdsect(String paramString)
    throws IOException
  {
    check(false);
    writer.write("<![CDATA[");
    writer.write(paramString);
    writer.write("]]>");
  }
  
  public XmlSerializer plainText(String paramString)
    throws IOException
  {
    check(false);
    writer.write(paramString);
    return this;
  }
  
  public void comment(String paramString)
    throws IOException
  {
    check(false);
    writer.write("<!--");
    writer.write(paramString);
    writer.write("-->");
  }
  
  public void processingInstruction(String paramString)
    throws IOException
  {
    check(false);
    writer.write("<?");
    writer.write(paramString);
    writer.write("?>");
  }
}
