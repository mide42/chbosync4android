package com.funambol.org.joda.time.convert;

import com.funambol.org.joda.time.Chronology;
import com.funambol.org.joda.time.PeriodType;
import com.funambol.org.joda.time.ReadWritablePeriod;

public abstract interface PeriodConverter
  extends Converter
{
  public abstract void setInto(ReadWritablePeriod paramReadWritablePeriod, Object paramObject, Chronology paramChronology);
  
  public abstract PeriodType getPeriodType(Object paramObject);
}
