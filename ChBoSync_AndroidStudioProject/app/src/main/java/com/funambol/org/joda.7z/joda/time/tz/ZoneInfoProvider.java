package com.funambol.org.joda.time.tz;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.SoftReference;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import com.funambol.org.joda.time.DateTimeZone;
































public class ZoneInfoProvider
  implements Provider
{
  private final File iFileDir;
  private final String iResourcePath;
  private final ClassLoader iLoader;
  private final Map iZoneInfoMap;
  
  public ZoneInfoProvider(File paramFile)
    throws IOException
  {
    if (paramFile == null) {
      throw new IllegalArgumentException("No file directory provided");
    }
    if (!paramFile.exists()) {
      throw new IOException("File directory doesn't exist: " + paramFile);
    }
    if (!paramFile.isDirectory()) {
      throw new IOException("File doesn't refer to a directory: " + paramFile);
    }
    
    iFileDir = paramFile;
    iResourcePath = null;
    iLoader = null;
    
    iZoneInfoMap = loadZoneInfoMap(openResource("ZoneInfoMap"));
  }
  





  public ZoneInfoProvider(String paramString)
    throws IOException
  {
    this(paramString, null, false);
  }
  








  public ZoneInfoProvider(String paramString, ClassLoader paramClassLoader)
    throws IOException
  {
    this(paramString, paramClassLoader, true);
  }
  





  private ZoneInfoProvider(String paramString, ClassLoader paramClassLoader, boolean paramBoolean)
    throws IOException
  {
    if (paramString == null) {
      throw new IllegalArgumentException("No resource path provided");
    }
    if (!paramString.endsWith("/")) {
      paramString = paramString + '/';
    }
    
    iFileDir = null;
    iResourcePath = paramString;
    
    if ((paramClassLoader == null) && (!paramBoolean)) {
      paramClassLoader = getClass().getClassLoader();
    }
    
    iLoader = paramClassLoader;
    
    iZoneInfoMap = loadZoneInfoMap(openResource("ZoneInfoMap"));
  }
  








  public synchronized DateTimeZone getZone(String paramString)
  {
    if (paramString == null) {
      return null;
    }
    
    Object localObject = iZoneInfoMap.get(paramString);
    if (localObject == null) {
      return null;
    }
    
    if (paramString.equals(localObject))
    {
      return loadZoneData(paramString);
    }
    
    if ((localObject instanceof SoftReference)) {
      DateTimeZone localDateTimeZone = (DateTimeZone)((SoftReference)localObject).get();
      if (localDateTimeZone != null) {
        return localDateTimeZone;
      }
      
      return loadZoneData(paramString);
    }
    

    return getZone((String)localObject);
  }
  







  public synchronized Set getAvailableIDs()
  {
    return new TreeSet(iZoneInfoMap.keySet());
  }
  




  protected void uncaughtException(Exception paramException)
  {
    Thread localThread = Thread.currentThread();
    localThread.getThreadGroup().uncaughtException(localThread, paramException);
  }
  



  private InputStream openResource(String paramString)
    throws IOException
  {
    Object localObject;
    

    if (iFileDir != null) {
      localObject = new FileInputStream(new File(iFileDir, paramString));
    } else {
      String str = iResourcePath.concat(paramString);
      if (iLoader != null) {
        localObject = iLoader.getResourceAsStream(str);
      } else {
        localObject = ClassLoader.getSystemResourceAsStream(str);
      }
      if (localObject == null) {
        StringBuffer localStringBuffer = new StringBuffer(40).append("Resource not found: \"").append(str).append("\" ClassLoader: ").append(iLoader != null ? iLoader.toString() : "system");
        



        throw new IOException(localStringBuffer.toString());
      }
    }
    return localObject;
  }
  





  private DateTimeZone loadZoneData(String paramString)
  {
    InputStream localInputStream = null;
    try {
      localInputStream = openResource(paramString);
      DateTimeZone localDateTimeZone1 = DateTimeZoneBuilder.readFrom(localInputStream, paramString);
      iZoneInfoMap.put(paramString, new SoftReference(localDateTimeZone1));
      return localDateTimeZone1;
    } catch (IOException localIOException1) { DateTimeZone localDateTimeZone2;
      uncaughtException(localIOException1);
      iZoneInfoMap.remove(paramString);
      return null;
    } finally {
      try {
        if (localInputStream != null) {
          localInputStream.close();
        }
      }
      catch (IOException localIOException2) {}
    }
  }
  





  private static Map loadZoneInfoMap(InputStream paramInputStream)
    throws IOException
  {
    TreeMap localTreeMap = new TreeMap(String.CASE_INSENSITIVE_ORDER);
    DataInputStream localDataInputStream = new DataInputStream(paramInputStream);
    try {
      readZoneInfoMap(localDataInputStream, localTreeMap);
      try
      {
        localDataInputStream.close();
      }
      catch (IOException localIOException1) {}
      
      localTreeMap.put("UTC", new SoftReference(DateTimeZone.UTC));
    }
    finally
    {
      try
      {
        localDataInputStream.close();
      }
      catch (IOException localIOException2) {}
    }
    
    return localTreeMap;
  }
  





  private static void readZoneInfoMap(DataInputStream paramDataInputStream, Map paramMap)
    throws IOException
  {
    int i = paramDataInputStream.readUnsignedShort();
    String[] arrayOfString = new String[i];
    for (int j = 0; j < i; j++) {
      arrayOfString[j] = paramDataInputStream.readUTF().intern();
    }
    

    i = paramDataInputStream.readUnsignedShort();
    for (j = 0; j < i; j++) {
      try {
        paramMap.put(arrayOfString[paramDataInputStream.readUnsignedShort()], arrayOfString[paramDataInputStream.readUnsignedShort()]);
      } catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException) {
        throw new IOException("Corrupt zone info map");
      }
    }
  }
}
