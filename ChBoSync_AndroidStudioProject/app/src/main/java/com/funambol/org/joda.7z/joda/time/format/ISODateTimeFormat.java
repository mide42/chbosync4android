package com.funambol.org.joda.time.format;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import com.funambol.org.joda.time.DateTimeFieldType;
import com.funambol.org.joda.time.DateTimeZone;





























































































































































public class ISODateTimeFormat
{
  private static DateTimeFormatter ye;
  private static DateTimeFormatter mye;
  private static DateTimeFormatter dme;
  private static DateTimeFormatter we;
  private static DateTimeFormatter wwe;
  private static DateTimeFormatter dwe;
  private static DateTimeFormatter dye;
  private static DateTimeFormatter hde;
  private static DateTimeFormatter mhe;
  private static DateTimeFormatter sme;
  private static DateTimeFormatter fse;
  private static DateTimeFormatter ze;
  private static DateTimeFormatter lte;
  private static DateTimeFormatter ym;
  private static DateTimeFormatter ymd;
  private static DateTimeFormatter ww;
  private static DateTimeFormatter wwd;
  private static DateTimeFormatter hm;
  private static DateTimeFormatter hms;
  private static DateTimeFormatter hmsl;
  private static DateTimeFormatter hmsf;
  private static DateTimeFormatter dh;
  private static DateTimeFormatter dhm;
  private static DateTimeFormatter dhms;
  private static DateTimeFormatter dhmsl;
  private static DateTimeFormatter dhmsf;
  private static DateTimeFormatter t;
  private static DateTimeFormatter tx;
  private static DateTimeFormatter tt;
  private static DateTimeFormatter ttx;
  private static DateTimeFormatter dt;
  private static DateTimeFormatter dtx;
  private static DateTimeFormatter wdt;
  private static DateTimeFormatter wdtx;
  private static DateTimeFormatter od;
  private static DateTimeFormatter odt;
  private static DateTimeFormatter odtx;
  private static DateTimeFormatter bd;
  private static DateTimeFormatter bt;
  private static DateTimeFormatter btx;
  private static DateTimeFormatter btt;
  private static DateTimeFormatter bttx;
  private static DateTimeFormatter bdt;
  private static DateTimeFormatter bdtx;
  private static DateTimeFormatter bod;
  private static DateTimeFormatter bodt;
  private static DateTimeFormatter bodtx;
  private static DateTimeFormatter bwd;
  private static DateTimeFormatter bwdt;
  private static DateTimeFormatter bwdtx;
  private static DateTimeFormatter dpe;
  private static DateTimeFormatter tpe;
  private static DateTimeFormatter dp;
  private static DateTimeFormatter ldp;
  private static DateTimeFormatter tp;
  private static DateTimeFormatter ltp;
  private static DateTimeFormatter dtp;
  private static DateTimeFormatter dotp;
  private static DateTimeFormatter ldotp;
  
  protected ISODateTimeFormat() {}
  
  public static DateTimeFormatter forFields(Collection paramCollection, boolean paramBoolean1, boolean paramBoolean2)
  {
    if ((paramCollection == null) || (paramCollection.size() == 0)) {
      throw new IllegalArgumentException("The fields must not be null or empty");
    }
    HashSet localHashSet = new HashSet(paramCollection);
    int i = localHashSet.size();
    boolean bool1 = false;
    DateTimeFormatterBuilder localDateTimeFormatterBuilder = new DateTimeFormatterBuilder();
    
    if (localHashSet.contains(DateTimeFieldType.monthOfYear())) {
      bool1 = dateByMonth(localDateTimeFormatterBuilder, localHashSet, paramBoolean1, paramBoolean2);
    } else if (localHashSet.contains(DateTimeFieldType.dayOfYear())) {
      bool1 = dateByOrdinal(localDateTimeFormatterBuilder, localHashSet, paramBoolean1, paramBoolean2);
    } else if (localHashSet.contains(DateTimeFieldType.weekOfWeekyear())) {
      bool1 = dateByWeek(localDateTimeFormatterBuilder, localHashSet, paramBoolean1, paramBoolean2);
    } else if (localHashSet.contains(DateTimeFieldType.dayOfMonth())) {
      bool1 = dateByMonth(localDateTimeFormatterBuilder, localHashSet, paramBoolean1, paramBoolean2);
    } else if (localHashSet.contains(DateTimeFieldType.dayOfWeek())) {
      bool1 = dateByWeek(localDateTimeFormatterBuilder, localHashSet, paramBoolean1, paramBoolean2);
    } else if (localHashSet.remove(DateTimeFieldType.year())) {
      localDateTimeFormatterBuilder.append(yearElement());
      bool1 = true;
    } else if (localHashSet.remove(DateTimeFieldType.weekyear())) {
      localDateTimeFormatterBuilder.append(weekyearElement());
      bool1 = true;
    }
    boolean bool2 = localHashSet.size() < i;
    

    time(localDateTimeFormatterBuilder, localHashSet, paramBoolean1, paramBoolean2, bool1, bool2);
    

    if (!localDateTimeFormatterBuilder.canBuildFormatter()) {
      throw new IllegalArgumentException("No valid format for fields: " + paramCollection);
    }
    

    try
    {
      paramCollection.retainAll(localHashSet);
    }
    catch (UnsupportedOperationException localUnsupportedOperationException) {}
    
    return localDateTimeFormatterBuilder.toFormatter();
  }
  
















  private static boolean dateByMonth(DateTimeFormatterBuilder paramDateTimeFormatterBuilder, Collection paramCollection, boolean paramBoolean1, boolean paramBoolean2)
  {
    boolean bool = false;
    if (paramCollection.remove(DateTimeFieldType.year())) {
      paramDateTimeFormatterBuilder.append(yearElement());
      if (paramCollection.remove(DateTimeFieldType.monthOfYear())) {
        if (paramCollection.remove(DateTimeFieldType.dayOfMonth()))
        {
          appendSeparator(paramDateTimeFormatterBuilder, paramBoolean1);
          paramDateTimeFormatterBuilder.appendMonthOfYear(2);
          appendSeparator(paramDateTimeFormatterBuilder, paramBoolean1);
          paramDateTimeFormatterBuilder.appendDayOfMonth(2);
        }
        else {
          paramDateTimeFormatterBuilder.appendLiteral('-');
          paramDateTimeFormatterBuilder.appendMonthOfYear(2);
          bool = true;
        }
      }
      else if (paramCollection.remove(DateTimeFieldType.dayOfMonth()))
      {
        checkNotStrictISO(paramCollection, paramBoolean2);
        paramDateTimeFormatterBuilder.appendLiteral('-');
        paramDateTimeFormatterBuilder.appendLiteral('-');
        paramDateTimeFormatterBuilder.appendDayOfMonth(2);
      }
      else {
        bool = true;
      }
      
    }
    else if (paramCollection.remove(DateTimeFieldType.monthOfYear())) {
      paramDateTimeFormatterBuilder.appendLiteral('-');
      paramDateTimeFormatterBuilder.appendLiteral('-');
      paramDateTimeFormatterBuilder.appendMonthOfYear(2);
      if (paramCollection.remove(DateTimeFieldType.dayOfMonth()))
      {
        appendSeparator(paramDateTimeFormatterBuilder, paramBoolean1);
        paramDateTimeFormatterBuilder.appendDayOfMonth(2);
      }
      else {
        bool = true;
      }
    } else if (paramCollection.remove(DateTimeFieldType.dayOfMonth()))
    {
      paramDateTimeFormatterBuilder.appendLiteral('-');
      paramDateTimeFormatterBuilder.appendLiteral('-');
      paramDateTimeFormatterBuilder.appendLiteral('-');
      paramDateTimeFormatterBuilder.appendDayOfMonth(2);
    }
    return bool;
  }
  















  private static boolean dateByOrdinal(DateTimeFormatterBuilder paramDateTimeFormatterBuilder, Collection paramCollection, boolean paramBoolean1, boolean paramBoolean2)
  {
    boolean bool = false;
    if (paramCollection.remove(DateTimeFieldType.year())) {
      paramDateTimeFormatterBuilder.append(yearElement());
      if (paramCollection.remove(DateTimeFieldType.dayOfYear()))
      {
        appendSeparator(paramDateTimeFormatterBuilder, paramBoolean1);
        paramDateTimeFormatterBuilder.appendDayOfYear(3);
      }
      else {
        bool = true;
      }
    }
    else if (paramCollection.remove(DateTimeFieldType.dayOfYear()))
    {
      paramDateTimeFormatterBuilder.appendLiteral('-');
      paramDateTimeFormatterBuilder.appendDayOfYear(3);
    }
    return bool;
  }
  















  private static boolean dateByWeek(DateTimeFormatterBuilder paramDateTimeFormatterBuilder, Collection paramCollection, boolean paramBoolean1, boolean paramBoolean2)
  {
    boolean bool = false;
    if (paramCollection.remove(DateTimeFieldType.weekyear())) {
      paramDateTimeFormatterBuilder.append(weekyearElement());
      if (paramCollection.remove(DateTimeFieldType.weekOfWeekyear())) {
        appendSeparator(paramDateTimeFormatterBuilder, paramBoolean1);
        paramDateTimeFormatterBuilder.appendLiteral('W');
        paramDateTimeFormatterBuilder.appendWeekOfWeekyear(2);
        if (paramCollection.remove(DateTimeFieldType.dayOfWeek()))
        {
          appendSeparator(paramDateTimeFormatterBuilder, paramBoolean1);
          paramDateTimeFormatterBuilder.appendDayOfWeek(1);
        }
        else {
          bool = true;
        }
      }
      else if (paramCollection.remove(DateTimeFieldType.dayOfWeek()))
      {
        checkNotStrictISO(paramCollection, paramBoolean2);
        appendSeparator(paramDateTimeFormatterBuilder, paramBoolean1);
        paramDateTimeFormatterBuilder.appendLiteral('W');
        paramDateTimeFormatterBuilder.appendLiteral('-');
        paramDateTimeFormatterBuilder.appendDayOfWeek(1);
      }
      else {
        bool = true;
      }
      
    }
    else if (paramCollection.remove(DateTimeFieldType.weekOfWeekyear())) {
      paramDateTimeFormatterBuilder.appendLiteral('-');
      paramDateTimeFormatterBuilder.appendLiteral('W');
      paramDateTimeFormatterBuilder.appendWeekOfWeekyear(2);
      if (paramCollection.remove(DateTimeFieldType.dayOfWeek()))
      {
        appendSeparator(paramDateTimeFormatterBuilder, paramBoolean1);
        paramDateTimeFormatterBuilder.appendDayOfWeek(1);
      }
      else {
        bool = true;
      }
    } else if (paramCollection.remove(DateTimeFieldType.dayOfWeek()))
    {
      paramDateTimeFormatterBuilder.appendLiteral('-');
      paramDateTimeFormatterBuilder.appendLiteral('W');
      paramDateTimeFormatterBuilder.appendLiteral('-');
      paramDateTimeFormatterBuilder.appendDayOfWeek(1);
    }
    return bool;
  }
  



















  private static void time(DateTimeFormatterBuilder paramDateTimeFormatterBuilder, Collection paramCollection, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4)
  {
    boolean bool1 = paramCollection.remove(DateTimeFieldType.hourOfDay());
    boolean bool2 = paramCollection.remove(DateTimeFieldType.minuteOfHour());
    boolean bool3 = paramCollection.remove(DateTimeFieldType.secondOfMinute());
    boolean bool4 = paramCollection.remove(DateTimeFieldType.millisOfSecond());
    if ((!bool1) && (!bool2) && (!bool3) && (!bool4)) {
      return;
    }
    if ((bool1) || (bool2) || (bool3) || (bool4)) {
      if ((paramBoolean2) && (paramBoolean3)) {
        throw new IllegalArgumentException("No valid ISO8601 format for fields because Date was reduced precision: " + paramCollection);
      }
      if (paramBoolean4) {
        paramDateTimeFormatterBuilder.appendLiteral('T');
      }
    }
    if (((!bool1) || (!bool2) || (!bool3)) && ((!bool1) || (bool3) || (bool4)))
    {

      if ((paramBoolean2) && (paramBoolean4)) {
        throw new IllegalArgumentException("No valid ISO8601 format for fields because Time was truncated: " + paramCollection);
      }
      if ((bool1) || (((!bool2) || (!bool3)) && ((!bool2) || (bool4)) && (!bool3)))
      {

        if (paramBoolean2) {
          throw new IllegalArgumentException("No valid ISO8601 format for fields: " + paramCollection);
        }
      }
    }
    if (bool1) {
      paramDateTimeFormatterBuilder.appendHourOfDay(2);
    } else if ((bool2) || (bool3) || (bool4)) {
      paramDateTimeFormatterBuilder.appendLiteral('-');
    }
    if ((paramBoolean1) && (bool1) && (bool2)) {
      paramDateTimeFormatterBuilder.appendLiteral(':');
    }
    if (bool2) {
      paramDateTimeFormatterBuilder.appendMinuteOfHour(2);
    } else if ((bool3) || (bool4)) {
      paramDateTimeFormatterBuilder.appendLiteral('-');
    }
    if ((paramBoolean1) && (bool2) && (bool3)) {
      paramDateTimeFormatterBuilder.appendLiteral(':');
    }
    if (bool3) {
      paramDateTimeFormatterBuilder.appendSecondOfMinute(2);
    } else if (bool4) {
      paramDateTimeFormatterBuilder.appendLiteral('-');
    }
    if (bool4) {
      paramDateTimeFormatterBuilder.appendLiteral('.');
      paramDateTimeFormatterBuilder.appendMillisOfSecond(3);
    }
  }
  







  private static void checkNotStrictISO(Collection paramCollection, boolean paramBoolean)
  {
    if (paramBoolean) {
      throw new IllegalArgumentException("No valid ISO8601 format for fields: " + paramCollection);
    }
  }
  







  private static void appendSeparator(DateTimeFormatterBuilder paramDateTimeFormatterBuilder, boolean paramBoolean)
  {
    if (paramBoolean) {
      paramDateTimeFormatterBuilder.appendLiteral('-');
    }
  }
  












  public static DateTimeFormatter dateParser()
  {
    if (dp == null) {
      DateTimeParser localDateTimeParser = new DateTimeFormatterBuilder().appendLiteral('T').append(offsetElement()).toParser();
      

      dp = new DateTimeFormatterBuilder().append(dateElementParser()).appendOptional(localDateTimeParser).toFormatter();
    }
    


    return dp;
  }
  












  public static DateTimeFormatter localDateParser()
  {
    if (ldp == null) {
      ldp = dateElementParser().withZone(DateTimeZone.UTC);
    }
    return ldp;
  }
  









  public static DateTimeFormatter dateElementParser()
  {
    if (dpe == null) {
      dpe = new DateTimeFormatterBuilder().append(null, new DateTimeParser[] { new DateTimeFormatterBuilder().append(yearElement()).appendOptional(new DateTimeFormatterBuilder().append(monthElement()).appendOptional(dayOfMonthElement().getParser()).toParser()).toParser(), new DateTimeFormatterBuilder().append(weekyearElement()).append(weekElement()).appendOptional(dayOfWeekElement().getParser()).toParser(), new DateTimeFormatterBuilder().append(yearElement()).append(dayOfYearElement()).toParser() }).toFormatter();
    }
    



















    return dpe;
  }
  











  public static DateTimeFormatter timeParser()
  {
    if (tp == null) {
      tp = new DateTimeFormatterBuilder().appendOptional(literalTElement().getParser()).append(timeElementParser()).appendOptional(offsetElement().getParser()).toFormatter();
    }
    



    return tp;
  }
  













  public static DateTimeFormatter localTimeParser()
  {
    if (ltp == null) {
      ltp = new DateTimeFormatterBuilder().appendOptional(literalTElement().getParser()).append(timeElementParser()).toFormatter().withZone(DateTimeZone.UTC);
    }
    


    return ltp;
  }
  









  public static DateTimeFormatter timeElementParser()
  {
    if (tpe == null)
    {
      DateTimeParser localDateTimeParser = new DateTimeFormatterBuilder().append(null, new DateTimeParser[] { new DateTimeFormatterBuilder().appendLiteral('.').toParser(), new DateTimeFormatterBuilder().appendLiteral(',').toParser() }).toParser();
      









      tpe = new DateTimeFormatterBuilder().append(hourElement()).append(null, new DateTimeParser[] { new DateTimeFormatterBuilder().append(minuteElement()).append(null, new DateTimeParser[] { new DateTimeFormatterBuilder().append(secondElement()).appendOptional(new DateTimeFormatterBuilder().append(localDateTimeParser).appendFractionOfSecond(1, 9).toParser()).toParser(), new DateTimeFormatterBuilder().append(localDateTimeParser).appendFractionOfMinute(1, 9).toParser(), null }).toParser(), new DateTimeFormatterBuilder().append(localDateTimeParser).appendFractionOfHour(1, 9).toParser(), null }).toFormatter();
    }
    

































    return tpe;
  }
  

















  public static DateTimeFormatter dateTimeParser()
  {
    if (dtp == null)
    {

      DateTimeParser localDateTimeParser = new DateTimeFormatterBuilder().appendLiteral('T').append(timeElementParser()).appendOptional(offsetElement().getParser()).toParser();
      



      dtp = new DateTimeFormatterBuilder().append(null, new DateTimeParser[] { localDateTimeParser, dateOptionalTimeParser().getParser() }).toFormatter();
    }
    

    return dtp;
  }
  
















  public static DateTimeFormatter dateOptionalTimeParser()
  {
    if (dotp == null) {
      DateTimeParser localDateTimeParser = new DateTimeFormatterBuilder().appendLiteral('T').appendOptional(timeElementParser().getParser()).appendOptional(offsetElement().getParser()).toParser();
      



      dotp = new DateTimeFormatterBuilder().append(dateElementParser()).appendOptional(localDateTimeParser).toFormatter();
    }
    


    return dotp;
  }
  


















  public static DateTimeFormatter localDateOptionalTimeParser()
  {
    if (ldotp == null) {
      DateTimeParser localDateTimeParser = new DateTimeFormatterBuilder().appendLiteral('T').append(timeElementParser()).toParser();
      


      ldotp = new DateTimeFormatterBuilder().append(dateElementParser()).appendOptional(localDateTimeParser).toFormatter().withZone(DateTimeZone.UTC);
    }
    


    return ldotp;
  }
  






  public static DateTimeFormatter date()
  {
    return yearMonthDay();
  }
  







  public static DateTimeFormatter time()
  {
    if (t == null) {
      t = new DateTimeFormatterBuilder().append(hourMinuteSecondFraction()).append(offsetElement()).toFormatter();
    }
    


    return t;
  }
  






  public static DateTimeFormatter timeNoMillis()
  {
    if (tx == null) {
      tx = new DateTimeFormatterBuilder().append(hourMinuteSecond()).append(offsetElement()).toFormatter();
    }
    


    return tx;
  }
  







  public static DateTimeFormatter tTime()
  {
    if (tt == null) {
      tt = new DateTimeFormatterBuilder().append(literalTElement()).append(time()).toFormatter();
    }
    


    return tt;
  }
  







  public static DateTimeFormatter tTimeNoMillis()
  {
    if (ttx == null) {
      ttx = new DateTimeFormatterBuilder().append(literalTElement()).append(timeNoMillis()).toFormatter();
    }
    


    return ttx;
  }
  






  public static DateTimeFormatter dateTime()
  {
    if (dt == null) {
      dt = new DateTimeFormatterBuilder().append(date()).append(tTime()).toFormatter();
    }
    


    return dt;
  }
  






  public static DateTimeFormatter dateTimeNoMillis()
  {
    if (dtx == null) {
      dtx = new DateTimeFormatterBuilder().append(date()).append(tTimeNoMillis()).toFormatter();
    }
    


    return dtx;
  }
  






  public static DateTimeFormatter ordinalDate()
  {
    if (od == null) {
      od = new DateTimeFormatterBuilder().append(yearElement()).append(dayOfYearElement()).toFormatter();
    }
    


    return od;
  }
  







  public static DateTimeFormatter ordinalDateTime()
  {
    if (odt == null) {
      odt = new DateTimeFormatterBuilder().append(ordinalDate()).append(tTime()).toFormatter();
    }
    


    return odt;
  }
  







  public static DateTimeFormatter ordinalDateTimeNoMillis()
  {
    if (odtx == null) {
      odtx = new DateTimeFormatterBuilder().append(ordinalDate()).append(tTimeNoMillis()).toFormatter();
    }
    


    return odtx;
  }
  





  public static DateTimeFormatter weekDate()
  {
    return weekyearWeekDay();
  }
  






  public static DateTimeFormatter weekDateTime()
  {
    if (wdt == null) {
      wdt = new DateTimeFormatterBuilder().append(weekDate()).append(tTime()).toFormatter();
    }
    


    return wdt;
  }
  






  public static DateTimeFormatter weekDateTimeNoMillis()
  {
    if (wdtx == null) {
      wdtx = new DateTimeFormatterBuilder().append(weekDate()).append(tTimeNoMillis()).toFormatter();
    }
    


    return wdtx;
  }
  






  public static DateTimeFormatter basicDate()
  {
    if (bd == null) {
      bd = new DateTimeFormatterBuilder().appendYear(4, 4).appendFixedDecimal(DateTimeFieldType.monthOfYear(), 2).appendFixedDecimal(DateTimeFieldType.dayOfMonth(), 2).toFormatter();
    }
    



    return bd;
  }
  







  public static DateTimeFormatter basicTime()
  {
    if (bt == null) {
      bt = new DateTimeFormatterBuilder().appendFixedDecimal(DateTimeFieldType.hourOfDay(), 2).appendFixedDecimal(DateTimeFieldType.minuteOfHour(), 2).appendFixedDecimal(DateTimeFieldType.secondOfMinute(), 2).appendLiteral('.').appendFractionOfSecond(3, 9).appendTimeZoneOffset("Z", false, 2, 2).toFormatter();
    }
    






    return bt;
  }
  






  public static DateTimeFormatter basicTimeNoMillis()
  {
    if (btx == null) {
      btx = new DateTimeFormatterBuilder().appendFixedDecimal(DateTimeFieldType.hourOfDay(), 2).appendFixedDecimal(DateTimeFieldType.minuteOfHour(), 2).appendFixedDecimal(DateTimeFieldType.secondOfMinute(), 2).appendTimeZoneOffset("Z", false, 2, 2).toFormatter();
    }
    




    return btx;
  }
  







  public static DateTimeFormatter basicTTime()
  {
    if (btt == null) {
      btt = new DateTimeFormatterBuilder().append(literalTElement()).append(basicTime()).toFormatter();
    }
    


    return btt;
  }
  







  public static DateTimeFormatter basicTTimeNoMillis()
  {
    if (bttx == null) {
      bttx = new DateTimeFormatterBuilder().append(literalTElement()).append(basicTimeNoMillis()).toFormatter();
    }
    


    return bttx;
  }
  






  public static DateTimeFormatter basicDateTime()
  {
    if (bdt == null) {
      bdt = new DateTimeFormatterBuilder().append(basicDate()).append(basicTTime()).toFormatter();
    }
    


    return bdt;
  }
  






  public static DateTimeFormatter basicDateTimeNoMillis()
  {
    if (bdtx == null) {
      bdtx = new DateTimeFormatterBuilder().append(basicDate()).append(basicTTimeNoMillis()).toFormatter();
    }
    


    return bdtx;
  }
  






  public static DateTimeFormatter basicOrdinalDate()
  {
    if (bod == null) {
      bod = new DateTimeFormatterBuilder().appendYear(4, 4).appendFixedDecimal(DateTimeFieldType.dayOfYear(), 3).toFormatter();
    }
    


    return bod;
  }
  







  public static DateTimeFormatter basicOrdinalDateTime()
  {
    if (bodt == null) {
      bodt = new DateTimeFormatterBuilder().append(basicOrdinalDate()).append(basicTTime()).toFormatter();
    }
    


    return bodt;
  }
  







  public static DateTimeFormatter basicOrdinalDateTimeNoMillis()
  {
    if (bodtx == null) {
      bodtx = new DateTimeFormatterBuilder().append(basicOrdinalDate()).append(basicTTimeNoMillis()).toFormatter();
    }
    


    return bodtx;
  }
  





  public static DateTimeFormatter basicWeekDate()
  {
    if (bwd == null) {
      bwd = new DateTimeFormatterBuilder().appendWeekyear(4, 4).appendLiteral('W').appendFixedDecimal(DateTimeFieldType.weekOfWeekyear(), 2).appendFixedDecimal(DateTimeFieldType.dayOfWeek(), 1).toFormatter();
    }
    




    return bwd;
  }
  






  public static DateTimeFormatter basicWeekDateTime()
  {
    if (bwdt == null) {
      bwdt = new DateTimeFormatterBuilder().append(basicWeekDate()).append(basicTTime()).toFormatter();
    }
    


    return bwdt;
  }
  






  public static DateTimeFormatter basicWeekDateTimeNoMillis()
  {
    if (bwdtx == null) {
      bwdtx = new DateTimeFormatterBuilder().append(basicWeekDate()).append(basicTTimeNoMillis()).toFormatter();
    }
    


    return bwdtx;
  }
  





  public static DateTimeFormatter year()
  {
    return yearElement();
  }
  





  public static DateTimeFormatter yearMonth()
  {
    if (ym == null) {
      ym = new DateTimeFormatterBuilder().append(yearElement()).append(monthElement()).toFormatter();
    }
    


    return ym;
  }
  





  public static DateTimeFormatter yearMonthDay()
  {
    if (ymd == null) {
      ymd = new DateTimeFormatterBuilder().append(yearElement()).append(monthElement()).append(dayOfMonthElement()).toFormatter();
    }
    



    return ymd;
  }
  




  public static DateTimeFormatter weekyear()
  {
    return weekyearElement();
  }
  





  public static DateTimeFormatter weekyearWeek()
  {
    if (ww == null) {
      ww = new DateTimeFormatterBuilder().append(weekyearElement()).append(weekElement()).toFormatter();
    }
    


    return ww;
  }
  





  public static DateTimeFormatter weekyearWeekDay()
  {
    if (wwd == null) {
      wwd = new DateTimeFormatterBuilder().append(weekyearElement()).append(weekElement()).append(dayOfWeekElement()).toFormatter();
    }
    



    return wwd;
  }
  




  public static DateTimeFormatter hour()
  {
    return hourElement();
  }
  





  public static DateTimeFormatter hourMinute()
  {
    if (hm == null) {
      hm = new DateTimeFormatterBuilder().append(hourElement()).append(minuteElement()).toFormatter();
    }
    


    return hm;
  }
  





  public static DateTimeFormatter hourMinuteSecond()
  {
    if (hms == null) {
      hms = new DateTimeFormatterBuilder().append(hourElement()).append(minuteElement()).append(secondElement()).toFormatter();
    }
    



    return hms;
  }
  







  public static DateTimeFormatter hourMinuteSecondMillis()
  {
    if (hmsl == null) {
      hmsl = new DateTimeFormatterBuilder().append(hourElement()).append(minuteElement()).append(secondElement()).appendLiteral('.').appendFractionOfSecond(3, 3).toFormatter();
    }
    





    return hmsl;
  }
  







  public static DateTimeFormatter hourMinuteSecondFraction()
  {
    if (hmsf == null) {
      hmsf = new DateTimeFormatterBuilder().append(hourElement()).append(minuteElement()).append(secondElement()).append(fractionElement()).toFormatter();
    }
    




    return hmsf;
  }
  





  public static DateTimeFormatter dateHour()
  {
    if (dh == null) {
      dh = new DateTimeFormatterBuilder().append(date()).append(literalTElement()).append(hour()).toFormatter();
    }
    



    return dh;
  }
  





  public static DateTimeFormatter dateHourMinute()
  {
    if (dhm == null) {
      dhm = new DateTimeFormatterBuilder().append(date()).append(literalTElement()).append(hourMinute()).toFormatter();
    }
    



    return dhm;
  }
  






  public static DateTimeFormatter dateHourMinuteSecond()
  {
    if (dhms == null) {
      dhms = new DateTimeFormatterBuilder().append(date()).append(literalTElement()).append(hourMinuteSecond()).toFormatter();
    }
    



    return dhms;
  }
  







  public static DateTimeFormatter dateHourMinuteSecondMillis()
  {
    if (dhmsl == null) {
      dhmsl = new DateTimeFormatterBuilder().append(date()).append(literalTElement()).append(hourMinuteSecondMillis()).toFormatter();
    }
    



    return dhmsl;
  }
  







  public static DateTimeFormatter dateHourMinuteSecondFraction()
  {
    if (dhmsf == null) {
      dhmsf = new DateTimeFormatterBuilder().append(date()).append(literalTElement()).append(hourMinuteSecondFraction()).toFormatter();
    }
    



    return dhmsf;
  }
  
  private static DateTimeFormatter yearElement()
  {
    if (ye == null) {
      ye = new DateTimeFormatterBuilder().appendYear(4, 9).toFormatter();
    }
    

    return ye;
  }
  
  private static DateTimeFormatter monthElement() {
    if (mye == null) {
      mye = new DateTimeFormatterBuilder().appendLiteral('-').appendMonthOfYear(2).toFormatter();
    }
    


    return mye;
  }
  
  private static DateTimeFormatter dayOfMonthElement() {
    if (dme == null) {
      dme = new DateTimeFormatterBuilder().appendLiteral('-').appendDayOfMonth(2).toFormatter();
    }
    


    return dme;
  }
  
  private static DateTimeFormatter weekyearElement() {
    if (we == null) {
      we = new DateTimeFormatterBuilder().appendWeekyear(4, 9).toFormatter();
    }
    

    return we;
  }
  
  private static DateTimeFormatter weekElement() {
    if (wwe == null) {
      wwe = new DateTimeFormatterBuilder().appendLiteral("-W").appendWeekOfWeekyear(2).toFormatter();
    }
    


    return wwe;
  }
  
  private static DateTimeFormatter dayOfWeekElement() {
    if (dwe == null) {
      dwe = new DateTimeFormatterBuilder().appendLiteral('-').appendDayOfWeek(1).toFormatter();
    }
    


    return dwe;
  }
  
  private static DateTimeFormatter dayOfYearElement() {
    if (dye == null) {
      dye = new DateTimeFormatterBuilder().appendLiteral('-').appendDayOfYear(3).toFormatter();
    }
    


    return dye;
  }
  
  private static DateTimeFormatter literalTElement() {
    if (lte == null) {
      lte = new DateTimeFormatterBuilder().appendLiteral('T').toFormatter();
    }
    

    return lte;
  }
  
  private static DateTimeFormatter hourElement() {
    if (hde == null) {
      hde = new DateTimeFormatterBuilder().appendHourOfDay(2).toFormatter();
    }
    

    return hde;
  }
  
  private static DateTimeFormatter minuteElement() {
    if (mhe == null) {
      mhe = new DateTimeFormatterBuilder().appendLiteral(':').appendMinuteOfHour(2).toFormatter();
    }
    


    return mhe;
  }
  
  private static DateTimeFormatter secondElement() {
    if (sme == null) {
      sme = new DateTimeFormatterBuilder().appendLiteral(':').appendSecondOfMinute(2).toFormatter();
    }
    


    return sme;
  }
  
  private static DateTimeFormatter fractionElement() {
    if (fse == null) {
      fse = new DateTimeFormatterBuilder().appendLiteral('.').appendFractionOfSecond(3, 9).toFormatter();
    }
    




    return fse;
  }
  
  private static DateTimeFormatter offsetElement() {
    if (ze == null) {
      ze = new DateTimeFormatterBuilder().appendTimeZoneOffset("Z", true, 2, 4).toFormatter();
    }
    

    return ze;
  }
}
