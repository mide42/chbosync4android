package com.funambol.org.joda.time;

import java.io.Serializable;
import com.funambol.org.joda.time.base.BaseDuration;
import com.funambol.org.joda.time.field.FieldUtils;
































public final class Duration
  extends BaseDuration
  implements ReadableDuration, Serializable
{
  public static final Duration ZERO = new Duration(0L);
  









  private static final long serialVersionUID = 2471658376918L;
  









  public static Duration standardDays(long paramLong)
  {
    if (paramLong == 0L) {
      return ZERO;
    }
    return new Duration(FieldUtils.safeMultiply(paramLong, 86400000));
  }
  















  public static Duration standardHours(long paramLong)
  {
    if (paramLong == 0L) {
      return ZERO;
    }
    return new Duration(FieldUtils.safeMultiply(paramLong, 3600000));
  }
  















  public static Duration standardMinutes(long paramLong)
  {
    if (paramLong == 0L) {
      return ZERO;
    }
    return new Duration(FieldUtils.safeMultiply(paramLong, 60000));
  }
  














  public static Duration standardSeconds(long paramLong)
  {
    if (paramLong == 0L) {
      return ZERO;
    }
    return new Duration(FieldUtils.safeMultiply(paramLong, 1000));
  }
  





  public Duration(long paramLong)
  {
    super(paramLong);
  }
  






  public Duration(long paramLong1, long paramLong2)
  {
    super(paramLong1, paramLong2);
  }
  






  public Duration(ReadableInstant paramReadableInstant1, ReadableInstant paramReadableInstant2)
  {
    super(paramReadableInstant1, paramReadableInstant2);
  }
  






  public Duration(Object paramObject)
  {
    super(paramObject);
  }
  










  public long getStandardSeconds()
  {
    return getMillis() / 1000L;
  }
  






  public Duration toDuration()
  {
    return this;
  }
  









  public Seconds toStandardSeconds()
  {
    long l = getStandardSeconds();
    return Seconds.seconds(FieldUtils.safeToInt(l));
  }
  






  public Duration withMillis(long paramLong)
  {
    if (paramLong == getMillis()) {
      return this;
    }
    return new Duration(paramLong);
  }
  









  public Duration withDurationAdded(long paramLong, int paramInt)
  {
    if ((paramLong == 0L) || (paramInt == 0)) {
      return this;
    }
    long l1 = FieldUtils.safeMultiply(paramLong, paramInt);
    long l2 = FieldUtils.safeAdd(getMillis(), l1);
    return new Duration(l2);
  }
  









  public Duration withDurationAdded(ReadableDuration paramReadableDuration, int paramInt)
  {
    if ((paramReadableDuration == null) || (paramInt == 0)) {
      return this;
    }
    return withDurationAdded(paramReadableDuration.getMillis(), paramInt);
  }
  









  public Duration plus(long paramLong)
  {
    return withDurationAdded(paramLong, 1);
  }
  








  public Duration plus(ReadableDuration paramReadableDuration)
  {
    if (paramReadableDuration == null) {
      return this;
    }
    return withDurationAdded(paramReadableDuration.getMillis(), 1);
  }
  








  public Duration minus(long paramLong)
  {
    return withDurationAdded(paramLong, -1);
  }
  








  public Duration minus(ReadableDuration paramReadableDuration)
  {
    if (paramReadableDuration == null) {
      return this;
    }
    return withDurationAdded(paramReadableDuration.getMillis(), -1);
  }
}
