package com.funambol.org.joda.time.format;

import java.io.IOException;
import java.io.Writer;
import java.util.Locale;
import com.funambol.org.joda.time.Chronology;
import com.funambol.org.joda.time.DateTime;
import com.funambol.org.joda.time.DateTimeUtils;
import com.funambol.org.joda.time.DateTimeZone;
import com.funambol.org.joda.time.MutableDateTime;
import com.funambol.org.joda.time.ReadWritableInstant;
import com.funambol.org.joda.time.ReadableInstant;
import com.funambol.org.joda.time.ReadablePartial;













































































public class DateTimeFormatter
{
  private final DateTimePrinter iPrinter;
  private final DateTimeParser iParser;
  private final Locale iLocale;
  private final boolean iOffsetParsed;
  private final Chronology iChrono;
  private final DateTimeZone iZone;
  private final Integer iPivotYear;
  
  public DateTimeFormatter(DateTimePrinter paramDateTimePrinter, DateTimeParser paramDateTimeParser)
  {
    iPrinter = paramDateTimePrinter;
    iParser = paramDateTimeParser;
    iLocale = null;
    iOffsetParsed = false;
    iChrono = null;
    iZone = null;
    iPivotYear = null;
  }
  







  private DateTimeFormatter(DateTimePrinter paramDateTimePrinter, DateTimeParser paramDateTimeParser, Locale paramLocale, boolean paramBoolean, Chronology paramChronology, DateTimeZone paramDateTimeZone, Integer paramInteger)
  {
    iPrinter = paramDateTimePrinter;
    iParser = paramDateTimeParser;
    iLocale = paramLocale;
    iOffsetParsed = paramBoolean;
    iChrono = paramChronology;
    iZone = paramDateTimeZone;
    iPivotYear = paramInteger;
  }
  





  public boolean isPrinter()
  {
    return iPrinter != null;
  }
  




  public DateTimePrinter getPrinter()
  {
    return iPrinter;
  }
  




  public boolean isParser()
  {
    return iParser != null;
  }
  




  public DateTimeParser getParser()
  {
    return iParser;
  }
  











  public DateTimeFormatter withLocale(Locale paramLocale)
  {
    if ((paramLocale == getLocale()) || ((paramLocale != null) && (paramLocale.equals(getLocale())))) {
      return this;
    }
    return new DateTimeFormatter(iPrinter, iParser, paramLocale, iOffsetParsed, iChrono, iZone, iPivotYear);
  }
  






  public Locale getLocale()
  {
    return iLocale;
  }
  














  public DateTimeFormatter withOffsetParsed()
  {
    if (iOffsetParsed == true) {
      return this;
    }
    return new DateTimeFormatter(iPrinter, iParser, iLocale, true, iChrono, null, iPivotYear);
  }
  






  public boolean isOffsetParsed()
  {
    return iOffsetParsed;
  }
  
















  public DateTimeFormatter withChronology(Chronology paramChronology)
  {
    if (iChrono == paramChronology) {
      return this;
    }
    return new DateTimeFormatter(iPrinter, iParser, iLocale, iOffsetParsed, paramChronology, iZone, iPivotYear);
  }
  





  public Chronology getChronolgy()
  {
    return iChrono;
  }
  
















  public DateTimeFormatter withZone(DateTimeZone paramDateTimeZone)
  {
    if (iZone == paramDateTimeZone) {
      return this;
    }
    return new DateTimeFormatter(iPrinter, iParser, iLocale, false, iChrono, paramDateTimeZone, iPivotYear);
  }
  





  public DateTimeZone getZone()
  {
    return iZone;
  }
  





























  public DateTimeFormatter withPivotYear(Integer paramInteger)
  {
    if ((iPivotYear == paramInteger) || ((iPivotYear != null) && (iPivotYear.equals(paramInteger)))) {
      return this;
    }
    return new DateTimeFormatter(iPrinter, iParser, iLocale, iOffsetParsed, iChrono, iZone, paramInteger);
  }
  





























  public DateTimeFormatter withPivotYear(int paramInt)
  {
    return withPivotYear(new Integer(paramInt));
  }
  





  public Integer getPivotYear()
  {
    return iPivotYear;
  }
  






  public void printTo(StringBuffer paramStringBuffer, ReadableInstant paramReadableInstant)
  {
    long l = DateTimeUtils.getInstantMillis(paramReadableInstant);
    Chronology localChronology = DateTimeUtils.getInstantChronology(paramReadableInstant);
    printTo(paramStringBuffer, l, localChronology);
  }
  




  public void printTo(Writer paramWriter, ReadableInstant paramReadableInstant)
    throws IOException
  {
    long l = DateTimeUtils.getInstantMillis(paramReadableInstant);
    Chronology localChronology = DateTimeUtils.getInstantChronology(paramReadableInstant);
    printTo(paramWriter, l, localChronology);
  }
  







  public void printTo(StringBuffer paramStringBuffer, long paramLong)
  {
    printTo(paramStringBuffer, paramLong, null);
  }
  





  public void printTo(Writer paramWriter, long paramLong)
    throws IOException
  {
    printTo(paramWriter, paramLong, null);
  }
  









  public void printTo(StringBuffer paramStringBuffer, ReadablePartial paramReadablePartial)
  {
    DateTimePrinter localDateTimePrinter = requirePrinter();
    if (paramReadablePartial == null) {
      throw new IllegalArgumentException("The partial must not be null");
    }
    localDateTimePrinter.printTo(paramStringBuffer, paramReadablePartial, iLocale);
  }
  







  public void printTo(Writer paramWriter, ReadablePartial paramReadablePartial)
    throws IOException
  {
    DateTimePrinter localDateTimePrinter = requirePrinter();
    if (paramReadablePartial == null) {
      throw new IllegalArgumentException("The partial must not be null");
    }
    localDateTimePrinter.printTo(paramWriter, paramReadablePartial, iLocale);
  }
  









  public String print(ReadableInstant paramReadableInstant)
  {
    StringBuffer localStringBuffer = new StringBuffer(requirePrinter().estimatePrintedLength());
    printTo(localStringBuffer, paramReadableInstant);
    return localStringBuffer.toString();
  }
  








  public String print(long paramLong)
  {
    StringBuffer localStringBuffer = new StringBuffer(requirePrinter().estimatePrintedLength());
    printTo(localStringBuffer, paramLong);
    return localStringBuffer.toString();
  }
  








  public String print(ReadablePartial paramReadablePartial)
  {
    StringBuffer localStringBuffer = new StringBuffer(requirePrinter().estimatePrintedLength());
    printTo(localStringBuffer, paramReadablePartial);
    return localStringBuffer.toString();
  }
  
  private void printTo(StringBuffer paramStringBuffer, long paramLong, Chronology paramChronology) {
    DateTimePrinter localDateTimePrinter = requirePrinter();
    paramChronology = selectChronology(paramChronology);
    

    DateTimeZone localDateTimeZone = paramChronology.getZone();
    int i = localDateTimeZone.getOffset(paramLong);
    long l = paramLong + i;
    if (((paramLong ^ l) < 0L) && ((paramLong ^ i) >= 0L))
    {
      localDateTimeZone = DateTimeZone.UTC;
      i = 0;
      l = paramLong;
    }
    localDateTimePrinter.printTo(paramStringBuffer, l, paramChronology.withUTC(), i, localDateTimeZone, iLocale);
  }
  
  private void printTo(Writer paramWriter, long paramLong, Chronology paramChronology) throws IOException {
    DateTimePrinter localDateTimePrinter = requirePrinter();
    paramChronology = selectChronology(paramChronology);
    

    DateTimeZone localDateTimeZone = paramChronology.getZone();
    int i = localDateTimeZone.getOffset(paramLong);
    long l = paramLong + i;
    if (((paramLong ^ l) < 0L) && ((paramLong ^ i) >= 0L))
    {
      localDateTimeZone = DateTimeZone.UTC;
      i = 0;
      l = paramLong;
    }
    localDateTimePrinter.printTo(paramWriter, l, paramChronology.withUTC(), i, localDateTimeZone, iLocale);
  }
  




  private DateTimePrinter requirePrinter()
  {
    DateTimePrinter localDateTimePrinter = iPrinter;
    if (localDateTimePrinter == null) {
      throw new UnsupportedOperationException("Printing not supported");
    }
    return localDateTimePrinter;
  }
  





























  public int parseInto(ReadWritableInstant paramReadWritableInstant, String paramString, int paramInt)
  {
    DateTimeParser localDateTimeParser = requireParser();
    if (paramReadWritableInstant == null) {
      throw new IllegalArgumentException("Instant must not be null");
    }
    
    long l1 = paramReadWritableInstant.getMillis();
    Chronology localChronology = paramReadWritableInstant.getChronology();
    long l2 = l1 + localChronology.getZone().getOffset(l1);
    localChronology = selectChronology(localChronology);
    
    DateTimeParserBucket localDateTimeParserBucket = new DateTimeParserBucket(l2, localChronology, iLocale, iPivotYear);
    
    int i = localDateTimeParser.parseInto(localDateTimeParserBucket, paramString, paramInt);
    paramReadWritableInstant.setMillis(localDateTimeParserBucket.computeMillis(false, paramString));
    if ((iOffsetParsed) && (localDateTimeParserBucket.getZone() == null)) {
      int j = localDateTimeParserBucket.getOffset();
      DateTimeZone localDateTimeZone = DateTimeZone.forOffsetMillis(j);
      localChronology = localChronology.withZone(localDateTimeZone);
    }
    paramReadWritableInstant.setChronology(localChronology);
    return i;
  }
  











  public long parseMillis(String paramString)
  {
    DateTimeParser localDateTimeParser = requireParser();
    
    Chronology localChronology = selectChronology(iChrono);
    DateTimeParserBucket localDateTimeParserBucket = new DateTimeParserBucket(0L, localChronology, iLocale, iPivotYear);
    int i = localDateTimeParser.parseInto(localDateTimeParserBucket, paramString, 0);
    if (i >= 0) {
      if (i >= paramString.length()) {
        return localDateTimeParserBucket.computeMillis(true, paramString);
      }
    } else {
      i ^= 0xFFFFFFFF;
    }
    throw new IllegalArgumentException(FormatUtils.createErrorMessage(paramString, i));
  }
  
















  public DateTime parseDateTime(String paramString)
  {
    DateTimeParser localDateTimeParser = requireParser();
    
    Chronology localChronology = selectChronology(null);
    DateTimeParserBucket localDateTimeParserBucket = new DateTimeParserBucket(0L, localChronology, iLocale, iPivotYear);
    int i = localDateTimeParser.parseInto(localDateTimeParserBucket, paramString, 0);
    if (i >= 0) {
      if (i >= paramString.length()) {
        long l = localDateTimeParserBucket.computeMillis(true, paramString);
        if ((iOffsetParsed) && (localDateTimeParserBucket.getZone() == null)) {
          int j = localDateTimeParserBucket.getOffset();
          DateTimeZone localDateTimeZone = DateTimeZone.forOffsetMillis(j);
          localChronology = localChronology.withZone(localDateTimeZone);
        }
        return new DateTime(l, localChronology);
      }
    } else {
      i ^= 0xFFFFFFFF;
    }
    throw new IllegalArgumentException(FormatUtils.createErrorMessage(paramString, i));
  }
  
















  public MutableDateTime parseMutableDateTime(String paramString)
  {
    DateTimeParser localDateTimeParser = requireParser();
    
    Chronology localChronology = selectChronology(null);
    DateTimeParserBucket localDateTimeParserBucket = new DateTimeParserBucket(0L, localChronology, iLocale, iPivotYear);
    int i = localDateTimeParser.parseInto(localDateTimeParserBucket, paramString, 0);
    if (i >= 0) {
      if (i >= paramString.length()) {
        long l = localDateTimeParserBucket.computeMillis(true, paramString);
        if ((iOffsetParsed) && (localDateTimeParserBucket.getZone() == null)) {
          int j = localDateTimeParserBucket.getOffset();
          DateTimeZone localDateTimeZone = DateTimeZone.forOffsetMillis(j);
          localChronology = localChronology.withZone(localDateTimeZone);
        }
        return new MutableDateTime(l, localChronology);
      }
    } else {
      i ^= 0xFFFFFFFF;
    }
    throw new IllegalArgumentException(FormatUtils.createErrorMessage(paramString, i));
  }
  




  private DateTimeParser requireParser()
  {
    DateTimeParser localDateTimeParser = iParser;
    if (localDateTimeParser == null) {
      throw new UnsupportedOperationException("Parsing not supported");
    }
    return localDateTimeParser;
  }
  






  private Chronology selectChronology(Chronology paramChronology)
  {
    paramChronology = DateTimeUtils.getChronology(paramChronology);
    if (iChrono != null) {
      paramChronology = iChrono;
    }
    if (iZone != null) {
      paramChronology = paramChronology.withZone(iZone);
    }
    return paramChronology;
  }
}
